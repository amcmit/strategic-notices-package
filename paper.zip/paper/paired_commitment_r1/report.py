"""Descriptive paired reductions; exact decimal-rational monetary arithmetic."""
import math
from fractions import Fraction
from common import F, EPS, MARGINS, PENALTIES, FAMILIES, ALPHA_CELLS

def sign(x): return 'positive' if x > EPS else 'negative' if x < -EPS else 'numerical_zero'

def weight_mean(rows, key, weighting):
    value=lambda r:Fraction(r['gain_exact']) if key=='gain' and 'gain_exact' in r else Fraction(r['change_gain_exact']) if key=='change_gain' and 'change_gain_exact' in r else F(r[key])
    if weighting == 'arithmetic': return sum((value(r) for r in rows), Fraction()) / len(rows)
    present = sorted({r['family'] for r in rows})
    if present != FAMILIES: raise ValueError('equal-family report requires all five families')
    return sum((sum((value(r) for r in rows if r['family']==fam), Fraction()) /
                sum(r['family']==fam for r in rows) for fam in present), Fraction()) / len(present)

def measures(observed, truth):
    return {'b': F(truth['backup'])-F(observed['backup']),
        'delta_d':F(observed['primary'])-F(truth['primary']),
        'delta_shortfall':F(observed['accepted_shortfall'])-F(truth['accepted_shortfall']),
        'accepted_shortfall':F(observed['accepted_shortfall']),
        'buyer_harm':F(observed['buyer_cost'])-F(truth['buyer_cost']),
        'qualification_selected':int(bool(observed['qualification_dates'])),
        'truth_qualification_selected':int(bool(truth['qualification_dates']))}

def build_report(records):
    if len(records)!=336 or len({r['path_id'] for r in records})!=336: raise ValueError('complete 336-path paired set required')
    bykey = {(r['task']['case_id'],r['task']['commitment'],r['task']['cell']):r for r in records}
    ids = sorted({r['task']['case_id'] for r in records})
    if len(ids)!=24: raise ValueError('all networks required')
    physical, decomposition, grid, paired, thresholds, grouped, pair_groups, patterns = [],[],[],[],[],[],[],[]
    cell_totals=[{'case_id':r['task']['case_id'],'family':r['task']['family'],'commitment':r['task']['commitment'],'cell':r['task']['cell'],**r['totals']} for r in records]
    for cid in ids:
        for contract in ['finite','horizon']:
            truth = bykey[cid,contract,'C00']['totals']; task = bykey[cid,contract,'C00']['task']
            cc = {cell:bykey[cid,contract,cell]['totals'] for cell in ['C00','C10','C01','C11']}
            h_contract = F(cc['C10']['buyer_cost'])-F(truth['buyer_cost'])
            h_belief = F(cc['C01']['buyer_cost'])-F(truth['buyer_cost'])
            h_total = F(cc['C11']['buyer_cost'])-F(truth['buyer_cost'])
            decomposition.append({'case_id':cid,'family':task['family'],'commitment':contract,
                'contractual':float(h_contract),'belief':float(h_belief),'interaction':float(h_total-h_contract-h_belief),'total':float(h_total)})
            suppression, positive_quantities, positive_gain = [],[],{}
            for alpha,cell in ALPHA_CELLS.items():
                observed = bykey[cid,contract,cell]['totals']; mm = measures(observed,truth)
                suppressed = bool(truth['qualification_dates']) and not bool(observed['qualification_dates'])
                suppression.append(suppressed); positive_quantities.append(mm['b']>EPS and mm['delta_d']>EPS)
                row = {'case_id':cid,'family':task['family'],'size':task['size'],'commitment':contract,'alpha':alpha,
                    **{k:float(v) for k,v in mm.items()}, 'backup_suppressed':suppressed,
                    'qualification_dates':observed['qualification_dates'],'truth_qualification_dates':truth['qualification_dates'],
                    'activation':observed['activation'],'expiry_exclusive':observed['expiry_exclusive'],
                    'truth_activation':truth['activation'],'truth_expiry_exclusive':truth['expiry_exclusive'],
                    'backup_payment':observed['backup_payment'],'truth_backup_payment':truth['backup_payment'],
                    'post_recovery_backup':observed['post_recovery_backup'],'truth_post_recovery_backup':truth['post_recovery_backup']}
                physical.append(row)
                for kappa in PENALTIES:
                    found = []
                    for rstr in MARGINS:
                        r = Fraction(rstr); gain = r*mm['delta_d']-kappa*mm['delta_shortfall']
                        gr = {k:row[k] for k in ['case_id','family','size','commitment','alpha']}
                        gr.update(r=float(r),r_fraction=rstr,kappa=kappa,
                            **{k:float(v) for k,v in mm.items()},gain=float(gain),gain_exact=str(gain),gain_sign=sign(gain))
                        grid.append(gr)
                        if gain > EPS: found.append(float(r))
                        positive_gain.setdefault((rstr,kappa),[]).append(gain>EPS)
                    thresholds.append({'case_id':cid,'family':task['family'],'commitment':contract,'alpha':alpha,'kappa':kappa,
                        'lowest_tested_r_positive':min(found) if found else None,'positive_levels':found,'interpolated':False})
            levels = list(ALPHA_CELLS)
            first = lambda pattern: next((a for a,v in zip(levels,pattern) if v),None)
            patterns.append({'case_id':cid,'commitment':contract,'family':task['family'],'alpha':levels,
                'suppression_pattern':suppression,'joint_positive_pattern':positive_quantities,
                'lowest_tested_alpha_suppression':first(suppression),'lowest_tested_alpha_joint':first(positive_quantities),
                'suppression_nonmonotone':any(a and not b for a,b in zip(suppression,suppression[1:])),
                'lowest_alpha_positive_gain':[{ 'r_fraction':r,'kappa':k,'alpha':first(p),
                    'pattern':p,'nonmonotone':any(a and not b for a,b in zip(p,p[1:]))} for (r,k),p in positive_gain.items()]})
    keys = ['b','delta_d','accepted_shortfall','delta_shortfall','buyer_harm','qualification_selected','truth_qualification_selected','gain']
    index = {(x['case_id'],x['commitment'],x['alpha'],x['r_fraction'],x['kappa']):x for x in grid}
    for cid in ids:
        for alpha in ALPHA_CELLS:
            for r in MARGINS:
                for k in PENALTIES:
                    lo,hi = [index[cid,c,alpha,r,k] for c in ['finite','horizon']]
                    pair = {'case_id':cid,'family':lo['family'],'alpha':alpha,'r_fraction':r,'r':float(Fraction(r)),'kappa':k}
                    for field in keys:
                        change = F(hi[field])-F(lo[field]) if field!='gain' else Fraction(hi['gain_exact'])-Fraction(lo['gain_exact'])
                        pair['change_'+field]=float(change); pair['sign_'+field]=sign(change)
                        if field=='gain':pair['change_gain_exact']=str(change)
                    pair['finite_gain']=lo['gain'];pair['horizon_gain']=hi['gain']
                    pair['nonpositive_to_positive']=Fraction(lo['gain_exact'])<=EPS and Fraction(hi['gain_exact'])>EPS
                    pair['positive_to_nonpositive']=Fraction(lo['gain_exact'])>EPS and Fraction(hi['gain_exact'])<=EPS
                    paired.append(pair)
    for alpha in ALPHA_CELLS:
        for r in MARGINS:
            for k in PENALTIES:
                at=[x for x in paired if (x['alpha'],x['r_fraction'],x['kappa'])==(alpha,r,k)]
                for weighting in ['arithmetic','equal_family']:
                    group={'alpha':alpha,'r_fraction':r,'r':float(Fraction(r)),'kappa':k,'weighting':weighting,'n':24,
                        'nonpositive_to_positive_count':sum(x['nonpositive_to_positive'] for x in at),
                        'positive_to_nonpositive_count':sum(x['positive_to_nonpositive'] for x in at)}
                    for key in keys:
                        val=weight_mean(at,'change_'+key,weighting);group['mean_change_'+key]=float(val);group['mean_change_sign_'+key]=sign(val)
                        for label in ['positive','negative','numerical_zero']:group[label+'_change_'+key]=sum(x['sign_'+key]==label for x in at)
                    pair_groups.append(group)
                    for contract in ['finite','horizon']:
                        selected=[index[cid,contract,alpha,r,k] for cid in ids]
                        out={'commitment':contract,'alpha':alpha,'r_fraction':r,'r':float(Fraction(r)),'kappa':k,'weighting':weighting,'n':24}
                        for key in keys:out['mean_'+key]=float(weight_mean(selected,key,weighting))
                        out['gain_positive_count']=sum(x['gain_sign']=='positive' for x in selected)
                        grouped.append(out)
    decomposition_means=[]
    for contract in ['finite','horizon']:
        for weighting in ['arithmetic','equal_family']:
            selected=[x for x in decomposition if x['commitment']==contract]
            decomposition_means.append({'commitment':contract,'weighting':weighting,'n':24,
                **{k:float(weight_mean(selected,k,weighting)) for k in ['contractual','belief','interaction','total']}})
    return {'schema':1,'descriptive_only':True,'tests':False,'intervals':False,'sign_tolerance':float(EPS),
        'cell_totals':cell_totals,'decomposition_means':decomposition_means,
        'physical':physical,'decomposition':decomposition,'network_grid':grid,'paired_grid':paired,
        'network_thresholds':thresholds,'group_grid':grouped,'paired_group_grid':pair_groups,'belief_patterns':patterns}
