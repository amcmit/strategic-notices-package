"""Receipt-gated paired profile/study. No solve without exact reviewed manifest."""
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
import argparse, math, resource, signal, sys, time, traceback, warnings
from common import *
from report import build_report

class ResourceStop(RuntimeError): pass
def rss(): return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024)

class Budget:
    def __init__(self,caps,folder):self.caps=caps;self.folder=folder;self.start=time.monotonic();self.phases=0;self.times=[]
    def check(self):
        if time.monotonic()-self.start>self.caps['wall_seconds']:raise ResourceStop('wall cap')
        if rss()>self.caps['peak_rss_mib']:raise ResourceStop('memory cap')
        if sum(p.stat().st_size for p in self.folder.rglob('*') if p.is_file())>self.caps['saved_bytes']-1048576:raise ResourceStop('output cap; reserve final failure record')
    def enter(self):
        self.check()
        if self.phases>=self.caps['maximum_mip_phases']:raise ResourceStop('phase cap')
        self.phases+=1
    def write(self,path,value):
        data=canonical(value)
        used=sum(p.stat().st_size for p in self.folder.rglob('*') if p.is_file())
        reserve=0 if path.name=='result.json' else 1048576
        if used+len(data)>self.caps['saved_bytes']-reserve:raise ResourceStop('write cap')
        path.write_bytes(data)

def objective_check(coeff,vector,cert):
    if len(coeff)!=len(vector) or not all(math.isfinite(float(v)) for v in [*coeff,*vector]):raise ValueError('nonfinite objective inputs')
    exact=sum((Fraction(float(a))*Fraction(float(x)) for a,x in zip(coeff,vector)),Fraction())
    limit=1e-7*max(1,abs(float(exact)),abs(cert.primal));gap=abs(float(exact)-cert.primal)
    if gap>limit:raise ValueError('objective consistency exceeds frozen scale')
    return {'exact_numerator':str(exact.numerator),'exact_denominator':str(exact.denominator),'solver_difference':gap,'limit':limit}

def run(path):
    m=authorize(path); out=ROOT/m['output'];out.mkdir() # exclusive attempt
    budget=Budget(m['caps'],out);profile=m['mode']=='profile';items={x['case_id']:x for x in m['catalog']}
    saved={} if profile else saved_records(m['catalog']);records=[];completed=[];failures=[];active=None;t=None
    write(out/'attempt.json',{'manifest_sha256':sha(path),'receipt_sha256':sha(HERE/('owner_approval_'+m['mode']+'.json')),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    original=planner._solve;observed={};call_cert=None
    def measured(model,objective,time_limit,phase,**kwargs):
        nonlocal observed,call_cert
        budget.enter();start=time.monotonic()
        try:
            vector,cert=original(model,objective,time_limit,phase,**kwargs);call_cert=asdict(cert)
            numerical=objective_check(objective,vector,cert)
            observed={'objective':numerical,'vector_length':len(vector),'primary_coefficients_finite':all(math.isfinite(x) for x in model.cost)}
            return vector,cert
        finally:
            elapsed=time.monotonic()-start;budget.times.append(elapsed)
            if elapsed>m['caps']['per_mip_seconds']+.01:raise ResourceStop('per phase cap plus 10ms measurement allowance')
            budget.check()
    def alarm(*_):raise ResourceStop('wall alarm')
    previous=signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,m['caps']['wall_seconds']);planner._solve=measured
    try:
        for index,task in enumerate(m['tasks']):
            active=task['path_id'];t=None;record={'path_id':active,'status':'running','periods':[]};captured=[]
            try:
                budget.check();item=items[task['case_id']];case,diff=variant(item,task['commitment'])
                if digest(asdict(case))!=task['variant_sha256'] or diff!=task['intervention']:raise ValueError('intervention hash differs')
                if not profile and task['cached_original']:
                    old,loc=saved[task['case_id'],task['cell']]
                    with forbid_solves():record=replay_cached(item,task,old)
                    record['cache_locator']=loc
                else:
                    state=initial_state_v3(case.network)
                    for t in range(20):
                        call=problem(case,state,task,m['caps']['per_mip_seconds']);observed={};call_cert=None;captured=[]
                        with warnings.catch_warnings(record=True) as captured:
                            warnings.simplefilter('always');choice=planner.plan(call)
                        warning_rows=[{'category':w.category.__name__,'message':str(w.message),'file':Path(w.filename).name,'line':w.lineno} for w in captured]
                        if any(issubclass(w.category,RuntimeWarning) for w in captured):raise ValueError('runtime numerical warning; review required')
                        if not all(math.isfinite(x) for x in [choice.expected_cost,choice.combined_objective,choice.primary_cost_loss_bound]):raise ValueError('nonfinite returned objective')
                        state,ledger=step_v3(case.network,case.contract,call.notice,state,choice.action,
                            Realization(case.long_capacity[t],case.baseline_demand[t]),
                            revealed_schedule=case.long_capacity if t==case.contract.revelation_period else None)
                        row={'period':t,'certificate':asdict(choice.certificate),'handoff_corrections':[asdict(c) for c in choice.handoff.corrections],
                            'phase_seconds':budget.times[-1],'peak_rss_mib':rss(),'warnings':warning_rows,'objective_check':observed}
                        if not profile:row.update(action=asdict(choice.action),ledger=asdict(ledger),planning_problem_sha256=digest(asdict(call)))
                        record['periods'].append(row);budget.check()
                    record.update(status='completed')
                    if not profile:record.update(task=task,totals=totals(record['periods'],case),final_state_sha256=digest(asdict(state)))
                if not profile:records.append(record)
                completed.append(active)
            except Exception as e:
                failure={'path_id':active,'period':t,'type':type(e).__name__,'full_error_text':str(e),'traceback':traceback.format_exc(),
                    'certificate':asdict(e.certificate) if isinstance(e,planner.PlannerFailure) else call_cert,
                    'warnings':[{'category':w.category.__name__,'message':str(w.message),'file':Path(w.filename).name,'line':w.lineno} for w in captured],
                    'last_objective_check':observed}
                record.update(status='failed',failure=failure);failures.append(failure)
            budget.write(out/f'path-{index:03d}.json',record)
            if failures:break
        if not failures and len(completed)==len(m['tasks']) and not profile:
            budget.write(out/'descriptive_report.json',build_report(records))
        budget.check()
    except Exception as e:failures.append({'path_id':active,'period':t,'type':type(e).__name__,'full_error_text':str(e),'traceback':traceback.format_exc()})
    finally:
        planner._solve=original;signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
    result={'status':'completed' if len(completed)==len(m['tasks']) and not failures else 'stopped','manifest_sha256':sha(path),
        'mode':m['mode'],'completed_paths':len(completed),'path_ids':completed,'mip_phases':budget.phases,
        'elapsed_seconds':time.monotonic()-budget.start,'peak_rss_mib':rss(),'phase_seconds':budget.times,'failures':failures,
        'files':{str(p.relative_to(out)):sha(p) for p in out.iterdir() if p.is_file()},
        'strategic_outputs_saved':not profile,'private_access':False,'new_tests_or_intervals':False}
    budget.write(out/'result.json',result);print(json.dumps({k:v for k,v in result.items() if k not in ['files','path_ids','phase_seconds']},indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);a=p.parse_args();run(a.manifest.resolve())
