"""Public-only paired extension preparation. No optimization at import/preparation."""
from pathlib import Path
from dataclasses import asdict, replace
from fractions import Fraction
from contextlib import contextmanager
import ast, csv, hashlib, json, math, platform, sys
from importlib.metadata import version

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
from sn import planner_v3_single_r3 as planner
from sn.allocation_v3 import canonical
from sn.belief_v3_common import load_case
from sn.core import Notice, Realization
from sn.core_v3 import initial_state_v3, step_v3
from sn.verify_belief_v3 import action, numeric_tree, certificate

PLANNER_HASH = '48f341a686809e41efa15b41583ccab562652ab9ae8a2bc24dbff97dcfcb239c'
CELLS = {'C00': ('major', 0), 'C10': ('minor', 0), 'C01': ('major', 1),
         'C11': ('minor', 1), 'A025': ('minor', .25), 'A050': ('minor', .5), 'A075': ('minor', .75)}
ALPHA_CELLS = {0: 'C10', .25: 'A025', .5: 'A050', .75: 'A075', 1: 'C11'}
MARGINS = [str(Fraction(i, 20)) for i in range(21)]
PENALTIES = [0, 1, 2, 3, 5, 10, 20]
FAMILIES = ['assembly', 'distribution', 'layered_dual', 'planted', 'serial']
EPS = Fraction(1, 100000000)
F = lambda x: Fraction(str(x))
DATASETS = ['v3_truthful_calibration_r4', 'v3_design_false_notice_r2', 'v3_discounted_belief_study_r1']
SCIENTIFIC = ['__init__', 'core', 'core_v2', 'core_v3', 'handoff_v3_single',
              'planner_v3_single_r3', 'allocation_v3', 'networks_v3', 'freeze_v3_design',
              'belief_v3_common', 'verify_belief_v3']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()

def digest(value): return hashlib.sha256(canonical(value)).hexdigest()
def read(path): return json.loads(Path(path).read_text())
def write(path, value): Path(path).write_bytes(canonical(value))
def csvwrite(path, rows):
    if not rows: raise ValueError('empty report')
    with Path(path).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)

@contextmanager
def forbid_solves():
    old = planner._solve, planner.milp
    def denied(*args, **kwargs): raise AssertionError('solve forbidden in preparation/tests/cache replay')
    planner._solve = planner.milp = denied
    try: yield
    finally: planner._solve, planner.milp = old

def environment():
    from scipy.optimize._highspy import _core
    return dict(python=platform.python_version(), system=platform.system(), machine=platform.machine(),
                numpy=version('numpy'), scipy=version('scipy'),
                highs='.'.join(str(getattr(_core, 'HIGHS_VERSION_' + x)) for x in ['MAJOR', 'MINOR', 'PATCH']))

def catalog():
    frozen = read(ROOT / 'configs/v3-design/selection-freeze.json')
    allocation = read(ROOT / 'configs/proposed-v3-allocation.json')
    factors = {x['case_id']: x for x in allocation['candidates'][0]['cases']}
    answer = [{**x, 'factors': factors[x['case_id']]} for x in frozen['cases']
              if x['regime'] == 'R1' and x['category'] == 'interior']
    if len(answer) != 24 or sha(ROOT / 'src/sn/planner_v3_single_r3.py') != PLANNER_HASH:
        raise ValueError('frozen roster or planner differs')
    return answer

def variant(item, commitment):
    original = load_case(ROOT, item)
    if commitment not in ('finite', 'horizon'): raise ValueError('unknown commitment')
    length = item['factors']['long_duration'] if commitment == 'finite' else None
    case = replace(original, contract=replace(original.contract, backup_commitment_periods=length))
    before, after = asdict(original), asdict(case)
    changed = before['contract'].pop('backup_commitment_periods'), after['contract'].pop('backup_commitment_periods')
    if before != after: raise ValueError('intervention changed more than commitment')
    if (case.network.horizon != 20 or case.contract.primary_price != 1 or
        case.contract.liability_multiplier != 1 or case.contract.fixed_contradiction_cost != 0 or
        case.contract.demand_rule != 'lost_sales'): raise ValueError('economic conventions differ')
    return case, {'field': 'contract.backup_commitment_periods', 'before': changed[0], 'after': changed[1]}

def make_tasks(items):
    tasks = []
    for item in items:
        for commitment in ('finite', 'horizon'):
            case, diff = variant(item, commitment)
            for cell, (schedule, alpha) in CELLS.items():
                tasks.append({'case_id': item['case_id'], 'family': item['family'], 'size': item['size'],
                    'commitment': commitment, 'cell': cell, 'schedule': schedule, 'alpha': alpha,
                    'path_id': f"{item['case_id']}|{commitment}|{cell}",
                    'original_content_sha256': item['content_sha256'], 'variant_sha256': digest(asdict(case)),
                    'intervention': diff, 'cached_original': commitment == item['factors']['commitment']})
    if len(tasks) != 336 or sum(not x['cached_original'] for x in tasks) != 168:
        raise ValueError('paired workload differs')
    return tasks

def problem(case, state, task, time_limit=30):
    schedule, alpha = CELLS[task['cell']]; period = state.period
    choices = [('long', 1, case.long_capacity)] if period >= case.contract.revelation_period else [
        ('short', alpha, case.short_capacity), ('long', 1-alpha, case.long_capacity)]
    scenarios = tuple(planner.Scenario(name, float(p), cap) for name,p,cap in choices if p > 0)
    notice = Notice(case.long_capacity if schedule == 'major' else case.short_capacity, schedule)
    return planner.PlanningProblem(case.network, case.contract, notice, state, scenarios,
        case.long_capacity[period], case.baseline_demand[period], case.baseline_demand, time_limit, False, 1)

def saved_records(items):
    ids = {x['case_id'] for x in items}; answer = {}
    for dataset in DATASETS:
        result_path = ROOT / f'results/{dataset}/result.json'; result = read(result_path)
        checked = read(result_path.parent / 'verification.json'); progress = result_path.parent / 'progress.jsonl'
        if (result['status'] != 'completed' or result['failures'] or checked['status'] != 'verified' or
            checked['result_sha256'] != sha(result_path) or result['progress_sha256'] != sha(progress) or
            checked['progress_sha256'] != result['progress_sha256']): raise ValueError('unverified cached evidence')
        with progress.open() as stream:
            for line_number, line in enumerate(stream,1):
                row = json.loads(line); cid, suffix = row['path_id'].split('|')
                if cid not in ids: continue
                cell = ('C00' if suffix == 'long/major' else None) if dataset == DATASETS[0] else (
                    suffix if dataset == DATASETS[1] else {'.25':'A025','.50':'A050','.75':'A075'}.get(suffix.replace('alpha=0','')))
                if cell not in CELLS: continue
                key = cid, cell
                if key in answer: raise ValueError('duplicate baseline path')
                answer[key] = (row, {'source': str(progress.relative_to(ROOT)), 'jsonl_line': line_number,
                                    'record_sha256': digest(row)})
    if len(answer) != 168: raise ValueError('missing cached path')
    return answer

def totals(periods, case):
    ledgers = [x['ledger'] for x in periods]
    def total(field): return math.fsum(x[field] for x in ledgers)
    dates = [x['period'] for x in periods if x['action']['qualify']]
    if len(dates) > 1: raise ValueError('qualification is irreversible')
    q = dates[0] if dates else None
    activation = None if q is None else q + case.contract.qualification_lead
    expiry = None if q is None else min(case.network.horizon, activation + (case.contract.backup_commitment_periods or case.network.horizon))
    return {'buyer_cost': total('operating_cost'), 'backup': total('backup_delivered'),
        'primary': total('primary_delivered'), 'accepted_shortfall': math.fsum(x['primary_shortfall']-x['pre_horizon_order_shortfall'] for x in ledgers),
        'pre_horizon_shortfall': total('pre_horizon_order_shortfall'), 'qualification_dates': dates,
        'activation': activation, 'expiry_exclusive': expiry, 'backup_payment': total('backup_cost'),
        'post_recovery_backup': math.fsum(x['backup_delivered'] for x in ledgers if case.long_capacity[x['period']] > 0),
        'lost_sales': math.fsum(v['quantity'] for x in ledgers for v in x['lost_sales']), 'spot': total('spot_delivered')}

def replay_cached(item, task, saved):
    case, _ = variant(item, task['commitment']); state = initial_state_v3(case.network); periods = []
    if saved['status'] != 'completed' or len(saved['periods']) != 20: raise ValueError('incomplete baseline')
    for t, row in enumerate(saved['periods']):
        if row['period'] != t: raise ValueError('period order')
        certificate(row['certificate'], current=task['cell'].startswith('A'))
        call = problem(case, state, task)
        if 'planning_problem_sha256' in row and digest(asdict(call)) != row['planning_problem_sha256']:
            raise ValueError('cached scientific input mismatch')
        chosen = action(row['action'])
        state, ledger = step_v3(case.network, case.contract, call.notice, state, chosen,
            Realization(case.long_capacity[t], case.baseline_demand[t]),
            revealed_schedule=case.long_capacity if t == case.contract.revelation_period else None)
        if 'ledger' in row:
            if numeric_tree(asdict(ledger)) != numeric_tree(row['ledger']): raise ValueError('cached ledger differs')
        elif digest(asdict(ledger)) != row['ledger_sha256']: raise ValueError('cached ledger hash differs')
        periods.append({**row, 'ledger': asdict(ledger)})
    if digest(asdict(state)) != saved['final_state_sha256']: raise ValueError('cached terminal state differs')
    return {'path_id': task['path_id'], 'status': 'completed', 'task': task, 'periods': periods,
            'final_state_sha256': digest(asdict(state)), 'totals': totals(periods, case)}

def check_bindings(manifest):
    for group in ['source_sha256', 'input_sha256']:
        for name, want in manifest[group].items():
            p = (ROOT / name).resolve()
            if not p.is_relative_to(ROOT) or sha(p) != want: raise ValueError('changed bound input: '+name)
    if environment() != manifest['environment']: raise ValueError('environment differs')

def authorize(path):
    m = read(path); check_bindings(m)
    if m['status'] != 'ready_for_owner_hash_approval': raise ValueError('full-run draft is not execution-ready')
    receipt = read(HERE / ('owner_approval_' + m['mode'] + '.json'))
    if receipt.get('decision') != 'owner_approved_paired_commitment_'+m['mode']+'_r1' or receipt.get('execution_manifest_sha256') != sha(path):
        raise PermissionError('exact owner-named manifest approval required')
    if m['mode'] == 'study':
        for name,want in m['prerequisite_sha256'].items():
            if sha(ROOT/name) != want: raise ValueError('prerequisite changed')
        if not m.get('numerical_clearance_accepted') or not m.get('measured_caps') or not m.get('cache_certified'):
            raise ValueError('reviewed numerical clearance, profile and cache certification required')
    return m

def prepare():
    items = catalog(); all_tasks = make_tasks(items); records = saved_records(items); lookup = {x['case_id']:x for x in items}
    cache = []
    with forbid_solves():
        for task in all_tasks:
            if task['cached_original']:
                saved, locator = records[task['case_id'],task['cell']]
                replayed = replay_cached(lookup[task['case_id']],task,saved)
                cache.append({'path_id':task['path_id'], **locator, 'replay_totals_sha256':digest(replayed['totals']),
                    'status':'physical_replay_passed_numerical_clearance_pending'})
    write(HERE/'CACHE_REPLAY_PREFLIGHT.json',{'paths':len(cache),'periods':len(cache)*20,'mip_solves':0,'paths_checked':cache,
        'scientific_cache_reuse_approved':False})
    dependencies=set()
    def visit(module):
        if module in dependencies:return
        path=ROOT/f'src/sn/{module}.py'
        if not path.is_file():raise ValueError('missing scientific import '+module)
        dependencies.add(module)
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.ImportFrom):
                if node.level==1:
                    for name in ([node.module.split('.')[0]] if node.module else [x.name for x in node.names]):visit(name)
                elif node.module and node.module.startswith('sn.'):
                    visit(node.module.split('.')[1])
    for module in SCIENTIFIC:visit(module)
    source = [f'src/sn/{x}.py' for x in sorted(dependencies)] + [str(p.relative_to(ROOT)) for p in sorted(HERE.glob('*.py'))]
    inputs = ['configs/proposed-v3-allocation.json','configs/v3-design/selection-freeze.json',
              'configs/v3-design/manifest.json','docs/V3_SINGLE_SOLVE_R3_PROTOCOL.md',
              'paper/paired_commitment_r1/CACHE_REPLAY_PREFLIGHT.json']
    inputs += [f'results/{d}/{f}' for d in DATASETS for f in ['result.json','verification.json','progress.jsonl']]
    inputs += [f"configs/v3-design/cases/candidate-0/{x['case_id']}.json" for x in items]
    profile = []
    for family in FAMILIES:
        for size in ['small','large']:
            candidates = [x for x in items if x['family']==family and x['size']==size]
            # Alternate desired changed commitment by size when the stratum permits it.
            want_original = 'horizon' if size == 'small' else 'finite'
            item = sorted(candidates, key=lambda x:(x['factors']['commitment']!=want_original,x['case_id']))[0]
            cell = 'C00' if size=='small' else 'A050'
            profile.append(next(t for t in all_tasks if t['case_id']==item['case_id'] and not t['cached_original'] and t['cell']==cell))
    for mode, tasks in [('profile',profile),('study',all_tasks)]:
        caps = {'paths':len(tasks), 'new_paths':len(tasks) if mode=='profile' else 168,
            'maximum_mip_phases':200 if mode=='profile' else 3360,'per_mip_seconds':30,
            'wall_seconds':600 if mode=='profile' else 900,'peak_rss_mib':512,
            'saved_bytes':134217728 if mode=='profile' else 536870912,'retries':0}
        m = {'schema':1,'mode':mode,'status':'ready_for_owner_hash_approval' if mode=='profile' else 'draft_blocked_pending_measured_caps_and_numerical_clearance',
            'catalog':items,'tasks':tasks,'source_sha256':{x:sha(ROOT/x) for x in source},'input_sha256':{x:sha(ROOT/x) for x in inputs},
            'environment':environment(),'planner_sha256':PLANNER_HASH,'caps':caps,'output':f'paper/paired_commitment_r1/{mode}_execution',
            'parameters':{'purchase_price':1,'margin_r_fractions':MARGINS,'production_cost':'1-r, identical between paired commitments',
                'penalty_kappa':PENALTIES,'liability_multiplier':1,'fixed_contradiction_cost':0,'demand_multiplier':1,
                'sign_tolerance':'1/100000000','alpha':[0,.25,.5,.75,1],'cells':CELLS,
                'reference':'same network and same commitment C00','gain':'r*(P_path-P_C00)-kappa*(A_path-A_C00)',
                'accepted_shortfall':'ledger primary_shortfall minus pre_horizon_order_shortfall',
                'weights':['arithmetic network mean','equal weight on each of five family means']},
            'report_policy':{'all_networks_all_levels':True,'no_exclusion_on_qualification':True,'no_tests_or_intervals':True,
                'paired_signs':'horizon minus finite, tolerance 1e-8','lowest_margin':'lowest tested 0.05 level with G>1e-8; none if absent; no interpolation',
                'gain_switch':'finite G<=1e-8 and horizon G>1e-8 at fixed alpha,r,kappa',
                'qualification_timing':'report selected, date, activation, expiry, payment and post-recovery units'},
            'profile_selection':'metadata-only first preferred opposite-contract case in each family-size; small C00, large alpha .50',
            'numeric_rule':'frozen planner, presolve off threads 1; fail on RuntimeWarning, nonfinite summary, certificate or objective consistency failure',
            'failure_policy':'first failure stops, full error and partial evidence retained, no retry',
            'prerequisite_sha256':{},'numerical_clearance_accepted':False,'measured_caps':False,'cache_certified':False,
            'cap_finalization_rule':'after reviewed complete profile: wall=max(900,ceil(2*profile_wall*168/10/60)*60); RSS=max(512,ceil(2*profile_RSS/64)*64); storage max(512 MiB, measured whole scientific record forecast with 2x headroom); per-MIP 30, phases 3360 unchanged; new hash approval required',
            'private_access':False,'m5_paused':True,'llm_paused':True,'equilibrium_grid_paused':True}
        write(HERE/f'{mode}_manifest.json',m)
    csvwrite(HERE/'PATH_INVENTORY.csv', [{k:t[k] for k in ['path_id','case_id','family','size','commitment','cell','schedule','alpha','cached_original','original_content_sha256','variant_sha256']} for t in all_tasks])
    print(json.dumps({'status':'prepared_unrun','cached_replays':len(cache),'new_solves':0,
                      'profile_manifest_sha256':sha(HERE/'profile_manifest.json'),'full_draft_manifest_sha256':sha(HERE/'study_manifest.json')}))

if __name__ == '__main__': prepare()
