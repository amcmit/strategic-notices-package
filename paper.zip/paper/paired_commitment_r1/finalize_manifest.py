"""After reviewed profile and numerical disposition, rebind full proposal only."""
from pathlib import Path
import argparse, math
from common import *

def finalize(disposition_path):
    profile=HERE/'profile_manifest.json';m=read(profile);check_bindings(m)
    out=ROOT/m['output'];r=read(out/'result.json');v=read(out/'verification.json')
    if r['status']!='completed' or r['failures'] or r['completed_paths']!=10 or r['mip_phases']!=200 or r['manifest_sha256']!=sha(profile) or v['status']!='verified' or v['result_sha256']!=sha(out/'result.json'):
        raise ValueError('complete bound verified profile required')
    disposition_path=disposition_path.resolve()
    if not disposition_path.is_relative_to(ROOT):raise ValueError('reviewed disposition must be in repository')
    disposition=read(disposition_path)
    if disposition.get('decision')!='owner_accepted_numerical_disposition_for_paired_study':raise ValueError('owner numerical disposition required')
    m=read(HERE/'study_manifest.json');check_bindings(m)
    m['status']='ready_for_owner_hash_approval';m['measured_caps']=True;m['cache_certified']=True;m['numerical_clearance_accepted']=True
    m['caps']['wall_seconds']=max(900,60*math.ceil(2*r['elapsed_seconds']*168/10/60))
    m['caps']['peak_rss_mib']=max(512,64*math.ceil(2*r['peak_rss_mib']/64))
    # Profile omits ledgers. Scientific storage is bounded by the saved original
    # complete-record byte maximum, scaled over all 336 records with 4x headroom.
    original=saved_records(m['catalog']);maximum=max(len(canonical(row)) for row,_ in original.values())
    m['caps']['saved_bytes']=max(536870912,4*maximum*336)
    prerequisites=[profile,out/'result.json',out/'verification.json',HERE/'owner_approval_profile.json',disposition_path]
    m['prerequisite_sha256']={str(p.relative_to(ROOT)):sha(p) for p in prerequisites}
    m['cap_measurements']={'profile_seconds':r['elapsed_seconds'],'profile_peak_rss_mib':r['peak_rss_mib'],'saved_original_max_record_bytes':maximum,
        'measurement_limit':'time excludes full report generation; 900-second floor retained; profile record storage excludes ledgers, so fourfold original-record allowance used'}
    destination=HERE/'study_execution_manifest.json'
    if destination.exists():raise FileExistsError('do not overwrite execution proposal')
    write(destination,m);print(sha(destination))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--accepted-disposition',type=Path,required=True);a=p.parse_args();finalize(a.accepted_disposition)
