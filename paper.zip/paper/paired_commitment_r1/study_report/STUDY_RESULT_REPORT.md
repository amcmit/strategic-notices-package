# Paired commitment study: verified result

14 November 2026.

At κ = 5, α = 1 and r = 0.50, changing only the commitment rule turns 16 of the 24 networks from non-positive to positive supplier gain. None moves the other way. Truthful qualification and its date remain unchanged in every network. Both contracts select truthful qualification in all 24 cases.

Under full belief, every network has more displaced backup and additional primary deliveries under the longer commitment, with unchanged accepted shortfall and lower buyer harm. At weaker beliefs the longer contract also changes whether the false notice suppresses qualification. At α = 0.50 and r = 0.50, five networks switch into positive gain, yet the through-horizon mean remains negative. The complete grid includes the null and negative results.

Source: `paper/paired_commitment_r1/study_execution/descriptive_report.json`, SHA-256 `e2cab9704d002158e0b7c75a1ce86356b5124c1949445437ce2ba68e3de1968f`. Each full CSV row includes its source hash and zero-based JSON pointer. All results are descriptive public-design comparisons; no tests or intervals are added.

## 1. Every network at κ = 5, full belief

Gain signs below use r = 0.50; the lowest-r columns search all 21 tested margins. The gain-sign supplement gives every margin and belief level at κ = 5 and all other penalties. Q dates are C00 qualification dates under finite / through-horizon commitment.

| Network suffix | Truthful Q dates F / H | Finite G(0.5,5) | Horizon G(0.5,5) | Finite lowest r | Horizon lowest r |
| --- | --- | --- | --- | --- | --- |
| assembly-large-0 | [0] / [0] | -3.500 (-) | 2.500 (+) | none | 0.350 |
| assembly-large-1 | [0] / [0] | -4.000 (-) | 3.500 (+) | none | 0.300 |
| assembly-large-2 | [1] / [1] | 1.500 (+) | 8.000 (+) | 0.050 | 0.050 |
| assembly-small-0 | [0] / [0] | -4.000 (-) | 3.000 (+) | none | 0.350 |
| assembly-small-1 | [0] / [0] | 1.500 (+) | 8.000 (+) | 0.050 | 0.050 |
| distribution-large-0 | [0] / [0] | -4.000 (-) | 3.125 (+) | none | 0.350 |
| distribution-large-1 | [1] / [1] | 1.500 (+) | 7.625 (+) | 0.050 | 0.050 |
| distribution-small-0 | [0] / [0] | 1.500 (+) | 7.875 (+) | 0.050 | 0.050 |
| distribution-small-1 | [0] / [0] | 1.500 (+) | 7.375 (+) | 0.050 | 0.050 |
| layered_dual-large-0 | [0] / [0] | -4.000 (-) | 2.625 (+) | none | 0.350 |
| layered_dual-large-1 | [0] / [0] | 1.500 (+) | 7.625 (+) | 0.050 | 0.050 |
| layered_dual-small-0 | [0] / [0] | -3.500 (-) | 2.625 (+) | none | 0.350 |
| layered_dual-small-1 | [0] / [0] | -3.500 (-) | 2.125 (+) | none | 0.400 |
| layered_dual-small-2 | [0] / [0] | -4.000 (-) | 3.125 (+) | none | 0.350 |
| planted-large-0 | [0] / [0] | -4.000 (-) | 2.625 (+) | none | 0.350 |
| planted-large-1 | [0] / [0] | -3.500 (-) | 2.625 (+) | none | 0.350 |
| planted-large-2 | [0] / [0] | 1.625 (+) | 7.125 (+) | 0.050 | 0.050 |
| planted-small-0 | [0] / [0] | -3.500 (-) | 2.000 (+) | none | 0.400 |
| planted-small-1 | [0] / [0] | -4.000 (-) | 3.000 (+) | none | 0.350 |
| serial-large-0 | [0] / [0] | 1.500 (+) | 7.375 (+) | 0.050 | 0.050 |
| serial-large-1 | [0] / [0] | -4.000 (-) | 3.375 (+) | none | 0.300 |
| serial-small-0 | [0] / [0] | -4.000 (-) | 3.500 (+) | none | 0.300 |
| serial-small-1 | [0] / [0] | -4.000 (-) | 3.000 (+) | none | 0.350 |
| serial-small-2 | [0] / [0] | -3.500 (-) | 3.000 (+) | none | 0.350 |

Eight networks have positive gain under both contracts at every tested r ≥ 0.05 and κ = 5 under full belief; their accepted shortfall is zero. The other sixteen never become profitable under the finite contract on r ∈ [0,1] at κ = 5. Their through-horizon thresholds are 0.30, 0.35 or 0.40. No threshold is interpolated.

## 2. κ = 5 across belief levels

The next table uses r = 0.50. Positive and switch counts are raw network counts. Both arithmetic and equal-family means are reported.

| α | Weighting | Finite mean G | Horizon mean G | Positive F / H | Non-positive→positive | Positive→non-positive |
| --- | --- | --- | --- | --- | --- | --- |
| 0 | equal_family | 0.000 | 0.000 | 0 / 0 | 0 | 0 |
| 0 | arithmetic | 0.000 | 0.000 | 0 / 0 | 0 | 0 |
| 0.25 | equal_family | -2.500 | -2.450 | 0 / 0 | 0 | 0 |
| 0.25 | arithmetic | -2.552 | -2.500 | 0 / 0 | 0 | 0 |
| 0.5 | equal_family | -2.500 | -0.771 | 0 / 5 | 5 | 0 |
| 0.5 | arithmetic | -2.552 | -0.833 | 0 / 5 | 5 | 0 |
| 0.75 | equal_family | -2.225 | 3.025 | 2 / 17 | 15 | 0 |
| 0.75 | arithmetic | -2.281 | 2.880 | 2 / 17 | 15 | 0 |
| 1 | equal_family | -1.950 | 4.530 | 8 / 24 | 16 | 0 |
| 1 | arithmetic | -2.036 | 4.448 | 8 / 24 | 16 | 0 |

For κ = 5 and α = 1, the switch count is zero through r = 0.25, three at r = 0.30, fourteen at r = 0.35, and sixteen at each tested level from 0.40 to 1.00. There are no reverse switches anywhere in the full α × r × κ grid.

## 3. Paired physical effects

Means below are through-horizon minus finite. They are invariant to repricing in r and κ. Every network and α appears in [PAIRED_PHYSICAL.md](PAIRED_PHYSICAL.md); the full signed rows are in PAIRED_GRID.csv.

| α | Weighting | Δb | Δ(ΔD) | Δ accepted shortfall | Δ buyer harm |
| --- | --- | --- | --- | --- | --- |
| 0 | equal_family | 0.000 | 0.000 | 0.000 | 0.000 |
| 0 | arithmetic | 0.000 | 0.000 | 0.000 | 0.000 |
| 0.25 | equal_family | 0.000 | 0.000 | -0.010 | 0.000 |
| 0.25 | arithmetic | 0.000 | 0.000 | -0.010 | 0.000 |
| 0.5 | equal_family | 3.650 | 3.357 | -0.010 | 1.925 |
| 0.5 | arithmetic | 3.625 | 3.333 | -0.010 | 1.908 |
| 0.75 | equal_family | 11.770 | 10.800 | 0.030 | 7.790 |
| 0.75 | arithmetic | 11.583 | 10.635 | 0.031 | 7.558 |
| 1 | equal_family | 13.410 | 12.960 | 0.000 | -3.809 |
| 1 | arithmetic | 13.417 | 12.969 | 0.000 | -3.809 |

At α = 1, all 24 paired b and ΔD changes are positive, all shortfall changes are zero, and all buyer-harm changes are negative. The lower harm is a difference relative to each contract’s own truthful buyer cost. It does not imply that longer commitments reduce buyer harm at all beliefs: mean harm rises at α = 0.50 and 0.75.

At α = 0.75, `planted-large-0` has 41 grid points where the longer contract reduces supplier gain. Its accepted shortfall rises from 0.25 to 1 while additional deliveries rise from 0 to 15.25. At sufficiently low r relative to κ, the additional liability outweighs the added margin. These are reductions between non-positive outcomes, so none is a positive-to-non-positive switch. Every such row is retained in NEGATIVE_PAIRED_GAIN_ROWS.csv.

## 4. All penalty levels and all network-level outcomes

- [NETWORK_GAIN_SIGNS_AND_THRESHOLDS.md](NETWORK_GAIN_SIGNS_AND_THRESHOLDS.md): every network, both contracts, every α and κ, all 21 gain signs, and lowest tested positive r.
- [GAIN_SWITCH_COUNTS.md](GAIN_SWITCH_COUNTS.md): both switch directions at every α, r and κ.
- NETWORK_GRID.csv: all 35,280 network/contract/α/r/κ rows, with exact rational gains.
- PAIRED_GRID.csv: all 17,640 paired rows, including signed physical changes and both gains.
- GROUP_GRID.csv and PAIRED_GROUP_GRID.csv: all arithmetic and equal-family means.
- CELL_TOTALS.csv: all 336 paths, including all four schedule-belief cells.
- DECOMPOSITION.csv and DECOMPOSITION_MEANS.csv: every four-cell decomposition.
- PHYSICAL.csv and BELIEF_PATTERNS.csv: every physical comparison and suppression pattern.
- Files ending in _K5.csv provide the complete κ = 5 slices.

The table below is a readable κ overview at r = 0.50. The linked switch table and CSVs retain every tested margin. Entries give non-positive→positive / positive→non-positive counts.

| κ | α = 0 | α = 0.25 | α = 0.5 | α = 0.75 | α = 1 |
| --- | --- | --- | --- | --- | --- |
| 5 | 0 / 0 | 0 / 0 | 5 / 0 | 15 / 0 | 16 / 0 |
| 0 | 0 / 0 | 0 / 0 | 5 / 0 | 12 / 0 | 0 / 0 |
| 1 | 0 / 0 | 0 / 0 | 5 / 0 | 14 / 0 | 10 / 0 |
| 2 | 0 / 0 | 0 / 0 | 5 / 0 | 15 / 0 | 16 / 0 |
| 3 | 0 / 0 | 0 / 0 | 5 / 0 | 15 / 0 | 16 / 0 |
| 10 | 0 / 0 | 0 / 0 | 2 / 0 | 5 / 0 | 0 / 0 |
| 20 | 0 / 0 | 0 / 0 | 2 / 0 | 5 / 0 | 0 / 0 |

At κ = 0 and full belief both contracts are profitable in all 24 networks for each positive tested r, so the count of sign switches is zero. At κ = 20 and full belief, neither contract makes the sixteen shortfall-positive networks profitable on the tested margin grid. The eight zero-shortfall networks remain profitable for positive r. These cases show why a zero switch count has to be read alongside the gain signs.

## 5. Execution and verification

Completed 336 paths: 168 cached and 168 new. The single run used 3360 MIPs, 37.775 seconds and 326.047 MiB peak RSS. Maximum measured phase time was 0.021272 seconds. No failures, new numerical warnings or hand-off corrections occurred. All 3,360 new certificates reported zero absolute and relative gap; the maximum objective-recomputation difference was zero.

The independent verifier ran once, passed all 336 paths and every report array, and used zero solves. There were no retries. The historical fractional-belief warning remains unresolved and disclosed under the owner-accepted limited disposition. This successful run does not retrospectively clear that warning.

## 6. Provenance and scope

- Execution manifest: `733914c13e483eb993a6cf20e10ab39b0f9f07fe8147f1118b0ca6aa55899064`.
- Approval receipt: `40864492dfed2744bb1ef6436304d2686a36bf2cdbbec526ccd29bdbf05e4a86`.
- Result: `b913b12faef2f9e540d91fe8dbc0b009e6a46983f1bd28d89cb83c3d2fe9dadb`.
- Independent verification: `05f7b68ff8dcae03e54ad57048a532e04646ff45e6b4864250be0855f2488b50`.
- Verified descriptive report: `e2cab9704d002158e0b7c75a1ce86356b5124c1949445437ce2ba68e3de1968f`.

Only public design paths were accessed. The report changes no study source, protocol, frozen artifact, manuscript or analysis rule. All 63 execution bindings and all 260 paper input hashes still match. No private access or hosting occurred. M5, the LLM arm and the equilibrium grid remain paused. Manuscript integration awaits owner review.
