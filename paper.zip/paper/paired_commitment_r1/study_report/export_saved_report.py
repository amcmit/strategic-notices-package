"""Read-only reductions/formatting of the approved, independently verified study.

Standard library only. Does not import study code, replay paths, optimize, or
compute tests/intervals. Execution evidence is never written by this exporter.
"""
from pathlib import Path
import csv
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
PACKAGE = HERE.parent
RUN = PACKAGE / 'study_execution'
EXPECTED_MANIFEST = '733914c13e483eb993a6cf20e10ab39b0f9f07fe8147f1118b0ca6aa55899064'
EXPECTED_RESULT = 'b913b12faef2f9e540d91fe8dbc0b009e6a46983f1bd28d89cb83c3d2fe9dadb'
EXPECTED_VERIFICATION = '05f7b68ff8dcae03e54ad57048a532e04646ff45e6b4864250be0855f2488b50'
EXPECTED_REPORT = 'e2cab9704d002158e0b7c75a1ce86356b5124c1949445437ce2ba68e3de1968f'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def fmt(x):
    return 'none' if x is None else f'{x:.3f}'


def short(cid):
    return cid.removeprefix('v3-c0-r1-interior-')


def mdtable(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |',
                      '| ' + ' | '.join(['---'] * len(headers)) + ' |'] +
                     ['| ' + ' | '.join(map(str, row)) + ' |' for row in rows]) + '\n'


def csvwrite(path, rows):
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        for row in rows:
            w.writerow({k: json.dumps(v, separators=(',', ':')) if isinstance(v, (list, dict)) else
                        'none' if v is None else v for k, v in row.items()})


def main():
    for p, expected in [(PACKAGE / 'study_execution_manifest.json', EXPECTED_MANIFEST),
                        (RUN / 'result.json', EXPECTED_RESULT),
                        (RUN / 'verification.json', EXPECTED_VERIFICATION),
                        (RUN / 'descriptive_report.json', EXPECTED_REPORT)]:
        assert sha(p) == expected, str(p)
    result, verification, data = [read(RUN / f) for f in
                                 ('result.json', 'verification.json', 'descriptive_report.json')]
    assert result['status'] == 'completed' and not result['failures']
    assert verification['status'] == 'verified' and verification['result_sha256'] == EXPECTED_RESULT
    for rel, expected in result['files'].items():
        assert sha(RUN / rel) == expected, rel
    manifest = read(PACKAGE / 'study_execution_manifest.json')
    for group in ('source_sha256', 'input_sha256', 'prerequisite_sha256'):
        for rel, expected in manifest[group].items():
            assert sha(ROOT / rel) == expected, rel
    pins = read(ROOT / 'paper/paper_inputs.json')['inputs']
    for rel, expected in pins.items():
        assert sha(ROOT / rel) == expected, rel

    source = str((RUN / 'descriptive_report.json').relative_to(ROOT))
    exports = []
    for key, count in verification['report_rows_checked'].items():
        rows = data[key]
        assert len(rows) == count
        annotated = [{'source_file': source, 'source_sha256': EXPECTED_REPORT,
                      'source_pointer': f'/{key}/{i}', **row} for i, row in enumerate(rows)]
        target = HERE / (key.upper() + '.csv')
        csvwrite(target, annotated)
        exports.append({'file': target.name, 'rows': count, 'source_array': key,
                        'source_columns': list(rows[0]),
                        'mapping': 'CSV data row i+1 maps to zero-based JSON pointer /array/i; columns keep their source names.'})
        if key in ('network_grid', 'paired_grid', 'network_thresholds', 'group_grid', 'paired_group_grid'):
            sub = [r for r in annotated if r['kappa'] == 5]
            csvwrite(HERE / (key.upper() + '_K5.csv'), sub)

    ids = sorted({x['case_id'] for x in data['physical']})
    alphas = manifest['parameters']['alpha']
    penalties = [5, 0, 1, 2, 3, 10, 20]  # requested emphasis first; all levels retained
    margins = [i / 20 for i in range(21)]
    phys = {(x['case_id'], x['commitment'], x['alpha']): x for x in data['physical']}
    thresholds = {(x['case_id'], x['commitment'], x['alpha'], x['kappa']): x for x in data['network_thresholds']}
    grid = {(x['case_id'], x['commitment'], x['alpha'], x['r'], x['kappa']): x for x in data['network_grid']}
    paired = {(x['case_id'], x['alpha'], x['r'], x['kappa']): x for x in data['paired_grid']}
    groups = {(x['commitment'], x['alpha'], x['r'], x['kappa'], x['weighting']): x for x in data['group_grid']}
    pgroups = {(x['alpha'], x['r'], x['kappa'], x['weighting']): x for x in data['paired_group_grid']}
    cell = {(x['case_id'], x['commitment'], x['cell']): x for x in data['cell_totals']}
    assert len(ids) == 24 and len(grid) == 35280 and len(paired) == 17640
    assert all(x['positive_to_nonpositive_count'] == 0 for x in data['paired_group_grid'])
    assert all(phys[cid, c, 0]['truth_qualification_dates'] == phys[cid, c, a]['truth_qualification_dates']
               for cid in ids for c in ('finite', 'horizon') for a in alphas)

    truth_rows = []
    for cid in ids:
        lo, hi = cell[cid, 'finite', 'C00'], cell[cid, 'horizon', 'C00']
        truth_rows.append({'case_id': cid, 'finite_qualification_dates': lo['qualification_dates'],
                           'horizon_qualification_dates': hi['qualification_dates'],
                           'selected_changed': bool(lo['qualification_dates']) != bool(hi['qualification_dates']),
                           'date_changed': lo['qualification_dates'] != hi['qualification_dates'],
                           'source_file': source, 'source_sha256': EXPECTED_REPORT,
                           'source_rows': [data['cell_totals'].index(lo), data['cell_totals'].index(hi)],
                           'source_column': 'qualification_dates'})
    csvwrite(HERE / 'TRUTHFUL_QUALIFICATION.csv', truth_rows)

    note = (f'Source: `{source}`, SHA-256 `{EXPECTED_REPORT}`. '
            'Each full CSV row includes its source hash and zero-based JSON pointer. '
            'All results are descriptive public-design comparisons; no tests or intervals are added.\n\n')
    signs = {'negative': '-', 'numerical_zero': '0', 'positive': '+'}
    out = ['# Every network: gain signs and tested margin thresholds\n\n', note,
           'Each sign string has 21 entries in this exact order: ' + ', '.join(f'{r:.2f}' for r in margins) + '.\n\n',
           '`-` means G < -1e-8; `0` means |G| <= 1e-8; `+` means G > 1e-8. '
           'A threshold of `none` means no tested margin gives positive gain. No interpolation. '
           'Full case IDs are the displayed suffix prefixed with `v3-c0-r1-interior-`.\n\n']
    for k in penalties:
        for a in alphas:
            out.append(f'## κ = {k}, α = {a:g}\n\n')
            rows = []
            for cid in ids:
                pp = ['`' + ''.join(signs[grid[cid, c, a, r, k]['gain_sign']] for r in margins) + '`'
                      for c in ('finite', 'horizon')]
                ts = [fmt(thresholds[cid, c, a, k]['lowest_tested_r_positive']) for c in ('finite', 'horizon')]
                rows.append([short(cid), pp[0], pp[1], *ts])
            out.append(mdtable(['Network', 'Finite signs', 'Through-horizon signs', 'Finite lowest r', 'Through-horizon lowest r'], rows) + '\n')
    (HERE / 'NETWORK_GAIN_SIGNS_AND_THRESHOLDS.md').write_text(''.join(out))

    out = ['# Gain-switch counts: every α, r and κ\n\n', note,
           'Each cell gives **non-positive→positive / positive→non-positive** counts when changing '
           'finite to through-horizon. Counts are unweighted networks out of 24.\n\n']
    for k in penalties:
        out.append(f'## κ = {k}\n\n')
        rows = []
        for r in margins:
            ss = [pgroups[a, r, k, 'arithmetic'] for a in alphas]
            rows.append([f'{r:.2f}'] + [f"{x['nonpositive_to_positive_count']} / {x['positive_to_nonpositive_count']}" for x in ss])
        out.append(mdtable(['r'] + [f'α = {a:g}' for a in alphas], rows) + '\n')
    (HERE / 'GAIN_SWITCH_COUNTS.md').write_text(''.join(out))

    out = ['# Physical paired differences: every network and α\n\n', note,
           'Every difference is through-horizon minus finite, with each false-notice effect measured '
           'against C00 under that same contract. A is accepted shortfall, excluding the pre-horizon order. '
           'These physical values are invariant across r and κ because repricing leaves the paths fixed. '
           'The exporter checks that invariance on every saved grid row. Q is false-notice qualification; '
           'Q_T is truthful qualification.\n\n']
    fields = ['b', 'delta_d', 'accepted_shortfall', 'delta_shortfall', 'buyer_harm',
              'qualification_selected', 'truth_qualification_selected']
    for a in alphas:
        rows = []
        for cid in ids:
            x = paired[cid, a, 0.5, 5]
            for r in margins:
                for k in penalties:
                    assert all(paired[cid, a, r, k]['change_' + f] == x['change_' + f] for f in fields)
            rows.append([short(cid)] + [fmt(x['change_' + f]) for f in fields])
        out += [f'## α = {a:g}\n\n', mdtable(['Network', 'Δb', 'Δ(ΔD)', 'ΔA', 'Δ(dA)', 'Δ buyer harm', 'ΔQ', 'ΔQ_T'], rows), '\n']
    (HERE / 'PAIRED_PHYSICAL.md').write_text(''.join(out))

    negative = [x for x in data['paired_grid'] if x['sign_gain'] == 'negative']
    csvwrite(HERE / 'NEGATIVE_PAIRED_GAIN_ROWS.csv', negative)
    records = [read(p) for p in sorted(RUN.glob('path-*.json'))]
    new = [x for x in records if not x['task']['cached_original']]
    periods = [p for x in new for p in x['periods']]
    cs = [x['certificate'] for x in periods]
    resources = {'completed_paths': result['completed_paths'], 'new_paths': len(new),
                 'cached_paths': len(records) - len(new), 'mip_phases': result['mip_phases'],
                 'elapsed_seconds': result['elapsed_seconds'], 'peak_rss_mib': result['peak_rss_mib'],
                 'maximum_phase_seconds': max(result['phase_seconds']),
                 'summed_phase_seconds': sum(result['phase_seconds']),
                 'new_numerical_warnings': sum(len(p.get('warnings', [])) for p in periods),
                 'new_handoff_corrections': sum(len(p['handoff_corrections']) for p in periods),
                 'new_certificate_max_absolute_gap': max(abs(c['primal'] - c['dual']) for c in cs),
                 'new_certificate_max_relative_gap': max(c['relative_gap'] for c in cs),
                 'new_max_objective_recomputation_difference': max(p['objective_check']['objective']['solver_difference'] for p in periods),
                 'execution_saved_bytes': sum(p.stat().st_size for p in RUN.iterdir() if p.is_file()),
                 'failures': result['failures'], 'verifier_runs': 1, 'verifier_new_solves': 0}
    write_json(HERE / 'RESOURCE_SUMMARY.json', resources)

    out = ['# Paired commitment study: verified result\n\n14 November 2026.\n\n',
           'At κ = 5, α = 1 and r = 0.50, changing only the commitment rule turns '
           '16 of the 24 networks from non-positive to positive supplier gain. None moves the other way. '
           'Truthful qualification and its date remain unchanged in every network. '
           'Both contracts select truthful qualification in all 24 cases.\n\n',
           'Under full belief, every network has more displaced backup and additional primary deliveries '
           'under the longer commitment, with unchanged accepted shortfall and lower buyer harm. '
           'At weaker beliefs the longer contract also changes whether the false notice suppresses qualification. '
           'At α = 0.50 and r = 0.50, five networks switch into positive gain, yet the through-horizon mean remains negative. '
           'The complete grid includes the null and negative results.\n\n', note,
           '## 1. Every network at κ = 5, full belief\n\n',
           'Gain signs below use r = 0.50; the lowest-r columns search all 21 tested margins. '
           'The gain-sign supplement gives every margin and belief level at κ = 5 and all other penalties. '
           'Q dates are C00 qualification dates under finite / through-horizon commitment.\n\n']
    rows = []
    for cid in ids:
        lo, hi = [grid[cid, c, 1, 0.5, 5] for c in ('finite', 'horizon')]
        tr = next(x for x in truth_rows if x['case_id'] == cid)
        rows.append([short(cid), f"{tr['finite_qualification_dates']} / {tr['horizon_qualification_dates']}",
                     f"{fmt(lo['gain'])} ({signs[lo['gain_sign']]})", f"{fmt(hi['gain'])} ({signs[hi['gain_sign']]})",
                     fmt(thresholds[cid, 'finite', 1, 5]['lowest_tested_r_positive']),
                     fmt(thresholds[cid, 'horizon', 1, 5]['lowest_tested_r_positive'])])
    out += [mdtable(['Network suffix', 'Truthful Q dates F / H', 'Finite G(0.5,5)', 'Horizon G(0.5,5)', 'Finite lowest r', 'Horizon lowest r'], rows), '\n',
            'Eight networks have positive gain under both contracts at every tested r ≥ 0.05 and κ = 5 under full belief; '
            'their accepted shortfall is zero. The other sixteen never become profitable under the finite contract '
            'on r ∈ [0,1] at κ = 5. Their through-horizon thresholds are 0.30, 0.35 or 0.40. '
            'No threshold is interpolated.\n\n',
            '## 2. κ = 5 across belief levels\n\n',
            'The next table uses r = 0.50. Positive and switch counts are raw network counts. '
            'Both arithmetic and equal-family means are reported.\n\n']
    rows = []
    for a in alphas:
        for w in ('equal_family', 'arithmetic'):
            lo, hi = [groups[c, a, .5, 5, w] for c in ('finite', 'horizon')]
            pg = pgroups[a, .5, 5, w]
            rows.append([f'{a:g}', w, fmt(lo['mean_gain']), fmt(hi['mean_gain']),
                         f"{lo['gain_positive_count']} / {hi['gain_positive_count']}",
                         pg['nonpositive_to_positive_count'], pg['positive_to_nonpositive_count']])
    out += [mdtable(['α', 'Weighting', 'Finite mean G', 'Horizon mean G', 'Positive F / H', 'Non-positive→positive', 'Positive→non-positive'], rows), '\n',
            'For κ = 5 and α = 1, the switch count is zero through r = 0.25, three at r = 0.30, '
            'fourteen at r = 0.35, and sixteen at each tested level from 0.40 to 1.00. '
            'There are no reverse switches anywhere in the full α × r × κ grid.\n\n',
            '## 3. Paired physical effects\n\n',
            'Means below are through-horizon minus finite. They are invariant to repricing in r and κ. '
            'Every network and α appears in [PAIRED_PHYSICAL.md](PAIRED_PHYSICAL.md); '
            'the full signed rows are in PAIRED_GRID.csv.\n\n']
    rows = []
    for a in alphas:
        for w in ('equal_family', 'arithmetic'):
            x = pgroups[a, .5, 5, w]
            rows.append([f'{a:g}', w] + [fmt(x['mean_change_' + k]) for k in ('b', 'delta_d', 'accepted_shortfall', 'buyer_harm')])
    out += [mdtable(['α', 'Weighting', 'Δb', 'Δ(ΔD)', 'Δ accepted shortfall', 'Δ buyer harm'], rows), '\n',
            'At α = 1, all 24 paired b and ΔD changes are positive, all shortfall changes are zero, '
            'and all buyer-harm changes are negative. The lower harm is a difference relative to each '
            'contract’s own truthful buyer cost. It does not imply that longer commitments reduce buyer harm '
            'at all beliefs: mean harm rises at α = 0.50 and 0.75.\n\n',
            'At α = 0.75, `planted-large-0` has 41 grid points where the longer contract reduces supplier gain. '
            'Its accepted shortfall rises from 0.25 to 1 while additional deliveries rise from 0 to 15.25. '
            'At sufficiently low r relative to κ, the additional liability outweighs the added margin. '
            'These are reductions between non-positive outcomes, so none is a positive-to-non-positive switch. '
            'Every such row is retained in NEGATIVE_PAIRED_GAIN_ROWS.csv.\n\n',
            '## 4. All penalty levels and all network-level outcomes\n\n',
            '- [NETWORK_GAIN_SIGNS_AND_THRESHOLDS.md](NETWORK_GAIN_SIGNS_AND_THRESHOLDS.md): every network, '
            'both contracts, every α and κ, all 21 gain signs, and lowest tested positive r.\n',
            '- [GAIN_SWITCH_COUNTS.md](GAIN_SWITCH_COUNTS.md): both switch directions at every α, r and κ.\n',
            '- NETWORK_GRID.csv: all 35,280 network/contract/α/r/κ rows, with exact rational gains.\n',
            '- PAIRED_GRID.csv: all 17,640 paired rows, including signed physical changes and both gains.\n',
            '- GROUP_GRID.csv and PAIRED_GROUP_GRID.csv: all arithmetic and equal-family means.\n',
            '- CELL_TOTALS.csv: all 336 paths, including all four schedule-belief cells.\n',
            '- DECOMPOSITION.csv and DECOMPOSITION_MEANS.csv: every four-cell decomposition.\n',
            '- PHYSICAL.csv and BELIEF_PATTERNS.csv: every physical comparison and suppression pattern.\n',
            '- Files ending in _K5.csv provide the complete κ = 5 slices.\n\n',
            'The table below is a readable κ overview at r = 0.50. The linked switch table and CSVs '
            'retain every tested margin. Entries give non-positive→positive / positive→non-positive counts.\n\n']
    rows = [[str(k)] + [f"{pgroups[a,.5,k,'arithmetic']['nonpositive_to_positive_count']} / {pgroups[a,.5,k,'arithmetic']['positive_to_nonpositive_count']}" for a in alphas] for k in penalties]
    out += [mdtable(['κ'] + [f'α = {a:g}' for a in alphas], rows), '\n',
            'At κ = 0 and full belief both contracts are profitable in all 24 networks for each positive '
            'tested r, so the count of sign switches is zero. At κ = 20 and full belief, neither contract '
            'makes the sixteen shortfall-positive networks profitable on the tested margin grid. '
            'The eight zero-shortfall networks remain profitable for positive r. These cases show why '
            'a zero switch count has to be read alongside the gain signs.\n\n',
            '## 5. Execution and verification\n\n',
            f"Completed {result['completed_paths']} paths: 168 cached and 168 new. The single run used "
            f"{result['mip_phases']} MIPs, {result['elapsed_seconds']:.3f} seconds and "
            f"{result['peak_rss_mib']:.3f} MiB peak RSS. Maximum measured phase time was "
            f"{resources['maximum_phase_seconds']:.6f} seconds. No failures, new numerical warnings or "
            'hand-off corrections occurred. All 3,360 new certificates reported zero absolute and relative '
            'gap; the maximum objective-recomputation difference was zero.\n\n',
            'The independent verifier ran once, passed all 336 paths and every report array, and used '
            'zero solves. There were no retries. The historical fractional-belief warning remains '
            'unresolved and disclosed under the owner-accepted limited disposition. This successful '
            'run does not retrospectively clear that warning.\n\n',
            '## 6. Provenance and scope\n\n',
            f'- Execution manifest: `{EXPECTED_MANIFEST}`.\n',
            f'- Approval receipt: `{sha(PACKAGE / "owner_approval_study.json")}`.\n',
            f'- Result: `{EXPECTED_RESULT}`.\n',
            f'- Independent verification: `{EXPECTED_VERIFICATION}`.\n',
            f'- Verified descriptive report: `{EXPECTED_REPORT}`.\n\n',
            'Only public design paths were accessed. The report changes no study source, protocol, '
            'frozen artifact, manuscript or analysis rule. All 63 execution bindings and all 260 paper '
            'input hashes still match. No private access or hosting occurred. M5, the LLM arm and '
            'the equilibrium grid remain paused. Manuscript integration awaits owner review.\n']
    (HERE / 'STUDY_RESULT_REPORT.md').write_text(''.join(out))
    write_json(HERE / 'SOURCE_MAP.json', {'source_file': source, 'source_sha256': EXPECTED_REPORT,
               'tables': exports, 'derived_views': {
                   'NETWORK_GAIN_SIGNS_AND_THRESHOLDS.md': 'network_grid.gain_sign; network_thresholds.lowest_tested_r_positive; index by case/contract/alpha/kappa/r',
                   'GAIN_SWITCH_COUNTS.md': 'paired_group_grid counts, arithmetic weighting; identical network counts under both weightings',
                   'PAIRED_PHYSICAL.md': 'paired_grid.change_* at r=0.5,kappa=5; all other r,kappa checked equal',
                   'TRUTHFUL_QUALIFICATION.csv': 'cell_totals C00 qualification_dates; source row indices included',
                   'STUDY_RESULT_REPORT.md': 'network_grid; network_thresholds; group_grid; paired_group_grid; physical; cell_totals; run result and saved path certificates',
                   'RESOURCE_SUMMARY.json': 'result.json fields; saved path period certificate/warning/handoff/objective_check fields'},
               'display_precision': 'three decimals in Markdown; CSV values preserved from saved JSON',
               'no_new_solves_or_tests': True})
    write_json(HERE / 'REPORT_VALIDATION.json', {
        'status': 'verified_evidence_exported', 'execution_bindings_unchanged': 63,
        'paper_pins_unchanged': len(pins), 'row_counts_match_verifier': verification['report_rows_checked'],
        'all_networks': len(ids), 'all_alpha_levels': alphas, 'all_r_levels': margins,
        'all_kappa_levels': sorted(penalties), 'truthful_selected_changes': sum(x['selected_changed'] for x in truth_rows),
        'truthful_date_changes': sum(x['date_changed'] for x in truth_rows),
        'physical_repricing_invariance_checked': True,
        'negative_paired_gain_rows_retained': len(negative),
        'positive_to_nonpositive_grid_count': sum(x['positive_to_nonpositive'] for x in data['paired_grid']),
        'reporting_only': True, 'study_verifier_rerun': False})
    write_json(HERE / 'HASHES.json', {str(p.relative_to(ROOT)): sha(p) for p in sorted(HERE.iterdir())
                                   if p.is_file() and p.name != 'HASHES.json'})
    print(json.dumps({'status': 'report_exported', 'files': len(list(HERE.iterdir())),
                      'source_sha256': EXPECTED_REPORT, 'all_networks': len(ids)}, indent=2))


if __name__ == '__main__':
    main()
