"""Independent saved-action replay and descriptive-table verifier. No solves.

Shares case hydration, binding/receipt utilities and declared constants. Does
not import the runner, its totals reducer, or its report builder.
"""
from pathlib import Path
from dataclasses import asdict
from fractions import Fraction
import argparse, json, math
from common import (ROOT,HERE,sha,read,write,digest,authorize,variant,forbid_solves,
                    MARGINS,PENALTIES,FAMILIES,ALPHA_CELLS,EPS,planner)
from sn.core import Action, Production, Shipment, Notice, Realization
from sn.core_v3 import initial_state_v3,step_v3
from sn.verify_belief_v3 import numeric_tree,certificate

def q(x):return Fraction(str(x))
def same(a,b):
    if isinstance(a,dict):return isinstance(b,dict) and set(a)==set(b) and all(same(a[k],b[k]) for k in a)
    if isinstance(a,(list,tuple)):return isinstance(b,(list,tuple)) and len(a)==len(b) and all(same(x,y) for x,y in zip(a,b))
    if isinstance(a,bool) or isinstance(b,bool):return type(a)==type(b) and a==b
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=1e-10*max(1,abs(a),abs(b))
    return a==b

def replay(case,task,record):
    state=initial_state_v3(case.network);dates=[];ledgers=[]
    schedule='major' if task['cell'] in ['C00','C01'] else 'minor'
    alpha={'C00':0,'C10':0,'C01':1,'C11':1,'A025':.25,'A050':.5,'A075':.75}[task['cell']]
    notice=Notice(case.long_capacity if schedule=='major' else case.short_capacity,schedule)
    if record['status']!='completed' or len(record['periods'])!=20:raise ValueError('incomplete saved path')
    for t,row in enumerate(record['periods']):
        if row['period']!=t:raise ValueError('period sequence')
        certificate(row['certificate'],current=not task['cached_original'] or task['cell'].startswith('A'))
        if 'planning_problem_sha256' in row:
            choices=[('long',1,case.long_capacity)] if t>=case.contract.revelation_period else [('short',alpha,case.short_capacity),('long',1-alpha,case.long_capacity)]
            call=planner.PlanningProblem(case.network,case.contract,notice,state,
                tuple(planner.Scenario(n,float(p),c) for n,p,c in choices if p),case.long_capacity[t],case.baseline_demand[t],case.baseline_demand,30,False,1)
            if digest(asdict(call))!=row['planning_problem_sha256']:raise ValueError('information-state hash mismatch')
        v=row['action']
        if set(v)!={'qualify','primary_order','spot_order','production','shipments'} or type(v['qualify']) is not bool:raise ValueError('action schema')
        a=Action(v['qualify'],v['primary_order'],v['spot_order'],tuple(Production(**x) for x in v['production']),tuple(Shipment(**x) for x in v['shipments']))
        state,ledger=step_v3(case.network,case.contract,notice,state,a,Realization(case.long_capacity[t],case.baseline_demand[t]),
                            revealed_schedule=case.long_capacity if t==case.contract.revelation_period else None)
        if numeric_tree(asdict(ledger))!=numeric_tree(row['ledger']):raise ValueError('physical ledger mismatch')
        if a.qualify:dates.append(t)
        ledgers.append(ledger)
    if digest(asdict(state))!=record['final_state_sha256'] or len(dates)>1:raise ValueError('final state or irreversible qualification')
    activation=dates[0]+case.contract.qualification_lead if dates else None
    expiry=min(20,activation+(case.contract.backup_commitment_periods or 20)) if dates else None
    sums=lambda name:math.fsum(getattr(l,name) for l in ledgers)
    result={'buyer_cost':sums('operating_cost'),'backup':sums('backup_delivered'),'primary':sums('primary_delivered'),
        'accepted_shortfall':math.fsum(l.primary_shortfall-l.pre_horizon_order_shortfall for l in ledgers),
        'pre_horizon_shortfall':sums('pre_horizon_order_shortfall'),'qualification_dates':dates,'activation':activation,'expiry_exclusive':expiry,
        'backup_payment':sums('backup_cost'),'post_recovery_backup':math.fsum(l.backup_delivered for l in ledgers if case.long_capacity[l.period]>0),
        'lost_sales':math.fsum(s.quantity for l in ledgers for s in l.lost_sales),'spot':sums('spot_delivered')}
    if not same(result,record['totals']):raise ValueError('path totals differ')
    return result

def label(x):return 'positive' if x>EPS else 'negative' if x < -EPS else 'numerical_zero'
def average(rows,field,weighting):
    value=lambda x:Fraction(x['gain_exact']) if field=='gain' and 'gain_exact' in x else Fraction(x['change_gain_exact']) if field=='change_gain' and 'change_gain_exact' in x else q(x[field])
    if weighting=='arithmetic':return sum((value(x) for x in rows),Fraction())/len(rows)
    if weighting!='equal_family':raise ValueError('unknown weighting')
    means=[]
    for fam in FAMILIES:
        selected=[x for x in rows if x['family']==fam]
        if not selected:raise ValueError('missing family')
        means.append(sum((value(x) for x in selected),Fraction())/len(selected))
    return sum(means,Fraction())/5

def check_report(report,bykey):
    ids=sorted({k[0] for k in bykey});metrics={};network={};paired={}
    expected_counts={'physical':240,'decomposition':48,'network_grid':35280,'paired_grid':17640,
        'network_thresholds':1680,'group_grid':2940,'paired_group_grid':1470,'belief_patterns':48,'cell_totals':336,'decomposition_means':4}
    for name,n in expected_counts.items():
        if len(report[name])!=n:raise ValueError('wrong report coverage: '+name)
    seen=set()
    for row in report['cell_totals']:
        key=row['case_id'],row['commitment'],row['cell']
        if key in seen or row['family']!=bykey[key]['task']['family']:raise ValueError('cell identity')
        seen.add(key)
        if not same({k:v for k,v in row.items() if k not in ['case_id','commitment','cell','family']},bykey[key]['totals']):raise ValueError('cell totals differ')
    def metric(cid,c,cell):
        truth=bykey[cid,c,'C00']['totals'];obs=bykey[cid,c,cell]['totals']
        return {'b':q(truth['backup'])-q(obs['backup']),'delta_d':q(obs['primary'])-q(truth['primary']),
            'delta_shortfall':q(obs['accepted_shortfall'])-q(truth['accepted_shortfall']),'accepted_shortfall':q(obs['accepted_shortfall']),
            'buyer_harm':q(obs['buyer_cost'])-q(truth['buyer_cost']),'qualification_selected':int(bool(obs['qualification_dates'])),
            'truth_qualification_selected':int(bool(truth['qualification_dates']))}
    for row in report['physical']:
        key=row['case_id'],row['commitment'],row['alpha']
        if key in metrics:raise ValueError('duplicate physical row')
        cid,c,alpha=key;truth=bykey[cid,c,'C00']['totals'];obs=bykey[cid,c,ALPHA_CELLS[alpha]]['totals'];values=metric(cid,c,ALPHA_CELLS[alpha])
        if any(row[k]!=bykey[cid,c,'C00']['task'][k] for k in ['family','size']):raise ValueError('physical metadata differs')
        if any(not same(row[k],float(v)) for k,v in values.items()):raise ValueError('physical effect differs')
        expected={'backup_suppressed':bool(truth['qualification_dates']) and not bool(obs['qualification_dates'])}
        for k in ['qualification_dates','activation','expiry_exclusive','backup_payment','post_recovery_backup']:
            expected[k]=obs[k];expected['truth_'+k]=truth[k]
        if any(not same(row[k],v) for k,v in expected.items()):raise ValueError('qualification/report timing differs')
        metrics[key]=values
    seen=set()
    for row in report['decomposition']:
        cid,c=row['case_id'],row['commitment'];cost={cell:q(bykey[cid,c,cell]['totals']['buyer_cost']) for cell in ['C00','C10','C01','C11']}
        if (cid,c) in seen or row['family']!=bykey[cid,c,'C00']['task']['family']:raise ValueError('decomposition identity')
        seen.add((cid,c))
        expect={'contractual':cost['C10']-cost['C00'],'belief':cost['C01']-cost['C00'],
                'interaction':cost['C11']-cost['C10']-cost['C01']+cost['C00'],'total':cost['C11']-cost['C00']}
        if any(not same(row[k],float(v)) for k,v in expect.items()):raise ValueError('decomposition differs')
    for row in report['network_grid']:
        cid,c,alpha,r,k=row['case_id'],row['commitment'],row['alpha'],row['r_fraction'],row['kappa'];key=cid,c,alpha,r,k
        if key in network or r not in MARGINS or k not in PENALTIES:raise ValueError('network grid key')
        mm=metrics[cid,c,alpha];gain=Fraction(r)*mm['delta_d']-k*mm['delta_shortfall']
        if any(row[x]!=bykey[cid,c,'C00']['task'][x] for x in ['family','size']) or row['r']!=float(Fraction(r)):raise ValueError('grid metadata differs')
        if any(not same(row[x],float(v)) for x,v in mm.items()) or not same(row['gain'],float(gain)) or Fraction(row['gain_exact'])!=gain or row['gain_sign']!=label(gain):raise ValueError('network repricing differs')
        network[key]=row
    keys=['b','delta_d','accepted_shortfall','delta_shortfall','buyer_harm','qualification_selected','truth_qualification_selected','gain']
    for row in report['paired_grid']:
        cid,alpha,r,k=row['case_id'],row['alpha'],row['r_fraction'],row['kappa'];key=cid,alpha,r,k
        if key in paired:raise ValueError('duplicate pair')
        lo,hi=[network[cid,c,alpha,r,k] for c in ['finite','horizon']]
        if row['family']!=lo['family'] or row['r']!=float(Fraction(r)):raise ValueError('pair metadata differs')
        for field in keys:
            d=(Fraction(hi['gain_exact'])-Fraction(lo['gain_exact'])) if field=='gain' else q(hi[field])-q(lo[field])
            if not same(row['change_'+field],float(d)) or row['sign_'+field]!=label(d):raise ValueError('paired difference differs')
            if field=='gain' and Fraction(row['change_gain_exact'])!=d:raise ValueError('exact paired gain differs')
        if not same(row['finite_gain'],lo['gain']) or not same(row['horizon_gain'],hi['gain']):raise ValueError('paired levels')
        if row['nonpositive_to_positive']!=(Fraction(lo['gain_exact'])<=EPS<Fraction(hi['gain_exact'])) or row['positive_to_nonpositive']!=(Fraction(hi['gain_exact'])<=EPS<Fraction(lo['gain_exact'])):raise ValueError('gain crossing differs')
        paired[key]=row
    seen=set()
    for row in report['network_thresholds']:
        cid,c,a,k=row['case_id'],row['commitment'],row['alpha'],row['kappa'];key=cid,c,a,k
        if key in seen:raise ValueError('duplicate threshold')
        seen.add(key);levels=[float(Fraction(r)) for r in MARGINS if Fraction(network[cid,c,a,r,k]['gain_exact'])>EPS]
        if row['positive_levels']!=levels or row['lowest_tested_r_positive']!=(min(levels) if levels else None) or row['interpolated']:raise ValueError('tested margin threshold differs')
    for table,kind in [('group_grid','individual'),('paired_group_grid','pair')]:
        seen=set()
        for row in report[table]:
            a,r,k,w=row['alpha'],row['r_fraction'],row['kappa'],row['weighting'];c=row.get('commitment');identity=(a,r,k,w,c)
            if identity in seen:raise ValueError('duplicate aggregate')
            seen.add(identity);selected=[network[cid,c,a,r,k] for cid in ids] if kind=='individual' else [paired[cid,a,r,k] for cid in ids]
            for field in keys:
                source=field if kind=='individual' else 'change_'+field;val=average(selected,source,w)
                if not same(row['mean_'+source],float(val)):raise ValueError('weighted mean differs')
                if kind=='pair':
                    if row['mean_change_sign_'+field]!=label(val):raise ValueError('mean sign differs')
                    for labelname in ['positive','negative','numerical_zero']:
                        if row[labelname+'_change_'+field]!=sum(x['sign_'+field]==labelname for x in selected):raise ValueError('pair sign count')
            if kind=='individual':
                if row['gain_positive_count']!=sum(x['gain_sign']=='positive' for x in selected):raise ValueError('positive count')
            else:
                for key in ['nonpositive_to_positive','positive_to_nonpositive']:
                    if row[key+'_count']!=sum(x[key] for x in selected):raise ValueError('crossing count')
    seen=set()
    for row in report['belief_patterns']:
        cid,c=row['case_id'],row['commitment'];levels=list(ALPHA_CELLS)
        if (cid,c) in seen or row['family']!=bykey[cid,c,'C00']['task']['family']:raise ValueError('belief pattern identity')
        seen.add((cid,c))
        sup=[bool(bykey[cid,c,'C00']['totals']['qualification_dates']) and not bool(bykey[cid,c,ALPHA_CELLS[a]]['totals']['qualification_dates']) for a in levels]
        joint=[metrics[cid,c,a]['b']>EPS and metrics[cid,c,a]['delta_d']>EPS for a in levels]
        first=lambda p:next((a for a,v in zip(levels,p) if v),None)
        if row['alpha']!=levels or row['suppression_pattern']!=sup or row['joint_positive_pattern']!=joint or row['lowest_tested_alpha_suppression']!=first(sup) or row['lowest_tested_alpha_joint']!=first(joint) or row['suppression_nonmonotone']!=any(x and not y for x,y in zip(sup,sup[1:])):raise ValueError('belief pattern differs')
        if len(row['lowest_alpha_positive_gain'])!=147:raise ValueError('gain pattern coverage')
        gains_seen=set()
        for g in row['lowest_alpha_positive_gain']:
            if (g['r_fraction'],g['kappa']) in gains_seen:raise ValueError('duplicate gain pattern')
            gains_seen.add((g['r_fraction'],g['kappa']))
            p=[Fraction(network[cid,c,a,g['r_fraction'],g['kappa']]['gain_exact'])>EPS for a in levels]
            if g['pattern']!=p or g['alpha']!=first(p) or g['nonmonotone']!=any(x and not y for x,y in zip(p,p[1:])):raise ValueError('positive gain belief pattern')
    seen=set()
    for row in report['decomposition_means']:
        identity=row['commitment'],row['weighting']
        if identity in seen:raise ValueError('duplicate decomposition mean')
        seen.add(identity);selected=[x for x in report['decomposition'] if x['commitment']==row['commitment']]
        if row['n']!=24 or any(not same(row[k],float(average(selected,k,row['weighting']))) for k in ['contractual','belief','interaction','total']):raise ValueError('weighted decomposition differs')
    return expected_counts

def verify(path):
    m=authorize(path);out=ROOT/m['output'];result=read(out/'result.json');caps=m['caps'];bykey={};records=[]
    if result['status']!='completed' or result['failures'] or result['manifest_sha256']!=sha(path):raise ValueError('complete bound run required')
    if result['completed_paths']!=len(m['tasks']) or result['mip_phases']!=caps['maximum_mip_phases']:raise ValueError('workload differs')
    if result['elapsed_seconds']>caps['wall_seconds'] or result['peak_rss_mib']>caps['peak_rss_mib'] or len(result['phase_seconds'])!=result['mip_phases'] or max(result['phase_seconds'])>30.01:raise ValueError('resource cap')
    for file,want in result['files'].items():
        p=(out/file).resolve()
        if not p.is_relative_to(out) or sha(p)!=want:raise ValueError('saved evidence changed')
    items={x['case_id']:x for x in m['catalog']}
    with forbid_solves():
        for i,task in enumerate(m['tasks']):
            saved=read(out/f'path-{i:03d}.json');case,diff=variant(items[task['case_id']],task['commitment'])
            if saved['path_id']!=task['path_id'] or saved['status']!='completed' or len(saved['periods'])!=20 or digest(asdict(case))!=task['variant_sha256'] or diff!=task['intervention']:raise ValueError('task/variant mismatch')
            for row in saved['periods']:
                certificate(row['certificate'],current=m['mode']=='profile' or not task['cached_original'] or task['cell'].startswith('A'))
                if row.get('warnings'):raise ValueError('warning needs review')
                if any(not all(math.isfinite(c[k]) for k in ['raw','projected']) or abs(c['projected']-c['raw'])>2e-7 for c in row.get('handoff_corrections',[])):raise ValueError('handoff correction cap')
            if math.fsum(abs(c['projected']-c['raw']) for row in saved['periods'] for c in row.get('handoff_corrections',[]))>1e-3:raise ValueError('cumulative handoff budget')
            if m['mode']=='study':
                replay(case,task,saved);bykey[task['case_id'],task['commitment'],task['cell']]=saved
            elif any('action' in row or 'ledger' in row for row in saved['periods']):raise ValueError('profile retained strategic path data')
            records.append(saved)
    counts=check_report(read(out/'descriptive_report.json'),bykey) if m['mode']=='study' else {}
    value={'status':'verified','result_sha256':sha(out/'result.json'),'manifest_sha256':sha(path),'paths':len(records),'report_rows_checked':counts,'mip_solves':0,'private_access':False}
    with (out/'verification.json').open('x') as f:json.dump(value,f,indent=2);f.write('\n')
    print(json.dumps(value,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);a=p.parse_args();verify(a.manifest.resolve())
