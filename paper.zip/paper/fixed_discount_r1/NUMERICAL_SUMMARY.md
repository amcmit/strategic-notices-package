# Fixed-concession numerical verification

Exact rational arithmetic on saved outputs only. No optimization, physical-policy replay, equilibrium solution, confidence interval or significance test.

## Choice counts

| Unit of comparison | Before: finite | Before: horizon | After: finite | After: horizon | After ties included in finite |
| --- | ---: | ---: | ---: | ---: | ---: |
| Network–probability pairs | 600 | 0 | 360 | 240 | 8 |
| Equal-family mean probability cells | 25 | 0 | 15 | 10 | 0 |
| Arithmetic mean probability cells | 25 | 0 | 15 | 10 | 0 |

Before the concession, finite is strictly cheaper in 576 comparisons, with 24 exact ties. All 240 individual switches after the concession favor through-horizon commitment. These totals count network–probability pairs, not distinct networks.

## Validated prior-one-half examples

| Reporting likelihood | Exact original gap | Exact adjusted gap | Displayed before/after | Mean preference after | Individual finite/horizon/ties |
| --- | --- | --- | --- | --- | --- |
| 0 | 3809/2000 | -191/2000 | 1.90 / -0.10 | horizon | 12 / 12 / 7 |
| 1 | 72893749999999999/20000000000000000 | 32893749999999999/20000000000000000 | 3.64 / 1.64 | finite | 24 / 0 / 0 |

## Equal-family mean regions, all tested cells

| Prior | Reporting likelihood | Original gap | Adjusted gap | Mean preference after | Individual finite | Individual horizon | Exact ties |
| --- | --- | ---: | ---: | --- | ---: | ---: | ---: |
| 1/10 | 0 | +0.380900 | -1.619100 | horizon | 0 | 24 | 0 |
| 1/10 | 1/4 | +0.285675 | -1.714325 | horizon | 0 | 24 | 0 |
| 1/10 | 1/2 | +0.194450 | -1.805550 | horizon | 0 | 24 | 0 |
| 1/10 | 3/4 | +0.201088 | -1.798912 | horizon | 0 | 24 | 0 |
| 1/10 | 1 | +0.241212 | -1.758787 | horizon | 1 | 23 | 1 |
| 1/4 | 0 | +0.952250 | -1.047750 | horizon | 0 | 24 | 0 |
| 1/4 | 1/4 | +0.802406 | -1.197594 | horizon | 0 | 24 | 0 |
| 1/4 | 1/2 | +1.234984 | -0.765016 | horizon | 4 | 20 | 0 |
| 1/4 | 3/4 | +1.689172 | -0.310828 | horizon | 12 | 12 | 0 |
| 1/4 | 1 | +2.185437 | +0.185438 | finite | 14 | 10 | 0 |
| 1/2 | 0 | +1.904500 | -0.095500 | horizon | 12 | 12 | 7 |
| 1/2 | 1/4 | +2.395781 | +0.395781 | finite | 13 | 11 | 0 |
| 1/2 | 1/2 | +3.065250 | +1.065250 | finite | 19 | 5 | 0 |
| 1/2 | 3/4 | +3.404016 | +1.404016 | finite | 21 | 3 | 0 |
| 1/2 | 1 | +3.644687 | +1.644687 | finite | 24 | 0 | 0 |
| 3/4 | 0 | +2.856750 | +0.856750 | finite | 24 | 0 | 0 |
| 3/4 | 1/4 | +3.606508 | +1.606508 | finite | 24 | 0 | 0 |
| 3/4 | 1/2 | +3.809250 | +1.809250 | finite | 24 | 0 | 0 |
| 3/4 | 3/4 | +3.809250 | +1.809250 | finite | 24 | 0 | 0 |
| 3/4 | 1 | +3.809250 | +1.809250 | finite | 24 | 0 | 0 |
| 9/10 | 0 | +3.428100 | +1.428100 | finite | 24 | 0 | 0 |
| 9/10 | 1/4 | +3.809100 | +1.809100 | finite | 24 | 0 | 0 |
| 9/10 | 1/2 | +3.809100 | +1.809100 | finite | 24 | 0 | 0 |
| 9/10 | 3/4 | +3.809100 | +1.809100 | finite | 24 | 0 | 0 |
| 9/10 | 1 | +3.809100 | +1.809100 | finite | 24 | 0 | 0 |

## Checks

- Every original gap independently recomputed from the two saved expected-cost fields.
- Every adjusted gap equals the original minus exactly two, using Fractions, with no tolerance-based classification.
- Zero concession recovers all 600 individual and 50 aggregate original gaps and choices.
- Mean costs independently recomputed by averaging within each family and then averaging the five family means; arithmetic means are also retained.
- Exact equality, values immediately above/below equality, and a zero objective comparison tested. Ties retain finite.
- CSV rows agree with the exact JSON records. Generated numerical macros, plotted cells and source pointers checked.
- Frozen result and physical-policy files retain their hashes. The concession does not enter supplier gain, reporting likelihood or the Bayesian posterior.
- All original analytical propositions and unrelated numerical tables remain byte-identical. Original preregistration and correction disclosures remain.

The original low-prior nonmonotonicity is preserved. The two-unit concession is uncalibrated and unconditional. It is not a conditional qualification discount or a change to a backup unit price. These restrictions matter for the validity of subtracting a constant without recomputing decisions.

`NETWORK_PREFERENCES.csv` contains all 600 network–probability rows. `AGGREGATE_PREFERENCES.csv` contains both weighting schemes. `COMPARISONS.json` contains exact rational values. `NUMERICAL_VERIFICATION.json` supplies the check record and source hashes.
