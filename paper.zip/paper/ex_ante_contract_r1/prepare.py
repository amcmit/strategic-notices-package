"""Build approval proposals and replay existing public evidence without solves."""
from dataclasses import asdict
from pathlib import Path
import argparse, ast, csv, json
from common import *
from runner import prefix,check_prefixes
from verifier import replay


def cache_catalog(items):
    inputs=set();known={i['case_id']:i for i in items};answer={}
    result=read(PAIRED/'result.json');v=read(PAIRED/'verification.json')
    if result['status']!='completed' or result['failures'] or v['status']!='verified' or v['result_sha256']!=sha(PAIRED/'result.json'):raise ValueError('paired evidence not verified')
    for rel,h in result['files'].items():
        path=(PAIRED/rel).resolve()
        if not path.is_relative_to(PAIRED.resolve()) or sha(path)!=h:raise ValueError('paired output binding differs')
    inputs|={str(p.relative_to(ROOT)) for p in [PAIRED/'result.json',PAIRED/'verification.json',PAIRED.parent/'study_execution_manifest.json',PAIRED.parent/'owner_approval_study.json']}
    for path in sorted(PAIRED.glob('path-*.json')):
        row=read(path);t=row['task']
        if t['case_id'] not in known:continue
        a=F(t['alpha']);schedule=t['schedule']
        if not ((schedule=='major' and a==0) or (schedule=='minor' and a in alphas())):continue
        item=known[t['case_id']];case=variant(item,t['commitment'])
        if t['variant_sha256']!=digest(asdict(case)) or row['status']!='completed':raise ValueError('cache configuration mismatch')
        key=scientific_key(case,'long',schedule,a)
        if key in answer:raise ValueError('duplicate cache key')
        answer[key]={'source':str(path.relative_to(ROOT)),'source_sha256':sha(path),'record_sha256':digest(row),'origin':'verified_paired_study'}
        inputs.add(str(path.relative_to(ROOT)))
    result=read(CALIBRATION/'result.json');v=read(CALIBRATION/'verification.json');progress=CALIBRATION/'progress.jsonl'
    if result['status']!='completed' or result['failures'] or v['status']!='verified' or v['result_sha256']!=sha(CALIBRATION/'result.json') or result['progress_sha256']!=sha(progress):raise ValueError('truthful evidence not verified')
    inputs|={str((CALIBRATION/f).relative_to(ROOT)) for f in ['result.json','verification.json','progress.jsonl']}
    with progress.open() as stream:
        for number,line in enumerate(stream,1):
            row=json.loads(line);cid,suffix=row['path_id'].split('|')
            if cid not in known or suffix!='short/minor':continue
            item=known[cid];case=variant(item,item['factors']['commitment']);key=scientific_key(case,'short','minor','1')
            if key in answer:raise ValueError('duplicate short cache')
            answer[key]={'source':str(progress.relative_to(ROOT)),'source_sha256':sha(progress),'record_sha256':digest(row),'line':number,'origin':'verified_truthful_calibration'}
    if len(answer)!=264:raise ValueError('expected 240 paired and 24 truthful cached paths')
    return answer,inputs


def prepare():
    destinations=[HERE/'profile_manifest.json',HERE/'study_manifest.json']
    if any(p.exists() for p in destinations):raise FileExistsError('do not overwrite a bound proposal')
    items=catalog();cache,inputs=cache_catalog(items);all_tasks=tasks(items,cache);by={i['case_id']:i for i in items}
    audits=[];prefixes=[]
    with forbid_solves():
        for t in all_tasks:
            if not t['cache']:continue
            case=variant(by[t['case_id']],t['commitment']);old=read_cache(t['cache']);record=replay_cache(case,t,old)
            record['pre_revelation']=prefix(record,case.contract.revelation_period)
            independent,pre=replay(case,t,record)
            if numeric_tree(independent)!=numeric_tree(record['totals']):raise ValueError('independent cached totals mismatch')
            audits.append({'path_id':t['path_id'],'scientific_key':t['scientific_key'],'cache_locator':t['cache'],
                           'replayed_totals_sha256':digest(independent),'independent_replay_passed':True})
            prefixes.append({'task':t,'pre_revelation':pre})
    pair_count=check_prefixes(prefixes)
    write(HERE/'CACHE_REPLAY_AUDIT.json',{'cached_paths':len(audits),'periods':20*len(audits),'mip_solves':0,
        'common_state_short_long_pairs':pair_count,'paths':audits,'historical_warning_cleared':False})
    with (HERE/'PATH_INVENTORY.csv').open('w',newline='') as stream:
        fields=['path_id','case_id','family','size','commitment','actual','schedule','alpha_exact','alpha_float','scientific_key','cached','cache_source']
        w=csv.DictWriter(stream,fieldnames=fields);w.writeheader()
        for t in all_tasks:w.writerow({k:t[k] for k in fields if k not in ('cached','cache_source')}|{'cached':bool(t['cache']),'cache_source':t['cache']['source'] if t['cache'] else ''})
    profile=[]
    for fam in FAMILIES:
        for size in ('small','large'):
            item=min((i for i in items if i['family']==fam and i['size']==size),key=lambda x:x['case_id'])
            profile += [dict(t,cache=None) for t in all_tasks if t['case_id']==item['case_id'] and t['schedule']=='minor' and t['alpha_exact']=='2/3']
    if len(all_tasks)!=1680 or sum(t['cache'] is not None for t in all_tasks)!=264 or len(profile)!=40:raise ValueError('workload count')
    baseline=read(PAIRED.parent/'study_execution_manifest.json')
    sources={name:sha(ROOT/name) for name in baseline['source_sha256'] if name.startswith('src/sn/')}
    sources.update({str(p.relative_to(ROOT)):sha(p) for p in HERE.glob('*.py')})
    inputs|={'configs/proposed-v3-allocation.json','configs/v3-design/selection-freeze.json','configs/v3-design/manifest.json',
             'docs/V3_SINGLE_SOLVE_R3_PROTOCOL.md','paper/ex_ante_contract_r1/EXECUTION_SPEC.md','paper/ex_ante_contract_r1/REQUEST.md',
             'paper/ex_ante_contract_r1/CACHE_REPLAY_AUDIT.json','paper/ex_ante_contract_r1/PATH_INVENTORY.csv',
             'paper/ex_ante_contract_r1/TEST_RESULTS.txt','paper/ex_ante_contract_r1/PREFLIGHT.json'}
    inputs|={f"configs/v3-design/cases/candidate-0/{i['case_id']}.json" for i in items}
    # Retain the accepted limited warning disposition as historical provenance.
    inputs|={'paper/paired_commitment_r1/owner_numerical_disposition.json','paper/followup_drafts_r1/WARNING_DISPOSITION_PROPOSAL.md'}
    for mode,selected in [('profile',profile),('study',all_tasks)]:
        new=sum(t['cache'] is None for t in selected)
        caps={'paths':len(selected),'new_paths':new,'cached_paths':len(selected)-new,'maximum_mip_phases':20*new,
              'per_mip_seconds':30,'wall_seconds':600 if mode=='profile' else 3600,'worker_wall_seconds':600,
              'peak_rss_mib_per_process':512,'maximum_live_workers':1,'saved_bytes':134217728 if mode=='profile' else 1073741824,'retries':0}
        manifest={'schema':1,'mode':mode,'status':'ready_for_owner_hash_approval' if mode=='profile' else 'draft_blocked_pending_verified_profile',
          'planner_sha256':PLANNER_HASH,'source_sha256':sources,'input_sha256':{x:sha(ROOT/x) for x in sorted(inputs)},'prerequisite_sha256':{},
          'environment':environment(),'catalog':items,'tasks':selected,'caps':caps,'measured_caps':False,
          'output':f'paper/ex_ante_contract_r1/{mode}_execution','receipt_path':f'paper/ex_ante_contract_r1/owner_approval_{mode}.json',
          'receipt_decision':f'owner_approved_ex_ante_contract_{mode}_r1',
          'parameters':{'mu':MU,'beta':BETA,'posterior_exact':[str(a) for a in alphas()],
             'margin_r':'1/2','penalty_kappa':'5','liability_lambda':'1','contradiction_F':'0','demand_multiplier':1,
             'buyer_cost':'executed ledger operating_cost; no tie score, no damages receipts',
             'contract_choice':'horizon iff exact saved-decimal expected-cost difference < 0; equality finite',
             'near_tie_flag':'absolute cost difference <= 1e-6; does not change selection',
             'premium':'unconditional stage-0 fee, sunk before operating decisions; negative values retained',
             'reporting_probability':'specified and common to both contracts; no equilibrium selection'},
          'policy':{'zero_retries':True,'stop_on_first_failure':True,'full_failure_text':True,'profile_scientific_outputs':False,
             'all_networks_and_levels':True,'new_tests_or_intervals':False,'confirmation_access':False,'manuscript_integration':False,
             'historical_warning':'unresolved; accepted limited reuse disposition retained; no claim of clearance'}}
        write(HERE/f'{mode}_manifest.json',manifest)
    summary={'unique_posteriors':len(alphas()),'paths':len(all_tasks),'cached_paths':264,'new_paths':1416,'maximum_new_mips':28320,
             'profile_paths':40,'profile_mips':800,'cached_replay_pairs':pair_count,
             'profile_manifest_sha256':sha(destinations[0]),'study_draft_sha256':sha(destinations[1]),'new_solves':0}
    write(HERE/'PREPARATION.json',summary);print(json.dumps(summary,indent=2))

if __name__=='__main__':prepare()
