"""After a complete verified study only: descriptive CSVs and a public heatmap.

This command exports locally. It never edits the manuscript or computes tests.
"""
from pathlib import Path
import argparse,csv,json
from common import *

def export(path):
    m=authorize(path)
    if m['mode']!='study':raise ValueError('study only')
    out=ROOT/m['output'];r=read(out/'result.json');v=read(out/'verification.json')
    if r['status']!='completed' or r['failures'] or v['status']!='verified' or v['result_sha256']!=sha(out/'result.json'):raise ValueError('complete verified study required')
    report_path=out/'descriptive_report.json'
    if sha(report_path)!=r['files']['descriptive_report.json']:raise ValueError('report changed')
    report=read(report_path);dest=HERE/'report';dest.mkdir()
    def flatten(row,prefix=''):
        answer={}
        for k,x in row.items():
            key=prefix+k
            if isinstance(x,dict):answer.update(flatten(x,key+'.'))
            else:answer[key]=x
        return answer
    for table in ['network_contract_grid','paired_grid','aggregate_grid']:
        rows=[flatten(x) for x in report[table]]
        with (dest/(table+'.csv')).open('w',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm
    rows=report['aggregate_grid'];extent=max(abs(x['difference']) for x in rows) or 1
    fig,axs=plt.subplots(1,2,figsize=(8,3.5),constrained_layout=True)
    for ax,weight,title in zip(axs,['equal_family','arithmetic'],['Equal family weights','Arithmetic network mean']):
        lookup={(x['mu'],x['beta']):x for x in rows if x['weighting']==weight}
        data=[[lookup[m,b]['difference'] for b in BETA] for m in MU]
        im=ax.imshow(data,cmap='RdBu_r',norm=TwoSlopeNorm(vmin=-extent,vcenter=0,vmax=extent),interpolation='none')
        for i,m in enumerate(MU):
            for j,b in enumerate(BETA):ax.text(j,i,f'{lookup[m,b]["difference"]:.2f}',ha='center',va='center',fontsize=8)
        ax.set(xticks=range(5),xticklabels=[f'{float(F(b)):g}' for b in BETA],yticks=range(5),yticklabels=[f'{float(F(m)):g}' for m in MU],xlabel=r'Reporting likelihood $\beta$',ylabel=r'Long-outage prior $\mu$',title=title)
    fig.colorbar(im,ax=axs,label='Expected operating cost: through-horizon minus finite',shrink=.85)
    fig.savefig(dest/'contract_preference.pdf',metadata={'Subject':'Saved verified report SHA-256 '+sha(report_path)})
    fig.savefig(dest/'contract_preference.png',dpi=240);plt.close(fig)
    source_map=[{'table':'aggregate_grid','row':i,'mu':x['mu'],'beta':x['beta'],'weighting':x['weighting'],'column':'difference','source_sha256':sha(report_path)} for i,x in enumerate(rows)]
    write(dest/'SOURCE_MAP.json',source_map)
    (dest/'README.md').write_text('# Descriptive ex ante contract comparison\n\nAll networks and all 25 probability combinations are retained. Negative cost differences favor through-horizon; exact equality selects finite. Cells are tested grid points, with no interpolation. Supplier reporting probabilities are exogenous. No new hypotheses or intervals.\n\nFull per-network costs, decomposition, preferences, premiums and incentive signs are in the CSV files. Manuscript integration remains subject to owner result review.\n')
    write(dest/'HASHES.json',{p.name:sha(p) for p in dest.iterdir() if p.is_file()})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True,type=Path);a=p.parse_args();export(a.manifest.resolve())
