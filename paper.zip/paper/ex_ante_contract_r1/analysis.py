"""Exact arithmetic over saved path totals. No statistical inference or solves."""
from fractions import Fraction
from common import MU,BETA,FAMILIES,CONTRACTS,F,posterior

METRICS=('expected_cost','truthful_cost','precaution_cost','misreport_cost','reporting_cost','gain','b','delta_d','delta_shortfall',
         'short_cost','long_major_cost','long_minor_cost','short_qualification','long_major_qualification','long_minor_qualification')

def rational_row(values):
    return {k:float(v) for k,v in values.items()}|{'exact':{k:str(v) for k,v in values.items()}}

def mean(rows,field,weight):
    get=lambda row:F(row['exact'][field])
    if weight=='arithmetic':return sum((get(r) for r in rows),F(0))/len(rows)
    if weight!='equal_family':raise ValueError('weighting')
    return sum((sum((get(r) for r in rows if r['family']==f),F(0))/sum(r['family']==f for r in rows) for f in FAMILIES),F(0))/len(FAMILIES)

def sign(v):return 'positive' if v>0 else 'negative' if v<0 else 'zero'

def build_report(summaries,items):
    expected={(i['case_id'],k,a,s,str(p)) for i in items for k in CONTRACTS for a,s,p in
              [('long','major',F(0))]+[(a,'minor',posterior(m,b)) for m in MU for b in BETA for a in ('short','long')]}
    by={}
    for row in summaries:
        t=row['task'];key=t['case_id'],t['commitment'],t['actual'],t['schedule'],t['alpha_exact']
        if key in by:raise ValueError('duplicate scientific path')
        by[key]=row['totals']
    if set(by)!=expected:raise ValueError('missing or extra path coverage')
    network=[];pair=[];groups=[]
    for item in items:
        cid=item['case_id']
        for ms in MU:
            for bs in BETA:
                m,b=F(ms),F(bs);a=posterior(m,b);per={}
                for k in CONTRACTS:
                    sm=by[cid,k,'short','minor',str(a)];st=by[cid,k,'short','minor','1']
                    lm=by[cid,k,'long','minor',str(a)];lt=by[cid,k,'long','major','0']
                    cost=lambda r:F(r['buyer_cost'])
                    expected_cost=(1-m)*cost(sm)+m*(1-b)*cost(lt)+m*b*cost(lm)
                    truth=(1-m)*cost(st)+m*cost(lt)
                    precaution=(1-m)*(cost(sm)-cost(st));misreport=m*b*(cost(lm)-cost(lt))
                    if expected_cost-truth!=precaution+misreport:raise AssertionError('cost decomposition identity')
                    dp=F(lm['primary'])-F(lt['primary']);da=F(lm['accepted_shortfall'])-F(lt['accepted_shortfall'])
                    values={'expected_cost':expected_cost,'truthful_cost':truth,'precaution_cost':precaution,'misreport_cost':misreport,
                        'reporting_cost':expected_cost-truth,'gain':F('1/2')*dp-5*da,'b':F(lt['backup'])-F(lm['backup']),
                        'delta_d':dp,'delta_shortfall':da,'short_cost':cost(sm),'long_major_cost':cost(lt),'long_minor_cost':cost(lm),
                        'short_qualification':Fraction(bool(sm['qualification_dates'])),'long_major_qualification':Fraction(bool(lt['qualification_dates'])),
                        'long_minor_qualification':Fraction(bool(lm['qualification_dates']))}
                    # Fraction(bool) is intentional here; F parses strings only.
                    row={'case_id':cid,'family':item['family'],'size':item['size'],'commitment':k,'mu':ms,'beta':bs,'alpha':str(a),
                         **rational_row(values),'gain_sign':sign(values['gain'])}
                    row['reporting_best_response_consistent']=(values['gain']<=0 if b==0 else values['gain']>=0 if b==1 else values['gain']==0)
                    network.append(row);per[k]=row
                delta=F(per['horizon']['exact']['expected_cost'])-F(per['finite']['exact']['expected_cost'])
                values={f'{k}_cost':F(per[k]['exact']['expected_cost']) for k in CONTRACTS}|{'difference':delta,'premium':-delta}
                pair.append({'case_id':cid,'family':item['family'],'mu':ms,'beta':bs,'alpha':str(a),**rational_row(values),
                    'preferred_contract':'horizon' if delta<0 else 'finite','exact_tie':delta==0,
                    'near_tie_within_1e_6':abs(delta)<=F('1e-6'),
                    'finite_gain_sign':per['finite']['gain_sign'],'horizon_gain_sign':per['horizon']['gain_sign']})
    for ms in MU:
        for bs in BETA:
            pairs=[r for r in pair if r['mu']==ms and r['beta']==bs]
            for w in ('arithmetic','equal_family'):
                vals={x:mean(pairs,x,w) for x in ('finite_cost','horizon_cost','difference','premium')}
                row={'mu':ms,'beta':bs,'alpha':str(posterior(ms,bs)),'weighting':w,'n':len(pairs),**rational_row(vals),
                    'preferred_contract':'horizon' if vals['difference']<0 else 'finite',
                    'finite_preferred':sum(r['preferred_contract']=='finite' for r in pairs),
                    'horizon_preferred':sum(r['preferred_contract']=='horizon' for r in pairs),'exact_ties':sum(r['exact_tie'] for r in pairs)}
                for k in CONTRACTS:
                    subset=[r for r in network if r['mu']==ms and r['beta']==bs and r['commitment']==k]
                    row[k]=rational_row({v:mean(subset,v,w) for v in METRICS})
                    row[k]['profitable_networks']=sum(r['gain_sign']=='positive' for r in subset)
                    row[k]['reporting_consistent_networks']=sum(r['reporting_best_response_consistent'] for r in subset)
                groups.append(row)
    return {'scope':'post-confirmation descriptive; public design; exogenous beta; no equilibrium or new tests',
            'parameters':{'r':'1/2','kappa':'5','lambda':'1','F':'0','buyer_compensation_receipts':False},
            'network_contract_grid':network,'paired_grid':pair,'aggregate_grid':groups}
