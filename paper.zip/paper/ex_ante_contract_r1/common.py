"""Public-only inputs and receipt gates. Import/preparation never optimizes."""
from contextlib import contextmanager
from dataclasses import asdict, replace
from fractions import Fraction
from pathlib import Path
from importlib.metadata import version
import hashlib, json, math, platform, sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'src'))
from sn import planner_v3_single_r3 as planner
from sn.allocation_v3 import canonical
from sn.belief_v3_common import load_case
from sn.core import Notice, Realization
from sn.core_v3 import initial_state_v3, step_v3
from sn.verify_belief_v3 import action, numeric_tree, certificate

PLANNER_HASH = '48f341a686809e41efa15b41583ccab562652ab9ae8a2bc24dbff97dcfcb239c'
MU = ('1/10','1/4','1/2','3/4','9/10')
BETA = ('0','1/4','1/2','3/4','1')
FAMILIES = ('assembly','distribution','layered_dual','planted','serial')
CONTRACTS = ('finite','horizon')
PAIRED = ROOT/'paper/paired_commitment_r1/study_execution'
CALIBRATION = ROOT/'results/v3_truthful_calibration_r4'
F = lambda x: Fraction(str(x))


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()

def digest(value):return hashlib.sha256(canonical(value)).hexdigest()
def read(path):
    def unique(pairs):
        d={}
        for k,v in pairs:
            if k in d:raise ValueError('duplicate JSON key: '+k)
            d[k]=v
        return d
    return json.loads(Path(path).read_text(),object_pairs_hook=unique)
def write(path,value):Path(path).write_bytes(canonical(value))
def repository_path(value):
    p=(ROOT/value).resolve()
    if not p.is_relative_to(ROOT):raise ValueError('path outside repository')
    return p

def posterior(mu,beta):
    m,b=F(mu),F(beta)
    if not 0<=m<=1 or not 0<=b<=1:raise ValueError('probability outside [0,1]')
    denominator=1-m+m*b
    if not denominator:raise ValueError('minor notice has zero probability; posterior undefined')
    return (1-m)/denominator

def alphas():return sorted({posterior(m,b) for m in MU for b in BETA})

def environment():
    from scipy.optimize._highspy import _core
    return dict(python=platform.python_version(),system=platform.system(),machine=platform.machine(),
                numpy=version('numpy'),scipy=version('scipy'),
                highs='.'.join(str(getattr(_core,'HIGHS_VERSION_'+x)) for x in ('MAJOR','MINOR','PATCH')))

@contextmanager
def forbid_solves():
    old=planner.plan,planner._solve,planner.milp
    def denied(*args,**kwargs):raise AssertionError('optimization forbidden in preparation, tests and verification')
    planner.plan=planner._solve=planner.milp=denied
    try:yield
    finally:planner.plan,planner._solve,planner.milp=old

def catalog():
    frozen=read(ROOT/'configs/v3-design/selection-freeze.json')
    allocation=read(ROOT/'configs/proposed-v3-allocation.json')
    factors={v['case_id']:v for v in allocation['candidates'][0]['cases']}
    rows=[{**x,'factors':factors[x['case_id']]} for x in frozen['cases'] if x['regime']=='R1' and x['category']=='interior']
    if len(rows)!=24 or sha(ROOT/'src/sn/planner_v3_single_r3.py')!=PLANNER_HASH:raise ValueError('frozen roster/planner differs')
    return rows

def variant(item,commitment):
    original=load_case(ROOT,item)
    if commitment not in CONTRACTS:raise ValueError('unknown commitment')
    case=replace(original,contract=replace(original.contract,backup_commitment_periods=item['factors']['long_duration'] if commitment=='finite' else None))
    before,after=asdict(original),asdict(case)
    before['contract'].pop('backup_commitment_periods');after['contract'].pop('backup_commitment_periods')
    if before!=after:raise ValueError('more than commitment changed')
    if (case.network.horizon!=20 or case.contract.primary_price!=1 or case.contract.demand_rule!='lost_sales' or
        case.contract.liability_multiplier!=1 or case.contract.fixed_contradiction_cost!=0):raise ValueError('frozen conventions differ')
    return case

def scientific_key(case,actual,schedule,alpha):
    return digest({'case_sha256':digest(asdict(case)),'actual':actual,'schedule':schedule,'alpha_exact':str(F(alpha)),
                   'planner_sha256':PLANNER_HASH,'presolve':False,'threads':1,'seed':0,'time_limit':30,'demand_multiplier':1})

def tasks(items,cache=None):
    result=[];cache=cache or {}
    for item in items:
        for commitment in CONTRACTS:
            case=variant(item,commitment)
            for actual,schedule,a in [('long','major',F(0))]+[(actual,'minor',a) for a in alphas() for actual in ('short','long')]:
                key=scientific_key(case,actual,schedule,a)
                result.append({'case_id':item['case_id'],'family':item['family'],'size':item['size'],'commitment':commitment,
                    'actual':actual,'schedule':schedule,'alpha_exact':str(a),'alpha_float':float(a),
                    'path_id':f"{item['case_id']}|{commitment}|{actual}/{schedule}|alpha={a}",
                    'variant_sha256':digest(asdict(case)),'scientific_key':key,'cache':cache.get(key)})
    return result

def problem(case,state,task):
    actual=case.short_capacity if task['actual']=='short' else case.long_capacity
    alpha=float(F(task['alpha_exact']));t=state.period
    rows=[(task['actual'],1.0,actual)] if t>=case.contract.revelation_period else [('short',alpha,case.short_capacity),('long',1-alpha,case.long_capacity)]
    notice=Notice(case.long_capacity if task['schedule']=='major' else case.short_capacity,task['schedule'])
    return planner.PlanningProblem(case.network,case.contract,notice,state,
        tuple(planner.Scenario(n,float(p),c) for n,p,c in rows if p>0),actual[t],case.baseline_demand[t],case.baseline_demand,30,False,1)

def totals(periods):
    ls=[r['ledger'] for r in periods]
    return {'buyer_cost':math.fsum(v['operating_cost'] for v in ls),'primary':math.fsum(v['primary_delivered'] for v in ls),
        'backup':math.fsum(v['backup_delivered'] for v in ls),
        'accepted_shortfall':math.fsum(v['primary_shortfall']-v['pre_horizon_order_shortfall'] for v in ls),
        'pre_horizon_shortfall':math.fsum(v['pre_horizon_order_shortfall'] for v in ls),
        'qualification_dates':[r['period'] for r in periods if r['action']['qualify']],
        'lost_sales':math.fsum(x['quantity'] for v in ls for x in v['lost_sales'])}

def read_cache(locator):
    path=repository_path(locator['source'])
    if sha(path)!=locator['source_sha256']:raise ValueError('cached file changed')
    if locator.get('line'):
        with path.open() as stream:
            row=next((json.loads(line) for i,line in enumerate(stream,1) if i==locator['line']),None)
    else:row=read(path)
    if row is None or digest(row)!=locator['record_sha256']:raise ValueError('cached record changed')
    return row

def replay_cache(case,task,saved):
    """Hydrate legacy ledger hashes by physical replay, never re-optimize."""
    if saved['status']!='completed' or len(saved['periods'])!=case.network.horizon:raise ValueError('incomplete cache')
    state=initial_state_v3(case.network);periods=[];actual=case.short_capacity if task['actual']=='short' else case.long_capacity
    for t,row in enumerate(saved['periods']):
        if row['period']!=t:raise ValueError('cached period order')
        certificate(row['certificate'],current='requested_threads' in row['certificate'])
        call=problem(case,state,task);ph=digest(asdict(call))
        if row.get('planning_problem_sha256',ph)!=ph:raise ValueError('cached planning inputs differ')
        before=digest(asdict(state));chosen=action(row['action'])
        state,ledger=step_v3(case.network,case.contract,call.notice,state,chosen,Realization(actual[t],case.baseline_demand[t]),
            revealed_schedule=actual if t==case.contract.revelation_period else None)
        if 'ledger' in row:
            if numeric_tree(asdict(ledger))!=numeric_tree(row['ledger']):raise ValueError('cached ledger value mismatch')
        elif digest(asdict(ledger))!=row['ledger_sha256']:raise ValueError('cached ledger hash mismatch')
        periods.append({**row,'ledger':asdict(ledger),'planning_problem_sha256':ph,'state_before_sha256':before,
                        'scenario_probabilities':{s.name:s.probability for s in call.scenarios},
                        'certificate_origin':'legacy_bound' if 'requested_threads' not in row['certificate'] else 'current_bound'})
    if digest(asdict(state))!=saved['final_state_sha256']:raise ValueError('cached final state differs')
    return {'path_id':task['path_id'],'task':task,'status':'completed','periods':periods,
            'final_state_sha256':digest(asdict(state)),'totals':totals(periods),'cache_locator':task['cache']}

def check_bindings(m,worker=False):
    for group in (('source_sha256',) if worker else ('source_sha256','input_sha256','prerequisite_sha256')):
        for name,want in m.get(group,{}).items():
            if sha(repository_path(name))!=want:raise ValueError('bound file changed: '+name)
    if m['environment']!=environment():raise ValueError('runtime environment differs')
    if m['planner_sha256']!=PLANNER_HASH:raise ValueError('wrong planner')

def authorize(path,worker=False):
    m=read(path);check_bindings(m,worker)
    if m['status']!='ready_for_owner_hash_approval':raise PermissionError('execution draft blocked pending verified profile and owner review')
    receipt=read(repository_path(m['receipt_path']))
    if receipt.get('decision')!=m['receipt_decision'] or receipt.get('execution_manifest_sha256')!=sha(path):
        raise PermissionError('exact owner-named manifest approval required')
    if m['mode']=='study' and not m.get('measured_caps'):raise PermissionError('full study needs measured caps')
    return m
