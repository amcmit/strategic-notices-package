"""Independent physical replay and ex ante arithmetic; no runner/report imports.

Shares receipt/binding/case loading, constants and the frozen physical core.
Reconstructs probabilities, totals, costs, preferences and groups independently.
"""
from pathlib import Path
from fractions import Fraction as Q
from dataclasses import asdict
import argparse, json, math, sys, traceback
from common import (ROOT,HERE,MU,BETA,FAMILIES,CONTRACTS,read,write,sha,digest,authorize,variant,forbid_solves,read_cache,planner)
from sn.core import Action,Production,Shipment,Notice,Realization
from sn.core_v3 import initial_state_v3,step_v3
from sn.verify_belief_v3 import numeric_tree,certificate


def q(x):return Q(str(x))
def action_hash(value):
    if isinstance(value,bool) or value is None or isinstance(value,str):return value
    if isinstance(value,(int,float)):return {'number':str(q(value))}
    if isinstance(value,dict):return {k:action_hash(v) for k,v in value.items()}
    return [action_hash(v) for v in value]

def check_period(row,current=True):
    gap,limit=certificate(row['certificate'],current=current)
    for correction in row.get('handoff_corrections',[]):
        amount=abs(correction['raw']-correction['projected'])
        if not math.isfinite(amount) or abs(amount)>2e-7:raise ValueError('hand-off projection outside frozen limit')
    if any(w['category']=='RuntimeWarning' for w in row.get('warnings',[])):raise ValueError('runtime numerical warning')
    if 'objective_check' in row:
        v=row['objective_check'];v=v.get('objective',v)
        exact=Q(int(v['exact_numerator']),int(v['exact_denominator']));p=row['certificate']['primal']
        threshold=1e-7*max(1,abs(float(exact)),abs(p));difference=abs(float(exact)-p)
        if v['limit']!=threshold or v['solver_difference']!=difference or difference>threshold:raise ValueError('objective recomputation record differs')
    if 'phase_seconds' in row and not 0<=row['phase_seconds']<=30.01:raise ValueError('per-phase resource cap')
    return gap,limit

def replay(case,task,record):
    if record['status']!='completed' or len(record['periods'])!=20:raise ValueError('incomplete record')
    state=initial_state_v3(case.network);actual=case.short_capacity if task['actual']=='short' else case.long_capacity
    notice=Notice(case.long_capacity if task['schedule']=='major' else case.short_capacity,task['schedule'])
    alpha=float(q(task['alpha_exact']));ledgers=[];dates=[];pre=[]
    for t,row in enumerate(record['periods']):
        if row['period']!=t:raise ValueError('period ordering')
        check_period(row,current='requested_threads' in row['certificate'])
        choices=[(task['actual'],1.0,actual)] if t>=case.contract.revelation_period else [('short',alpha,case.short_capacity),('long',1-alpha,case.long_capacity)]
        scenarios=tuple(planner.Scenario(name,float(p),cap) for name,p,cap in choices if p>0)
        call=planner.PlanningProblem(case.network,case.contract,notice,state,scenarios,actual[t],case.baseline_demand[t],case.baseline_demand,30,False,1)
        if row['planning_problem_sha256']!=digest(asdict(call)) or row['state_before_sha256']!=digest(asdict(state)):raise ValueError('information input mismatch')
        if row['scenario_probabilities']!={s.name:s.probability for s in scenarios}:raise ValueError('revelation update mismatch')
        v=row['action']
        if set(v)!={'qualify','primary_order','spot_order','production','shipments'} or type(v['qualify']) is not bool:raise ValueError('executed action schema')
        chosen=Action(v['qualify'],v['primary_order'],v['spot_order'],tuple(Production(**x) for x in v['production']),tuple(Shipment(**x) for x in v['shipments']))
        state,ledger=step_v3(case.network,case.contract,notice,state,chosen,Realization(actual[t],case.baseline_demand[t]),revealed_schedule=actual if t==case.contract.revelation_period else None)
        if numeric_tree(asdict(ledger))!=numeric_tree(row['ledger']):raise ValueError('ledger value mismatch')
        if chosen.qualify:dates.append(t)
        if t<case.contract.revelation_period:pre.append({k:row[k] for k in ('period','planning_problem_sha256','state_before_sha256')}|{'action_sha256':digest(action_hash(v))})
        ledgers.append(ledger)
    if len(dates)>1 or digest(asdict(state))!=record['final_state_sha256']:raise ValueError('final state/qualification')
    result={'buyer_cost':math.fsum(l.operating_cost for l in ledgers),'primary':math.fsum(l.primary_delivered for l in ledgers),
        'backup':math.fsum(l.backup_delivered for l in ledgers),'accepted_shortfall':math.fsum(l.primary_shortfall-l.pre_horizon_order_shortfall for l in ledgers),
        'pre_horizon_shortfall':math.fsum(l.pre_horizon_order_shortfall for l in ledgers),
        'qualification_dates':dates,'lost_sales':math.fsum(d.quantity for l in ledgers for d in l.lost_sales)}
    if numeric_tree(result)!=numeric_tree(record['totals']) or pre!=record['pre_revelation']:raise ValueError('total or pre-revelation evidence differs')
    if task['cache']:
        old=read_cache(task['cache'])
        for before,after in zip(old['periods'],record['periods']):
            if numeric_tree(before['action'])!=numeric_tree(after['action']) or before['certificate']!=after['certificate']:raise ValueError('reused action/certificate changed')
    return result,pre

def verify_report(report,summaries,items):
    def sig(t):return (t['case_id'],t['commitment'],t['actual'],t['schedule'],t['alpha_exact'])
    paths={sig(r['task']):r['totals'] for r in summaries}
    if len(paths)!=len(summaries):raise ValueError('duplicate path')
    levels={str((1-q(m))/(1-q(m)+q(m)*q(b))) for m in MU for b in BETA}
    expect={(i['case_id'],k,a,s,v) for i in items for k in CONTRACTS for a,s,v in [('long','major','0')]+[(a,'minor',v) for v in levels for a in ('short','long')]}
    if set(paths)!=expect:raise ValueError('scientific coverage')
    def exact(row,values):
        if set(row['exact'])!=set(values):raise ValueError('quantity columns')
        for name,want in values.items():
            if q(row['exact'][name])!=want or row[name]!=float(want):raise ValueError('quantity mismatch: '+name)
    def sign(v):return 'positive' if v>0 else 'negative' if v<0 else 'zero'
    by={};paired={};families={i['case_id']:i['family'] for i in items}
    if len(report['network_contract_grid'])!=len(items)*50 or len(report['paired_grid'])!=len(items)*25 or len(report['aggregate_grid'])!=50:raise ValueError('table coverage')
    if report['parameters']!={'r':'1/2','kappa':'5','lambda':'1','F':'0','buyer_compensation_receipts':False}:raise ValueError('financial parameters')
    for row in report['network_contract_grid']:
        cid,k,ms,bs=row['case_id'],row['commitment'],row['mu'],row['beta'];key=cid,k,ms,bs
        if key in by or ms not in MU or bs not in BETA:raise ValueError('duplicate/undeclared grid cell')
        m,b=q(ms),q(bs);a=(1-m)/(1-m+m*b)
        if row['alpha']!=str(a) or row['family']!=families[cid]:raise ValueError('posterior/family')
        S=paths[cid,k,'short','minor',str(a)];T=paths[cid,k,'short','minor','1'];L=paths[cid,k,'long','major','0'];X=paths[cid,k,'long','minor',str(a)]
        cS,cT,cL,cX=[q(x['buyer_cost']) for x in (S,T,L,X)]
        weights=(1-m,m-m*b,m*b)
        if sum(weights)!=1:raise ValueError('probabilities')
        cost=sum(w*c for w,c in zip(weights,(cS,cL,cX)));truth=(1-m)*cT+m*cL
        dp=q(X['primary'])-q(L['primary']);da=q(X['accepted_shortfall'])-q(L['accepted_shortfall']);g=dp/2-5*da
        values={'expected_cost':cost,'truthful_cost':truth,'precaution_cost':(1-m)*(cS-cT),'misreport_cost':m*b*(cX-cL),'reporting_cost':cost-truth,
                'gain':g,'b':q(L['backup'])-q(X['backup']),'delta_d':dp,'delta_shortfall':da,
                'short_cost':cS,'long_major_cost':cL,'long_minor_cost':cX,
                'short_qualification':Q(bool(S['qualification_dates'])),'long_major_qualification':Q(bool(L['qualification_dates'])),'long_minor_qualification':Q(bool(X['qualification_dates']))}
        exact(row,values)
        if values['reporting_cost']!=values['precaution_cost']+values['misreport_cost']:raise ValueError('decomposition')
        if row['gain_sign']!=sign(g) or row['reporting_best_response_consistent']!=(g<=0 if b==0 else g>=0 if b==1 else g==0):raise ValueError('incentive diagnostic')
        by[key]=values
    for row in report['paired_grid']:
        cid,ms,bs=row['case_id'],row['mu'],row['beta'];key=cid,ms,bs
        if key in paired:raise ValueError('duplicate pair')
        lo,hi=by[cid,'finite',ms,bs],by[cid,'horizon',ms,bs];d=hi['expected_cost']-lo['expected_cost']
        values={'finite_cost':lo['expected_cost'],'horizon_cost':hi['expected_cost'],'difference':d,'premium':-d};exact(row,values)
        a=(1-q(ms))/(1-q(ms)+q(ms)*q(bs))
        if row['alpha']!=str(a) or row['family']!=families[cid]:raise ValueError('paired identity')
        if row['preferred_contract']!=('horizon' if d<0 else 'finite') or row['exact_tie']!=(d==0) or row['near_tie_within_1e_6']!=(abs(d)<=q('1e-6')):raise ValueError('decision tie convention')
        if row['finite_gain_sign']!=sign(lo['gain']) or row['horizon_gain_sign']!=sign(hi['gain']):raise ValueError('paired incentive signs')
        paired[key]=values
    seen=set()
    for row in report['aggregate_grid']:
        ms,bs,w=row['mu'],row['beta'],row['weighting'];key=ms,bs,w
        if key in seen or w not in ('arithmetic','equal_family'):raise ValueError('aggregate identity')
        seen.add(key);ids=sorted(families)
        def avg(data,field):
            if w=='arithmetic':return sum(data[c][field] for c in ids)/len(ids)
            fm=[]
            for fam in FAMILIES:
                group=[c for c in ids if families[c]==fam]
                fm.append(sum(data[c][field] for c in group)/len(group))
            return sum(fm)/len(fm)
        pairdata={cid:paired[cid,ms,bs] for cid in ids};values={x:avg(pairdata,x) for x in ('finite_cost','horizon_cost','difference','premium')};exact(row,values)
        hor=sum(v['difference']<0 for v in pairdata.values());ties=sum(v['difference']==0 for v in pairdata.values())
        if row['n']!=len(ids) or row['finite_preferred']!=len(ids)-hor or row['horizon_preferred']!=hor or row['exact_ties']!=ties or row['preferred_contract']!=('horizon' if values['difference']<0 else 'finite'):raise ValueError('aggregate preference counts')
        for k in CONTRACTS:
            data={cid:by[cid,k,ms,bs] for cid in ids};metrics={x:avg(data,x) for x in next(iter(data.values()))};exact(row[k],metrics)
            b=q(bs);consistent=lambda g:g<=0 if b==0 else g>=0 if b==1 else g==0
            if row[k]['profitable_networks']!=sum(v['gain']>0 for v in data.values()) or row[k]['reporting_consistent_networks']!=sum(consistent(v['gain']) for v in data.values()):raise ValueError('aggregate incentive counts')
    return {'network_contract_rows':len(by),'paired_rows':len(paired),'aggregate_rows':len(seen)}

def verify(path):
    m=authorize(path);out=ROOT/m['output'];destination=out/'verification.json'
    if destination.exists() or (out/'verification.started').exists():raise FileExistsError('verification is one-shot')
    write(out/'verification.started',{'manifest_sha256':sha(path)})
    try:
        r=read(out/'result.json')
        if r['status']!='completed' or r['failures'] or r['manifest_sha256']!=sha(path):raise ValueError('complete bound result required')
        if r['completed_paths']!=len(m['tasks']) or r['path_ids']!=[t['path_id'] for t in m['tasks']]:raise ValueError('result coverage')
        for rel,h in r['files'].items():
            p=(out/rel).resolve()
            if not p.is_relative_to(out.resolve()) or sha(p)!=h:raise ValueError('output hash mismatch')
        caps=m['caps'];new=sum(not t['cache'] for t in m['tasks'])
        if r['mip_phases']!=20*new or r['mip_phases']>caps['maximum_mip_phases'] or len(r['phase_seconds'])!=r['mip_phases']:raise ValueError('phase account')
        if r['elapsed_seconds']>caps['wall_seconds'] or max(r['parent_peak_rss_mib'],r['worker_peak_rss_mib'])>caps['peak_rss_mib_per_process']:raise ValueError('resource cap')
        if sum((out/rel).stat().st_size for rel in r['files'])+(out/'result.json').stat().st_size>caps['saved_bytes']:raise ValueError('output cap')
        items={i['case_id']:i for i in m['catalog']};summaries=[];pre={};count=0
        with forbid_solves():
            for index,task in enumerate(m['tasks']):
                case=variant(items[task['case_id']],task['commitment'])
                if digest(asdict(case))!=task['variant_sha256']:raise ValueError('case content')
                record=read(out/(f'cache-{index:04d}.json' if task['cache'] else f'worker-{index:04d}/path.json'))
                if record['task']!=task or record['path_id']!=task['path_id'] or record['status']!='completed':raise ValueError('path identity')
                if m['mode']=='study':
                    values,prefix=replay(case,task,record);summaries.append({'task':task,'totals':values})
                else:
                    if len(record['periods'])!=20 or 'totals' in record:raise ValueError('profile schema')
                    for period,row in enumerate(record['periods']):
                        if row['period']!=period or any(k in row for k in ('action','ledger')):raise ValueError('profile output restrictions')
                        check_period(row)
                    prefix=record['pre_revelation']
                    expected=[{k:row[k] for k in ('period','planning_problem_sha256','state_before_sha256','action_sha256')} for row in record['periods'] if row['period']<case.contract.revelation_period]
                    if prefix!=expected:raise ValueError('profile prefix record')
                if not task['cache']:
                    res=record['resources']
                    if res['mip_phases']!=20 or len(res['phase_seconds'])!=20 or res['wall_seconds']>caps['worker_wall_seconds'] or res['peak_rss_mib']>caps['peak_rss_mib_per_process']:raise ValueError('worker resources')
                if task['schedule']=='minor':pre.setdefault((task['case_id'],task['commitment'],task['alpha_exact']),{})[task['actual']]=prefix
            for key,v in pre.items():
                if set(v)=={'short','long'}:
                    if v['short']!=v['long']:raise ValueError('nonanticipation difference '+str(key))
                    count+=1
            if read(out/'nonanticipativity.json')!={'pairs_checked':count,'exact_action_and_input_agreement':True}:raise ValueError('pair account')
            checks={}
            if m['mode']=='study':
                if numeric_tree(read(out/'path_totals.json'))!=numeric_tree(summaries):raise ValueError('summary file differs')
                checks=verify_report(read(out/'descriptive_report.json'),summaries,m['catalog'])
        answer={'status':'verified','manifest_sha256':sha(path),'result_sha256':sha(out/'result.json'),'paths':len(m['tasks']),
                'nonanticipativity_pairs':count,'report_rows_checked':checks,'mip_solves':0,'confirmation_access':False}
        write(destination,answer);print(json.dumps(answer,indent=2));return 0
    except Exception as e:
        write(out/'verification_failure.json',{'status':'failed','type':type(e).__name__,'full_error_text':str(e),'traceback':traceback.format_exc()})
        raise

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);a=p.parse_args();sys.exit(verify(a.manifest.resolve()))
