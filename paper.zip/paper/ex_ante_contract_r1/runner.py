"""Receipt-gated profile/study; one fresh serial subprocess per new path.

No planner changes. Each worker streams certificates before returning; failures
retain complete text and cannot trigger a retry. Completed paths are on disk.
"""
from dataclasses import asdict
from fractions import Fraction
from pathlib import Path
import argparse, math, os, resource, signal, subprocess, sys, time, traceback, warnings
from common import *
from analysis import build_report

class ResourceStop(RuntimeError):pass

def rss():return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1048576 if sys.platform=='darwin' else 1024)
def bytes_used(out):return sum(p.stat().st_size for p in out.rglob('*') if p.is_file())
def objective_check(coeff,vector,cert):
    if len(coeff)!=len(vector) or not all(math.isfinite(float(v)) for v in [*coeff,*vector]):raise ValueError('nonfinite objective inputs')
    exact=sum((Fraction(float(a))*Fraction(float(x)) for a,x in zip(coeff,vector)),Fraction())
    limit=1e-7*max(1,abs(float(exact)),abs(cert.primal));error=abs(float(exact)-cert.primal)
    if error>limit:raise ValueError('objective consistency outside unchanged scaled limit')
    return {'exact_numerator':str(exact.numerator),'exact_denominator':str(exact.denominator),'solver_difference':error,'limit':limit}

def action_digest(value):
    def normalize(x):
        if isinstance(x,bool) or x is None or isinstance(x,str):return x
        if isinstance(x,(int,float)):return {'number':str(F(x))}
        if isinstance(x,dict):return {k:normalize(v) for k,v in x.items()}
        return [normalize(v) for v in x]
    return digest(normalize(value))

def prefix(record,revelation):
    return [{k:r[k] for k in ('period','planning_problem_sha256','state_before_sha256')}|
            {'action_sha256':action_digest(r['action'])} for r in record['periods'] if r['period']<revelation]

def check_prefixes(rows):
    paired={}
    for r in rows:
        t=r['task']
        if t['schedule']!='minor':continue
        key=t['case_id'],t['commitment'],t['alpha_exact']
        paired.setdefault(key,{})[t['actual']]=r['pre_revelation']
    checked=0
    for key,types in paired.items():
        if set(types)=={'short','long'}:
            if types['short']!=types['long']:raise ValueError('pre-revelation common-state/action mismatch: '+str(key))
            checked+=1
    return checked

def worker(manifest_path,index):
    m=authorize(manifest_path,worker=True);task=m['tasks'][index];out=repository_path(m['output']);folder=out/f'worker-{index:04d}'
    folder.mkdir();start=time.monotonic();phases=0;phase_seconds=[];captured=[];observed={};call_cert=None;t=None
    record={'path_id':task['path_id'],'task':task,'status':'running','periods':[]};failure=None
    old=planner._solve;state=None
    caps=m['caps'];profile=m['mode']=='profile'
    def check():
        if rss()>caps['peak_rss_mib_per_process']:raise ResourceStop('worker memory cap')
        if time.monotonic()-start>caps['worker_wall_seconds']:raise ResourceStop('worker wall cap')
        if bytes_used(out)>caps['saved_bytes']-1048576:raise ResourceStop('output cap; failure reserve')
    def measured(model,objective,time_limit,phase,**kwargs):
        nonlocal phases,observed,call_cert
        check()
        if phases>=20:raise ResourceStop('worker phase cap')
        phases+=1;begin=time.monotonic()
        # Persist attempt before the call so abrupt process failures retain counts.
        write(folder/'solve_account.json',{'phases_started':phases,'period':t})
        try:
            vector,cert=old(model,objective,time_limit,phase,**kwargs);call_cert=asdict(cert)
            observed=objective_check(objective,vector,cert)
            return vector,cert
        finally:
            elapsed=time.monotonic()-begin;phase_seconds.append(elapsed)
            if elapsed>caps['per_mip_seconds']+.01:raise ResourceStop('per-MIP time cap plus 10ms measurement allowance')
            check()
    def alarm(*_):raise ResourceStop('worker wall alarm')
    previous=signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,caps['worker_wall_seconds']);planner._solve=measured
    try:
        if task['cache']:raise ValueError('cached tasks must never launch a solver worker')
        item=next(v for v in m['catalog'] if v['case_id']==task['case_id']);case=variant(item,task['commitment'])
        if digest(asdict(case))!=task['variant_sha256']:raise ValueError('case variant hash')
        if scientific_key(case,task['actual'],task['schedule'],task['alpha_exact'])!=task['scientific_key']:raise ValueError('scientific cache key')
        actual=case.short_capacity if task['actual']=='short' else case.long_capacity;state=initial_state_v3(case.network)
        for t in range(20):
            check();call=problem(case,state,task);before=digest(asdict(state));observed={};call_cert=None;captured=[]
            with warnings.catch_warnings(record=True) as captured:
                warnings.simplefilter('always');choice=planner.plan(call)
            warning_rows=[{'category':w.category.__name__,'message':str(w.message),'file':Path(w.filename).name,'line':w.lineno} for w in captured]
            if any(issubclass(w.category,RuntimeWarning) for w in captured):raise ValueError('runtime numerical warning; review required')
            if not all(math.isfinite(v) for v in (choice.expected_cost,choice.combined_objective,choice.primary_cost_loss_bound)):raise ValueError('nonfinite returned objective')
            state,ledger=step_v3(case.network,case.contract,call.notice,state,choice.action,Realization(actual[t],case.baseline_demand[t]),
                               revealed_schedule=actual if t==case.contract.revelation_period else None)
            row={'period':t,'certificate':asdict(choice.certificate),'certificate_origin':'new',
                 'handoff_corrections':[asdict(c) for c in choice.handoff.corrections],
                 'warnings':warning_rows,'objective_check':observed,'phase_seconds':phase_seconds[-1],'peak_rss_mib':rss(),
                 'planning_problem_sha256':digest(asdict(call)),'state_before_sha256':before,
                 'scenario_probabilities':{s.name:s.probability for s in call.scenarios},
                 'action':asdict(choice.action),'ledger':asdict(ledger)}
            record['periods'].append(row)
            public_row={k:v for k,v in row.items() if k not in ('action','ledger')}|{'action_sha256':action_digest(row['action'])}
            with (folder/'period_evidence.jsonl').open('ab') as stream:stream.write(canonical(public_row))
            check()
        record.update(status='completed',final_state_sha256=digest(asdict(state)))
        record['pre_revelation']=prefix(record,case.contract.revelation_period)
        if profile:
            record['periods']=[{k:v for k,v in r.items() if k not in ('action','ledger')}|{'action_sha256':action_digest(r['action'])} for r in record['periods']]
        else:record['totals']=totals(record['periods'])
    except Exception as e:
        failure={'path_id':task['path_id'],'period':t,'type':type(e).__name__,'full_error_text':str(e),'traceback':traceback.format_exc(),
                 'certificate':asdict(e.certificate) if isinstance(e,planner.PlannerFailure) else call_cert,'last_objective_check':observed,
                 'warnings':[{'category':w.category.__name__,'message':str(w.message)} for w in captured]}
        record.update(status='failed',failure=failure)
        if profile:
            record['periods']=[{k:v for k,v in r.items() if k not in ('action','ledger')} for r in record['periods']]
    finally:
        planner._solve=old;signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
    record['resources']={'mip_phases':phases,'phase_seconds':phase_seconds,'wall_seconds':time.monotonic()-start,'peak_rss_mib':rss()}
    write(folder/'path.json',record)
    return 1 if failure else 0

def run(path):
    m=authorize(path);out=repository_path(m['output']);out.mkdir();start=time.monotonic();phases=0;completed=[];summaries=[];prefixes=[];failures=[];workers=[];active=None;index=None
    write(out/'attempt.json',{'manifest_sha256':sha(path),'receipt_sha256':sha(repository_path(m['receipt_path'])),
                            'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
    caps=m['caps'];items={i['case_id']:i for i in m['catalog']};profile=m['mode']=='profile'
    def check():
        if time.monotonic()-start>caps['wall_seconds']:raise ResourceStop('total wall cap')
        if rss()>caps['peak_rss_mib_per_process']:raise ResourceStop('parent memory cap')
        if bytes_used(out)>caps['saved_bytes']-1048576:raise ResourceStop('saved output cap')
    try:
        for index,task in enumerate(m['tasks']):
            active=task['path_id'];check();case=variant(items[task['case_id']],task['commitment'])
            if task['cache']:
                if profile:raise ValueError('profile cannot reuse scientific output')
                with forbid_solves():record=replay_cache(case,task,read_cache(task['cache']))
                record['pre_revelation']=prefix(record,case.contract.revelation_period)
                write(out/f'cache-{index:04d}.json',record)
            else:
                if phases+20>caps['maximum_mip_phases']:raise ResourceStop('new phase reservation exceeds cap')
                left=caps['wall_seconds']-(time.monotonic()-start)
                command=[sys.executable,str(HERE/'runner.py'),'--manifest',str(path),'--worker-index',str(index)]
                stderr=out/f'worker-{index:04d}.stderr.txt';stdout=out/f'worker-{index:04d}.stdout.txt'
                try:
                    with stdout.open('w') as so,stderr.open('w') as se:
                        proc=subprocess.run(command,stdout=so,stderr=se,timeout=min(left,caps['worker_wall_seconds']+10),cwd=ROOT)
                finally:
                    account=out/f'worker-{index:04d}/solve_account.json'
                    if account.exists():phases+=read(account)['phases_started']
                result=out/f'worker-{index:04d}/path.json'
                if not result.exists():raise RuntimeError('worker failed without final record; exit '+str(proc.returncode)+'; '+stderr.read_text())
                record=read(result);workers.append(record['resources'])
                if record['status']!='completed' or proc.returncode:
                    failures.append(record.get('failure',{'path_id':active,'full_error_text':stderr.read_text(),'exit_code':proc.returncode}));break
            if record['status']!='completed':raise ValueError('incomplete path')
            completed.append(active);prefixes.append({'task':task,'pre_revelation':record['pre_revelation']})
            check_prefixes(prefixes)
            if not profile:summaries.append({'task':task,'totals':record['totals']})
            del record;check()
        if not failures and len(completed)==len(m['tasks']):
            check_bindings(m)
            write(out/'nonanticipativity.json',{'pairs_checked':check_prefixes(prefixes),'exact_action_and_input_agreement':True})
            if not profile:
                write(out/'path_totals.json',summaries)
                write(out/'descriptive_report.json',build_report(summaries,m['catalog']))
        check()
    except Exception as e:
        failures.append({'path_id':active,'task_index':index,'type':type(e).__name__,'full_error_text':str(e),'traceback':traceback.format_exc()})
    result={'status':'completed' if len(completed)==len(m['tasks']) and not failures else 'stopped','manifest_sha256':sha(path),
        'mode':m['mode'],'completed_paths':len(completed),'path_ids':completed,'mip_phases':phases,'failures':failures,
        'elapsed_seconds':time.monotonic()-start,'parent_peak_rss_mib':rss(),'worker_peak_rss_mib':max((r['peak_rss_mib'] for r in workers),default=0),
        'maximum_worker_wall_seconds':max((r['wall_seconds'] for r in workers),default=0),'new_workers_completed':len(workers),
        'phase_seconds':[t for r in workers for t in r['phase_seconds']],
        'files':{str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},
        'strategic_outputs_saved':not profile,'confirmation_access':False,'new_tests_or_intervals':False,'retries':0}
    write(out/'result.json',result)
    print(json.dumps({k:v for k,v in result.items() if k not in ('files','phase_seconds','path_ids')},indent=2))
    return 0 if result['status']=='completed' else 1

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--manifest',type=Path,required=True);p.add_argument('--worker-index',type=int);a=p.parse_args()
    sys.exit(run(a.manifest.resolve()) if a.worker_index is None else worker(a.manifest.resolve(),a.worker_index))
