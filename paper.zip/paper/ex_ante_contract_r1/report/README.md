# Descriptive ex ante contract comparison

All networks and all 25 probability combinations are retained. Negative cost differences favor through-horizon; exact equality selects finite. Cells are tested grid points, with no interpolation. Supplier reporting probabilities are exogenous. No new hypotheses or intervals.

Full per-network costs, decomposition, preferences, premiums and incentive signs are in the CSV files. Manuscript integration remains subject to owner result review.
