# Ex ante contract comparison: verified descriptive results

14 November 2026. Public design networks only. No manuscript integration.

All 1,680 paths completed and passed independent physical replay and exact saved-decimal report checks. Finite commitment is strictly cheaper in 576 of 600 network–probability comparisons. The remaining 24 comparisons are exact cost ties, resolved toward finite under the declared rule. Through-horizon commitment is never cheaper on this grid. No nonzero difference lies within the 1e-6 near-tie flag.

At equal family weights, the through-horizon minus finite expected-cost difference ranges from 0.194450 to 3.809250. Arithmetic network means give the same preference in every probability cell, with differences from 0.194609 to 3.809115.

## Interpretation

The proposed operating-cost versus incentive tradeoff does not appear on this grid. Extending the commitment raises the long supplier's conditional misreporting gain in 352 paired comparisons and leaves it unchanged in 248; it never lowers that gain. Finite commitment weakly minimizes both expected buyer operating cost and the conditional supplier gain here. It does not eliminate profitable misreporting in every network.

These comparisons hold the same externally specified reporting likelihood under both contracts. They do not determine contract-specific reporting equilibria. The grid uses the 24 public window networks, the declared rolling planner and fixed economic inputs. All outcomes are descriptive; no new test or interval was computed. Buyer costs exclude supplier damages receipts and the solver tie term.

The break-even premium is finite cost minus through-horizon cost for an unconditional up-front fee. Every reported premium is nonpositive. A negative premium denotes the discount the longer contract needs to reach equal expected cost; equality still selects finite. This calculation does not reprice a qualification-contingent fee.

All tables below read `paper/ex_ante_contract_r1/study_execution_r3/descriptive_report.json` (SHA-256 `de8810d45034f4d665cd18eb6cdd9892d9424abdfe7e978ec00daeb48b625c40`). Row/column pointers are in `RESULT_SOURCE_MAP.json`; exact rational values and all cases are retained in the CSV files.

## Expected cost and contract preference: Equal family weights

All probability cells; cost difference = through-horizon minus finite. Counts are unweighted networks; the finite choice count includes exact ties.

| μ | β | α | Finite cost | Horizon cost | Difference | Premium | Finite choice | Horizon choice | Exact ties |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.1 | 0 | 1 | 30.996862 | 31.377762 | 0.380900 | -0.380900 | 24 | 0 | 0 |
| 0.1 | 0.25 | 36/37 | 31.586028 | 31.871703 | 0.285675 | -0.285675 | 24 | 0 | 0 |
| 0.1 | 0.5 | 18/19 | 32.171194 | 32.365644 | 0.194450 | -0.194450 | 24 | 0 | 0 |
| 0.1 | 0.75 | 12/13 | 32.658497 | 32.859584 | 0.201088 | -0.201088 | 24 | 0 | 0 |
| 0.1 | 1 | 9/10 | 33.112313 | 33.353525 | 0.241212 | -0.241212 | 24 | 0 | 19 |
| 0.25 | 0 | 1 | 33.470156 | 34.422406 | 0.952250 | -0.952250 | 24 | 0 | 0 |
| 0.25 | 0.25 | 12/13 | 34.854852 | 35.657258 | 0.802406 | -0.802406 | 24 | 0 | 0 |
| 0.25 | 0.5 | 6/7 | 35.642688 | 36.877672 | 1.234984 | -1.234984 | 24 | 0 | 0 |
| 0.25 | 0.75 | 4/5 | 36.132258 | 37.821430 | 1.689172 | -1.689172 | 24 | 0 | 0 |
| 0.25 | 1 | 3/4 | 36.316000 | 38.501438 | 2.185437 | -2.185437 | 24 | 0 | 5 |
| 0.5 | 0 | 1 | 37.592312 | 39.496812 | 1.904500 | -1.904500 | 24 | 0 | 0 |
| 0.5 | 0.25 | 4/5 | 39.367047 | 41.762828 | 2.395781 | -2.395781 | 24 | 0 | 0 |
| 0.5 | 0.5 | 2/3 | 39.717531 | 42.782781 | 3.065250 | -3.065250 | 24 | 0 | 0 |
| 0.5 | 0.75 | 4/7 | 39.760625 | 43.164641 | 3.404016 | -3.404016 | 24 | 0 | 0 |
| 0.5 | 1 | 1/2 | 39.761313 | 43.406000 | 3.644687 | -3.644687 | 24 | 0 | 0 |
| 0.75 | 0 | 1 | 41.714469 | 44.571219 | 2.856750 | -2.856750 | 24 | 0 | 0 |
| 0.75 | 0.25 | 4/7 | 42.798625 | 46.405133 | 3.606508 | -3.606508 | 24 | 0 | 0 |
| 0.75 | 0.5 | 2/5 | 42.799656 | 46.608906 | 3.809250 | -3.809250 | 24 | 0 | 0 |
| 0.75 | 0.75 | 4/13 | 42.800688 | 46.609938 | 3.809250 | -3.809250 | 24 | 0 | 0 |
| 0.75 | 1 | 1/4 | 42.801719 | 46.610969 | 3.809250 | -3.809250 | 24 | 0 | 0 |
| 0.9 | 0 | 1 | 44.187762 | 47.615862 | 3.428100 | -3.428100 | 24 | 0 | 0 |
| 0.9 | 0.25 | 4/13 | 44.622250 | 48.431350 | 3.809100 | -3.809100 | 24 | 0 | 0 |
| 0.9 | 0.5 | 2/11 | 44.623488 | 48.432587 | 3.809100 | -3.809100 | 24 | 0 | 0 |
| 0.9 | 0.75 | 4/31 | 44.624725 | 48.433825 | 3.809100 | -3.809100 | 24 | 0 | 0 |
| 0.9 | 1 | 1/10 | 44.625962 | 48.435063 | 3.809100 | -3.809100 | 24 | 0 | 0 |

## Reporting-cost decomposition: Equal family weights

Precaution is the weighted change in buyer cost on truthful-short paths. Misreport is the weighted long/minor versus long/major cost change. Their sum is the increase over the truthful-reporting benchmark.

| μ | β | Finite precaution | Finite misreport | Finite total | Horizon precaution | Horizon misreport | Horizon total |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.1 | 0.25 | 0.000000 | 0.589166 | 0.589166 | 0.000000 | 0.493941 | 0.493941 |
| 0.1 | 0.5 | 0.072000 | 1.102331 | 1.174331 | 0.000000 | 0.987881 | 0.987881 |
| 0.1 | 0.75 | 0.234000 | 1.427634 | 1.661634 | 0.000000 | 1.481822 | 1.481822 |
| 0.1 | 1 | 0.375750 | 1.739700 | 2.115450 | 0.000000 | 1.975762 | 1.975762 |
| 0.25 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.25 | 0.25 | 0.195000 | 1.189695 | 1.384695 | 0.000000 | 1.234852 | 1.234852 |
| 0.25 | 0.5 | 1.003125 | 1.169406 | 2.172531 | 0.330000 | 2.125266 | 2.455266 |
| 0.25 | 0.75 | 1.704375 | 0.957727 | 2.662102 | 0.952500 | 2.446523 | 3.399023 |
| 0.25 | 1 | 2.161875 | 0.683969 | 2.845844 | 1.447500 | 2.631531 | 4.079031 |
| 0.5 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.5 | 0.25 | 1.136250 | 0.638484 | 1.774734 | 0.635000 | 1.631016 | 2.266016 |
| 0.5 | 0.5 | 1.441250 | 0.683969 | 2.125219 | 2.318750 | 0.967219 | 3.285969 |
| 0.5 | 0.75 | 2.166250 | 0.002062 | 2.168312 | 2.943750 | 0.724078 | 3.667828 |
| 0.5 | 1 | 2.166250 | 0.002750 | 2.169000 | 2.943750 | 0.965437 | 3.909187 |
| 0.75 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.75 | 0.25 | 1.083125 | 0.001031 | 1.084156 | 1.471875 | 0.362039 | 1.833914 |
| 0.75 | 0.5 | 1.083125 | 0.002062 | 1.085187 | 2.035625 | 0.002062 | 2.037688 |
| 0.75 | 0.75 | 1.083125 | 0.003094 | 1.086219 | 2.035625 | 0.003094 | 2.038719 |
| 0.75 | 1 | 1.083125 | 0.004125 | 1.087250 | 2.035625 | 0.004125 | 2.039750 |
| 0.9 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.9 | 0.25 | 0.433250 | 0.001237 | 0.434487 | 0.814250 | 0.001237 | 0.815487 |
| 0.9 | 0.5 | 0.433250 | 0.002475 | 0.435725 | 0.814250 | 0.002475 | 0.816725 |
| 0.9 | 0.75 | 0.433250 | 0.003712 | 0.436962 | 0.814250 | 0.003712 | 0.817962 |
| 0.9 | 1 | 0.433250 | 0.004950 | 0.438200 | 0.814250 | 0.004950 | 0.819200 |

## Conditional supplier incentive: Equal family weights

G uses r=0.5 and κ=5, with liability multiplier 1 and no fixed contradiction cost. Positive/consistent counts are unweighted networks. A conditional gain is retained even when the corresponding minor report has zero ex ante probability. “Consistent” checks the declared endpoint/interior best-response condition only; it does not establish an equilibrium.

| μ | β | Finite G | Horizon G | Finite positive /24 | Horizon positive /24 | Finite consistent /24 | Horizon consistent /24 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.1 | 0 | -1.950000 | 4.530000 | 8 | 24 | 16 | 0 |
| 0.1 | 0.25 | -1.950000 | 4.530000 | 8 | 24 | 0 | 0 |
| 0.1 | 0.5 | -1.790000 | 4.530000 | 8 | 24 | 1 | 0 |
| 0.1 | 0.75 | -1.910000 | 4.530000 | 7 | 24 | 2 | 0 |
| 0.1 | 1 | -2.000000 | 4.530000 | 7 | 24 | 9 | 24 |
| 0.25 | 0 | -1.950000 | 4.530000 | 8 | 24 | 16 | 0 |
| 0.25 | 0.25 | -1.910000 | 4.530000 | 7 | 24 | 2 | 0 |
| 0.25 | 0.5 | -1.995000 | 4.115000 | 6 | 22 | 5 | 2 |
| 0.25 | 0.75 | -2.040000 | 3.410000 | 5 | 19 | 6 | 3 |
| 0.25 | 1 | -2.225000 | 3.025000 | 2 | 17 | 11 | 21 |
| 0.5 | 0 | -1.950000 | 4.530000 | 8 | 24 | 16 | 0 |
| 0.5 | 0.25 | -2.040000 | 3.410000 | 5 | 19 | 6 | 3 |
| 0.5 | 0.5 | -2.225000 | 0.513750 | 2 | 9 | 9 | 8 |
| 0.5 | 0.75 | -2.500000 | -0.771250 | 0 | 5 | 11 | 10 |
| 0.5 | 1 | -2.500000 | -0.771250 | 0 | 5 | 11 | 15 |
| 0.75 | 0 | -1.950000 | 4.530000 | 8 | 24 | 16 | 0 |
| 0.75 | 0.25 | -2.500000 | -0.771250 | 0 | 5 | 11 | 10 |
| 0.75 | 0.5 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |
| 0.75 | 0.75 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |
| 0.75 | 1 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |
| 0.9 | 0 | -1.950000 | 4.530000 | 8 | 24 | 16 | 0 |
| 0.9 | 0.25 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |
| 0.9 | 0.5 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |
| 0.9 | 0.75 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |
| 0.9 | 1 | -2.500000 | -2.450000 | 0 | 0 | 11 | 12 |

## Expected cost and contract preference: Arithmetic network means

All probability cells; cost difference = through-horizon minus finite. Counts are unweighted networks; the finite choice count includes exact ties.

| μ | β | α | Finite cost | Horizon cost | Difference | Premium | Finite choice | Horizon choice | Exact ties |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.1 | 0 | 1 | 31.333802 | 31.714688 | 0.380885 | -0.380885 | 24 | 0 | 0 |
| 0.1 | 0.25 | 36/37 | 31.926276 | 32.211940 | 0.285664 | -0.285664 | 24 | 0 | 0 |
| 0.1 | 0.5 | 18/19 | 32.514583 | 32.709193 | 0.194609 | -0.194609 | 24 | 0 | 0 |
| 0.1 | 0.75 | 12/13 | 33.000951 | 33.206445 | 0.205495 | -0.205495 | 24 | 0 | 0 |
| 0.1 | 1 | 9/10 | 33.454948 | 33.703698 | 0.248750 | -0.248750 | 24 | 0 | 19 |
| 0.25 | 0 | 1 | 33.850911 | 34.803125 | 0.952214 | -0.952214 | 24 | 0 | 0 |
| 0.25 | 0.25 | 12/13 | 35.240202 | 36.046257 | 0.806055 | -0.806055 | 24 | 0 | 0 |
| 0.25 | 0.5 | 6/7 | 36.025391 | 37.274349 | 1.248958 | -1.248958 | 24 | 0 | 0 |
| 0.25 | 0.75 | 4/5 | 36.512826 | 38.214258 | 1.701432 | -1.701432 | 24 | 0 | 0 |
| 0.25 | 1 | 3/4 | 36.695833 | 38.879427 | 2.183594 | -2.183594 | 24 | 0 | 5 |
| 0.5 | 0 | 1 | 38.046094 | 39.950521 | 1.904427 | -1.904427 | 24 | 0 | 0 |
| 0.5 | 0.25 | 4/5 | 39.820703 | 42.224609 | 2.403906 | -2.403906 | 24 | 0 | 0 |
| 0.5 | 0.5 | 2/3 | 40.169010 | 43.230469 | 3.061458 | -3.061458 | 24 | 0 | 0 |
| 0.5 | 0.75 | 4/7 | 40.211003 | 43.616016 | 3.405013 | -3.405013 | 24 | 0 | 0 |
| 0.5 | 1 | 1/2 | 40.211719 | 43.855208 | 3.643490 | -3.643490 | 24 | 0 | 0 |
| 0.75 | 0 | 1 | 42.241276 | 45.097917 | 2.856641 | -2.856641 | 24 | 0 | 0 |
| 0.75 | 0.25 | 4/7 | 43.323730 | 46.930664 | 3.606934 | -3.606934 | 24 | 0 | 0 |
| 0.75 | 0.5 | 2/5 | 43.324805 | 47.133919 | 3.809115 | -3.809115 | 24 | 0 | 0 |
| 0.75 | 0.75 | 4/13 | 43.325879 | 47.134993 | 3.809115 | -3.809115 | 24 | 0 | 0 |
| 0.75 | 1 | 1/4 | 43.326953 | 47.136068 | 3.809115 | -3.809115 | 24 | 0 | 0 |
| 0.9 | 0 | 1 | 44.758385 | 48.186354 | 3.427969 | -3.427969 | 24 | 0 | 0 |
| 0.9 | 0.25 | 4/13 | 45.192227 | 49.001185 | 3.808958 | -3.808958 | 24 | 0 | 0 |
| 0.9 | 0.5 | 2/11 | 45.193516 | 49.002474 | 3.808958 | -3.808958 | 24 | 0 | 0 |
| 0.9 | 0.75 | 4/31 | 45.194805 | 49.003763 | 3.808958 | -3.808958 | 24 | 0 | 0 |
| 0.9 | 1 | 1/10 | 45.196094 | 49.005052 | 3.808958 | -3.808958 | 24 | 0 | 0 |

## Reporting-cost decomposition: Arithmetic network means

Precaution is the weighted change in buyer cost on truthful-short paths. Misreport is the weighted long/minor versus long/major cost change. Their sum is the increase over the truthful-reporting benchmark.

| μ | β | Finite precaution | Finite misreport | Finite total | Horizon precaution | Horizon misreport | Horizon total |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.1 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.1 | 0.25 | 0.000000 | 0.592474 | 0.592474 | 0.000000 | 0.497253 | 0.497253 |
| 0.1 | 0.5 | 0.075000 | 1.105781 | 1.180781 | 0.000000 | 0.994505 | 0.994505 |
| 0.1 | 0.75 | 0.243750 | 1.423398 | 1.667148 | 0.000000 | 1.491758 | 1.491758 |
| 0.1 | 1 | 0.375000 | 1.746146 | 2.121146 | 0.000000 | 1.989010 | 1.989010 |
| 0.25 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.25 | 0.25 | 0.203125 | 1.186165 | 1.389290 | 0.000000 | 1.243132 | 1.243132 |
| 0.25 | 0.5 | 1.015625 | 1.158854 | 2.174479 | 0.343750 | 2.127474 | 2.471224 |
| 0.25 | 0.75 | 1.689453 | 0.972461 | 2.661914 | 0.992188 | 2.418945 | 3.411133 |
| 0.25 | 1 | 2.166016 | 0.678906 | 2.844922 | 1.507812 | 2.568490 | 4.076302 |
| 0.5 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.5 | 0.25 | 1.126302 | 0.648307 | 1.774609 | 0.661458 | 1.612630 | 2.274089 |
| 0.5 | 0.5 | 1.444010 | 0.678906 | 2.122917 | 2.296875 | 0.983073 | 3.279948 |
| 0.5 | 0.75 | 2.162760 | 0.002148 | 2.164909 | 2.947917 | 0.717578 | 3.665495 |
| 0.5 | 1 | 2.162760 | 0.002865 | 2.165625 | 2.947917 | 0.956771 | 3.904688 |
| 0.75 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.75 | 0.25 | 1.081380 | 0.001074 | 1.082454 | 1.473958 | 0.358789 | 1.832747 |
| 0.75 | 0.5 | 1.081380 | 0.002148 | 1.083529 | 2.033854 | 0.002148 | 2.036003 |
| 0.75 | 0.75 | 1.081380 | 0.003223 | 1.084603 | 2.033854 | 0.003223 | 2.037077 |
| 0.75 | 1 | 1.081380 | 0.004297 | 1.085677 | 2.033854 | 0.004297 | 2.038151 |
| 0.9 | 0 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 | 0.000000 |
| 0.9 | 0.25 | 0.432552 | 0.001289 | 0.433841 | 0.813542 | 0.001289 | 0.814831 |
| 0.9 | 0.5 | 0.432552 | 0.002578 | 0.435130 | 0.813542 | 0.002578 | 0.816120 |
| 0.9 | 0.75 | 0.432552 | 0.003867 | 0.436419 | 0.813542 | 0.003867 | 0.817409 |
| 0.9 | 1 | 0.432552 | 0.005156 | 0.437708 | 0.813542 | 0.005156 | 0.818698 |

## Conditional supplier incentive: Arithmetic network means

G uses r=0.5 and κ=5, with liability multiplier 1 and no fixed contradiction cost. Positive/consistent counts are unweighted networks. A conditional gain is retained even when the corresponding minor report has zero ex ante probability. “Consistent” checks the declared endpoint/interior best-response condition only; it does not establish an equilibrium.

| μ | β | Finite G | Horizon G | Finite positive /24 | Horizon positive /24 | Finite consistent /24 | Horizon consistent /24 |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 0.1 | 0 | -2.036458 | 4.447917 | 8 | 24 | 16 | 0 |
| 0.1 | 0.25 | -2.036458 | 4.447917 | 8 | 24 | 0 | 0 |
| 0.1 | 0.5 | -1.869792 | 4.447917 | 8 | 24 | 1 | 0 |
| 0.1 | 0.75 | -1.994792 | 4.447917 | 7 | 24 | 2 | 0 |
| 0.1 | 1 | -2.078125 | 4.447917 | 7 | 24 | 9 | 24 |
| 0.25 | 0 | -2.036458 | 4.447917 | 8 | 24 | 16 | 0 |
| 0.25 | 0.25 | -1.994792 | 4.447917 | 7 | 24 | 2 | 0 |
| 0.25 | 0.5 | -2.057292 | 4.015625 | 6 | 22 | 5 | 2 |
| 0.25 | 0.75 | -2.088542 | 3.281250 | 5 | 19 | 6 | 3 |
| 0.25 | 1 | -2.281250 | 2.880208 | 2 | 17 | 11 | 21 |
| 0.5 | 0 | -2.036458 | 4.447917 | 8 | 24 | 16 | 0 |
| 0.5 | 0.25 | -2.088542 | 3.281250 | 5 | 19 | 6 | 3 |
| 0.5 | 0.5 | -2.281250 | 0.505208 | 2 | 9 | 9 | 8 |
| 0.5 | 0.75 | -2.552083 | -0.833333 | 0 | 5 | 11 | 10 |
| 0.5 | 1 | -2.552083 | -0.833333 | 0 | 5 | 11 | 15 |
| 0.75 | 0 | -2.036458 | 4.447917 | 8 | 24 | 16 | 0 |
| 0.75 | 0.25 | -2.552083 | -0.833333 | 0 | 5 | 11 | 10 |
| 0.75 | 0.5 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |
| 0.75 | 0.75 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |
| 0.75 | 1 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |
| 0.9 | 0 | -2.036458 | 4.447917 | 8 | 24 | 16 | 0 |
| 0.9 | 0.25 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |
| 0.9 | 0.5 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |
| 0.9 | 0.75 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |
| 0.9 | 1 | -2.552083 | -2.500000 | 0 | 0 | 11 | 12 |

## Exact ties

| Network | μ | β | α |
|---|---:|---:|---:|
| v3-c0-r1-interior-serial-small-2 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-serial-large-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-assembly-small-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-assembly-small-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-assembly-large-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-assembly-large-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-assembly-large-1 | 0.25 | 1 | 3/4 |
| v3-c0-r1-interior-assembly-large-2 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-assembly-large-2 | 0.25 | 1 | 3/4 |
| v3-c0-r1-interior-distribution-small-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-distribution-small-0 | 0.25 | 1 | 3/4 |
| v3-c0-r1-interior-distribution-small-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-distribution-large-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-layered_dual-small-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-layered_dual-small-2 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-layered_dual-large-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-layered_dual-large-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-planted-small-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-planted-small-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-planted-small-1 | 0.25 | 1 | 3/4 |
| v3-c0-r1-interior-planted-large-0 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-planted-large-1 | 0.1 | 1 | 9/10 |
| v3-c0-r1-interior-planted-large-1 | 0.25 | 1 | 3/4 |
| v3-c0-r1-interior-planted-large-2 | 0.1 | 1 | 9/10 |

## One grid point in detail

At μ=0.50 and β=0.50, α=2/3. Equal-family expected buyer cost is 39.717531 under finite and 42.782781 under through-horizon commitment, a difference of 3.065250. Finite's precaution and long-misreport components are 1.441250 and 0.683969; through-horizon's are 2.318750 and 0.967219. Conditional supplier gain is -2.225000 versus 0.513750.

## Execution and verification

R3 reused 1,321 cached paths and completed 359 new paths with 7,180 MIPs. It took 864.792 seconds. Parent/worker peak RSS was 109.094/99.047 MiB. New certificates had maximum absolute/relative gap 0.0/0.0, 0 new warning records and 0 hand-off corrections. Failures: 0; automatic retries: 0.

Independent verification used zero solves and checked all 1,680 paths, 816 common-state short/long pairs before revelation, 1,200 network-contract rows, 600 paired rows and 50 aggregate rows. All 1,589 protected files and 1,375 execution bindings remain unchanged. All stored certificates are available in the path records.

R1 stopped after an uncertified time-limit return; the owner reported a computer interruption. R2 reached its one-hour wall cap. Both attempts and their partial records are retained. R3 restarted only the unfinished path work; the 14 partial R2 solves remain counted. Cumulative use is 38,800 study MIPs including stopped attempts, or 39,600 with profiling. The historical fractional-belief warning remains unresolved under the previously accepted reuse disposition. This completion does not clear that historical warning. These numerical records remain outside the main manuscript.

- Execution manifest: `322f6461be4c605ae4e0fe78b60e7e4a379459e4eb0310f6d8c83b8101ff153b`
- Result: `46b35f86ea4a8dbe962dd0ab53580d99d512df4f0f9e1c16998c16c75a5d5bdb`
- Independent verification: `97699f920ec931511e172e1b0f3af5715b3fe6d957c05c33b8a78cbd4da2c283`
- Descriptive report: `de8810d45034f4d665cd18eb6cdd9892d9424abdfe7e978ec00daeb48b625c40`

No manuscript integration, confirmation access, hosting or submission occurred. M5, the LLM arm and the equilibrium grid remain paused. Owner review is the next step.
