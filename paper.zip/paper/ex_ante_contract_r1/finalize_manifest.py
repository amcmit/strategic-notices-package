"""After approved profiling only: price and bind the unrun full proposal."""
from pathlib import Path
import math
from common import *

def finalize():
    profile=HERE/'profile_manifest.json';p=authorize(profile);out=ROOT/p['output'];r=read(out/'result.json');v=read(out/'verification.json')
    if r['status']!='completed' or r['failures'] or r['completed_paths']!=40 or r['mip_phases']!=800 or v['status']!='verified' or v['result_sha256']!=sha(out/'result.json') or v['manifest_sha256']!=sha(profile):raise ValueError('complete verified profile required')
    m=read(HERE/'study_manifest.json');check_bindings(m)
    m['status']='ready_for_owner_hash_approval';m['measured_caps']=True
    m['caps']['wall_seconds']=max(3600,60*math.ceil(2*r['elapsed_seconds']*1416/40/60))
    m['caps']['peak_rss_mib_per_process']=max(512,64*math.ceil(2*max(r['parent_peak_rss_mib'],r['worker_peak_rss_mib'])/64))
    # Profile excludes ledgers. Use the maximum complete public path for storage.
    records=[PAIRED/name for name in read(PAIRED/'result.json')['files'] if name.startswith('path-')]
    maximum=max(p.stat().st_size for p in records)
    m['caps']['saved_bytes']=max(1073741824,8*maximum*1680)
    bound=[profile,out/'result.json',out/'verification.json',ROOT/p['receipt_path']]
    m['prerequisite_sha256']={str(p.relative_to(ROOT)):sha(p) for p in bound}
    m['cap_measurements']={'profile_wall_seconds':r['elapsed_seconds'],'profile_workers':40,'profile_new_mips':800,
        'parent_peak_rss_mib':r['parent_peak_rss_mib'],'worker_peak_rss_mib':r['worker_peak_rss_mib'],
        'complete_public_path_max_bytes':maximum,'wall_headroom':2,'memory_headroom':2,'path_storage_headroom':8,
        'limitation':'profile covers ten family-size strata at posterior 2/3; all posterior levels remain a full-run risk'}
    target=HERE/'study_execution_manifest.json'
    if target.exists():raise FileExistsError('preserve prior proposal')
    write(target,m);print(sha(target))

if __name__=='__main__':finalize()
