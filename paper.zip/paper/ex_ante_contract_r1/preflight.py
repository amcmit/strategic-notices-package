"""Zero-solve process/import/RSS/output preflight. Does not consume an attempt."""
from pathlib import Path
import json,resource,subprocess,sys,tempfile
from common import HERE,ROOT,forbid_solves,write,environment


def child(destination):
    with forbid_solves():
        peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1048576 if sys.platform=='darwin' else 1024)
        value={'status':'passed','environment':environment(),'peak_rss_mib':peak,'mip_solves':0}
        write(destination,value);print(json.dumps(value))

def run():
    with tempfile.TemporaryDirectory(dir=HERE) as d:
        path=Path(d)/'child.json'
        result=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--child',str(path)],cwd=ROOT,capture_output=True,text=True,timeout=30)
        if result.returncode:raise RuntimeError(result.stdout+'\n'+result.stderr)
        record=json.loads(path.read_text())
        if json.loads(result.stdout)!=record or record['mip_solves']!=0 or record['peak_rss_mib']>512:raise ValueError('preflight IPC/memory failure')
        write(HERE/'PREFLIGHT.json',{'status':'passed','child':record,'full_stderr':result.stderr,'receipts_created':False,'execution_attempt_consumed':False})
        print(json.dumps(record,indent=2))

if __name__=='__main__':
    child(Path(sys.argv[2])) if len(sys.argv)>1 and sys.argv[1]=='--child' else run()
