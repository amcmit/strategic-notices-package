"""Independent exact-number checks for an approved map output; no solves."""
from pathlib import Path
from fractions import Fraction
import csv,hashlib,json
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
F=lambda x:Fraction(str(x))

def verify():
    m=read(HERE/'manifest.json');r=read(HERE/'output/RESULT.json')
    if r['status']!='completed' or r['failures'] or r['manifest_sha256']!=sha(HERE/'manifest.json'):raise ValueError('completed bound map required')
    for group in ['source_sha256','input_sha256']:
        for path,value in m[group].items():
            if sha(ROOT/path)!=value:raise ValueError('bound input changed')
    receipt=read(HERE/'owner_approval.json')
    if receipt.get('decision')!=m['receipt_decision'] or receipt.get('execution_manifest_sha256')!=sha(HERE/'manifest.json'):raise ValueError('approval differs')
    for name,value in r['files'].items():
        if sha(HERE/'output'/name)!=value:raise ValueError('output changed')
    factors={x['case_id']:x['commitment'] for x in read(ROOT/'configs/proposed-v3-allocation.json')['candidates'][0]['cases']}
    factors.update({x['case_id']:x['factors']['commitment'] for x in read(ROOT/'configs/v3-confirmation-public.json')['cases']})
    rows={d:read(ROOT/f'results/{folder}/result.json')['case_rows'] for d,folder in [('design','v3_design_false_notice_r2'),('confirmation','v3_confirmation_opening')]}
    functions=read(HERE/'output/NETWORK_FUNCTIONS.json');regions=read(HERE/'output/REGIONS.json');grid=list(csv.DictReader((HERE/'output/DISPLAY_GRID.csv').open()))
    if (len(functions),len(regions),len(grid))!=(112,24,40824):raise ValueError('incomplete output')
    co={};seen=set()
    for row in functions:
        key=row['dataset'],row['case_id']
        if key in seen:raise ValueError('duplicate network')
        seen.add(key);source=next(x for x in rows[key[0]] if x['case_id']==key[1]);c=source['cells'];a=F(c['C11']['primary'])-F(c['C00']['primary']);s=F(c['C11']['accepted_shortfall'])-F(c['C00']['accepted_shortfall'])
        if Fraction(row['delivery_coefficient'])!=a or Fraction(row['shortfall_coefficient'])!=s or row['commitment']!=factors[key[1]]:raise ValueError('network coefficient')
        co[key]=(a,s)
    means={}
    for row in regions:
        key=row['dataset'],row['population'],row['group'],row['weighting']
        if key in means:raise ValueError('duplicate group')
        selected=[x for x in rows[key[0]] if (key[1]=='all_56' or (x['regime']=='R1' and x['category']=='interior')) and (key[2]=='all' or factors[x['case_id']]==key[2])]
        if len(selected)!=row['n']:raise ValueError('group size')
        families=sorted({x['family'] for x in selected});groups=[selected] if key[3]=='arithmetic' else [[x for x in selected if x['family']==f] for f in families]
        values=tuple(sum((sum((co[key[0],x['case_id']][j] for x in group),Fraction())/len(group) for group in groups),Fraction())/len(groups) for j in [0,1]);a,s=values
        if values!=(Fraction(row['delivery_coefficient']),Fraction(row['shortfall_coefficient'])):raise ValueError('weighted coefficient')
        for name,eps in [('polygon_closure',Fraction()),('tolerance_positive_polygon_closure',Fraction(1,100000000))]:
            points=[(Fraction(x),Fraction(y)) for x,y in row[name]]
            # Independently enumerate all rectangle corners and all intersections
            # of the zero line with its four edges, then compare vertex sets.
            candidates=[(Fraction(0),Fraction(0)),(Fraction(1),Fraction(0)),(Fraction(1),Fraction(20)),(Fraction(0),Fraction(20))]
            if s:candidates += [(x,(a*x-eps)/s) for x in [Fraction(0),Fraction(1)]]
            if a:candidates += [((eps+s*y)/a,y) for y in [Fraction(0),Fraction(20)]]
            expected={(x,y) for x,y in candidates if 0<=x<=1 and 0<=y<=20 and a*x-s*y>=eps}
            if max(a*x-s*y-eps for x,y in [(0,0),(1,0),(1,20),(0,20)])<=0:expected=set()
            if set(points)!=expected:raise ValueError('positive region geometry')
        means[key]=values
    seen=set()
    for row in grid:
        key=tuple(row[x] for x in ['dataset','population','group','weighting']);rr,kk=F(row['r']),F(row['kappa']);identity=(*key,rr,kk)
        if identity in seen:raise ValueError('duplicate grid cell')
        seen.add(identity);a,s=means[key];gain=a*rr-s*kk
        if Fraction(row['gain_exact'])!=gain or abs(float(row['gain'])-float(gain))>1e-12:raise ValueError('grid gain')
        label='positive' if gain>Fraction(1,100000000) else 'negative' if gain < -Fraction(1,100000000) else 'numerical_zero'
        if row['numeric_sign']!=label or row['mathematically_positive']!=str(gain>0):raise ValueError('grid sign')
    answer={'status':'verified','result_sha256':sha(HERE/'output/RESULT.json'),'networks':112,'groups':24,'grid_cells':40824,'solves':0,'private_access':False}
    with (HERE/'output/VERIFICATION.json').open('x') as f:json.dump(answer,f,indent=2);f.write('\n')
    print(json.dumps(answer,indent=2))

if __name__=='__main__':verify()
