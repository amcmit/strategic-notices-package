"""Synthetic arithmetic tests only; real evidence repricing remains unrun."""
from fractions import Fraction as F
import unittest
import incentive_map as m

class Tests(unittest.TestCase):
    def test_gain_identity_and_zero_shortfall(self):
        row={'cells':{'C00':{'primary':1,'accepted_shortfall':0},'C11':{'primary':3,'accepted_shortfall':1}}}
        self.assertEqual(m.coefficients(row),(2,1));self.assertEqual(F(1,2)*2-5,-4)
        row['cells']['C11']['accepted_shortfall']=0;self.assertEqual(m.coefficients(row),(2,0))
    def test_empty_and_all_positive_domains(self):
        self.assertEqual(m.positive_polygon(F(0),F(0)),[])
        self.assertEqual(m.positive_polygon(F(-1),F(1)),[])
        self.assertEqual(len(m.positive_polygon(F(1),F(0))),4)
    def test_exact_boundary_polygon(self):
        points=m.positive_polygon(F(2),F(1));self.assertIn((F(1),F(2)),points)
        self.assertTrue(all(2*r-k>=0 for r,k in points))
    def test_negative_shortfall(self):
        points=m.positive_polygon(F(-1),F(-1));self.assertTrue(points)
        self.assertTrue(all(-r+k>=0 for r,k in points))
    def test_tolerance_and_boundary(self):
        points=m.positive_polygon(F(2),F(1),m.EPS)
        self.assertTrue(all(2*r-k>=m.EPS for r,k in points))
        self.assertNotIn((F(0),F(0)),points)
    def test_equal_family_weighting(self):
        rows=[]
        for family in m.FAMILIES:
            for _ in range(5 if family=='serial' else 1):
                rows.append({'family':family,'cells':{'C00':{'primary':0,'accepted_shortfall':0},'C11':{'primary':int(family=='serial'),'accepted_shortfall':0}}})
        self.assertEqual(m.mean_coefficients(rows,'arithmetic'),(F(5,9),0))
        self.assertEqual(m.mean_coefficients(rows,'equal_family'),(F(1,5),0))
        with self.assertRaises(ValueError):m.mean_coefficients(rows[:1],'equal_family')

if __name__=='__main__':unittest.main(verbosity=2)
