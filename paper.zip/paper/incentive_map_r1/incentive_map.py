"""Unrun, solver-free two-parameter repricing of saved derived outcome rows.

No study imports, simulation, resampling, statistical tests or private files.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import argparse,csv,hashlib,json,math,resource,signal,sys,time,traceback
ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
F=lambda x:Fraction(str(x));EPS=Fraction(1,100000000)
FAMILIES=['assembly','distribution','layered_dual','planted','serial']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())

def write(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def coefficients(row):
    truth,false=row['cells']['C00'],row['cells']['C11']
    return F(false['primary'])-F(truth['primary']), F(false['accepted_shortfall'])-F(truth['accepted_shortfall'])

def mean_coefficients(rows,weighting):
    if not rows:raise ValueError('empty group')
    if weighting=='arithmetic':
        pairs=[coefficients(row) for row in rows]
        return tuple(sum((x[k] for x in pairs),Fraction())/len(pairs) for k in [0,1])
    if weighting!='equal_family':raise ValueError('unknown weighting')
    if sorted({r['family'] for r in rows})!=FAMILIES:raise ValueError('missing family in prespecified group')
    means=[mean_coefficients([r for r in rows if r['family']==family],'arithmetic') for family in FAMILIES]
    return tuple(sum((x[k] for x in means),Fraction())/5 for k in [0,1])

def positive_polygon(a,s,epsilon=Fraction()):
    """Closure of rectangle intersection a*r-s*kappa > epsilon.
    Boundary segments are excluded by the separately reported strict inequality.
    Identically zero/non-positive domains return empty, not the whole rectangle.
    """
    corners=[(Fraction(0),Fraction(0)),(Fraction(1),Fraction(0)),(Fraction(1),Fraction(20)),(Fraction(0),Fraction(20))]
    value=lambda v:a*v[0]-s*v[1]-epsilon
    if max(map(value,corners))<=0:return []
    polygon=[]
    for start,end in zip(corners,corners[1:]+corners[:1]):
        f,g=value(start),value(end)
        if f>=0:polygon.append(start)
        if (f<0<=g) or (g<0<=f):
            t=f/(f-g);point=tuple(start[j]+t*(end[j]-start[j]) for j in [0,1])
            polygon.append(point)
    unique=[]
    for point in polygon:
        if not unique or point!=unique[-1]:unique.append(point)
    if len(unique)>1 and unique[0]==unique[-1]:unique.pop()
    return unique

def bindings():
    names=['configs/proposed-v3-allocation.json','configs/v3-confirmation-public.json',
           'paper/margin_repricing_r1/VERIFICATION.json','paper/margin_repricing_r1/output/NETWORK_FUNCTIONS.json']
    names += [f'results/{dataset}/{name}' for dataset in ['v3_design_false_notice_r2','v3_confirmation_opening'] for name in ['result.json','verification.json']]
    return {n:sha(ROOT/n) for n in names}

def prepare():
    m={'schema':1,'status':'unrun_requires_owner_source_and_hash_approval','source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in sorted(HERE.glob('*.py'))},
        'input_sha256':bindings(),'domain':{'margin':[0,1],'penalty':[0,20],'purchase_price':1,'lambda':1,'F':0,
            'exact_region':'a*r-s*kappa>0; a=mean(P_C11-P_C00), s=mean(A_C11-A_C00)',
            'numeric_classification':'positive above 1e-8; negative below -1e-8; otherwise numerical_zero',
            'margin_grid_fractions':[str(Fraction(i,20)) for i in range(21)],'penalty_display_fractions':[str(Fraction(i,4)) for i in range(81)]},
        'datasets':['design','confirmation'],'populations':['all_56','window_24'],'groups':['all','finite','horizon'],
        'weights':['arithmetic','equal_family'],'figure_weight':'equal_family','figures':['incentive_regions_window.pdf','incentive_regions_all56.pdf'],
        'interpretation':'post-confirmation descriptive repricing of fixed policies; commitment subgroups remain unpaired associations',
        'privacy':'derived result rows and public metadata only; no private cases, progress, seed or mount',
        'caps':{'wall_seconds':120,'peak_rss_mib':512,'saved_bytes':67108864,'mip_solves':0,'simulation_transitions':0,'retries':0},
        'no_new_tests_intervals_or_confirmatory_decisions':True,'receipt_decision':'owner_approved_incentive_map_r1'}
    write(HERE/'manifest.json',m);print(json.dumps({'manifest_sha256':sha(HERE/'manifest.json'),'source_sha256':sha(HERE/'incentive_map.py'),'executed':False}))

def check(m):
    for group in ['source_sha256','input_sha256']:
        for name,want in m[group].items():
            p=(ROOT/name).resolve()
            if not p.is_relative_to(ROOT) or sha(p)!=want:raise ValueError('binding mismatch: '+name)
    receipt=read(HERE/'owner_approval.json')
    if receipt.get('decision')!=m['receipt_decision'] or receipt.get('execution_manifest_sha256')!=sha(HERE/'manifest.json'):raise PermissionError('exact-hash approval required')

def csvout(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def draw(rows,population,dest,manifest_hash):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Polygon
    plt.rcParams.update({'font.family':'serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axes=plt.subplots(2,3,figsize=(8.0,5.0),sharex=True,sharey=True,constrained_layout=True)
    for i,dataset in enumerate(['design','confirmation']):
        for j,group in enumerate(['all','finite','horizon']):
            row=next(r for r in rows if (r['dataset'],r['population'],r['group'],r['weighting'])==(dataset,population,group,'equal_family'))
            ax=axes[i,j];a,s=Fraction(row['delivery_coefficient']),Fraction(row['shortfall_coefficient'])
            polygon=positive_polygon(a,s)
            if polygon:ax.add_patch(Polygon([(float(x),float(y)) for x,y in polygon],facecolor='#d7e3e8',edgecolor='none'))
            if s:
                xs=[x/200 for x in range(201)];ys=[float(a/s)*x for x in xs]
                ax.plot(xs,ys,color='#173f50',linewidth=1.3)
            elif a==0:ax.text(.5,.5,'Mean gain is zero',transform=ax.transAxes,ha='center')
            ax.axhline(5,color='.45',linestyle=':',linewidth=.8);ax.axvline(.5,color='.65',linestyle=':',linewidth=.8)
            ax.set(xlim=(0,1),ylim=(0,20),xticks=[0,.5,1],yticks=[0,5,10,15,20])
            ax.set_title(('All' if group=='all' else 'Finite' if group=='finite' else 'Through horizon')+f" (n={row['n']})")
            if j==0:ax.set_ylabel(dataset.capitalize()+'\nPenalty '+r'$\kappa$')
            if i==1:ax.set_xlabel('Unit margin '+r'$r$')
    fig.supxlabel('Shading: positive mean gain; solid line: zero gain. Equal family weights.',fontsize=9)
    fig.savefig(dest,metadata={'Title':'Descriptive supplier incentive regions','Subject':'Bound manifest SHA-256 '+manifest_hash});plt.close(fig)

def run():
    m=read(HERE/'manifest.json');check(m);out=HERE/'output';out.mkdir();start=time.monotonic();failures=[]
    def cap():
        peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024)
        if time.monotonic()-start>120 or peak>512 or sum(p.stat().st_size for p in out.rglob('*') if p.is_file())>67108864-1048576:raise RuntimeError('repricing cap')
        return peak
    def alarm(*_):raise RuntimeError('repricing wall cap')
    previous=signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,120)
    try:
        factors={x['case_id']:x['commitment'] for x in read(ROOT/'configs/proposed-v3-allocation.json')['candidates'][0]['cases']}
        factors.update({x['case_id']:x['factors']['commitment'] for x in read(ROOT/'configs/v3-confirmation-public.json')['cases']})
        functions=[];regions=[];grid=[];sources=[]
        prior={(x['set'],x['case_id']):x for x in read(ROOT/'paper/margin_repricing_r1/output/NETWORK_FUNCTIONS.json')}
        for dataset,folder in [('design','v3_design_false_notice_r2'),('confirmation','v3_confirmation_opening')]:
            filename=f'results/{folder}/result.json';result=read(ROOT/filename);ver=read(ROOT/f'results/{folder}/verification.json')
            if result['status']!='completed' or result['failures'] or ver['status']!='verified' or ver['result_sha256']!=sha(ROOT/filename):raise ValueError('unverified saved outcomes')
            if len(result['case_rows'])!=56:raise ValueError('case coverage')
            for index,row in enumerate(result['case_rows']):
                a,s=coefficients(row)
                old=prior[dataset,row['case_id']]
                if a!=Fraction(old['delivery_slope_exact']) or -5*s!=Fraction(old['penalty_intercept_exact']) or factors[row['case_id']]!=old['commitment']:
                    raise ValueError('coefficient differs from verified margin correction')
                functions.append({'dataset':dataset,'case_id':row['case_id'],'family':row['family'],
                    'regime':row['regime'],'category':row['category'],'commitment':factors[row['case_id']],
                    'delivery_coefficient':str(a),'shortfall_coefficient':str(s)})
                sources.append({'dataset':dataset,'case_id':row['case_id'],'file':filename,'sha256':sha(ROOT/filename),
                    'row':f'case_rows[{index}]','columns':'cells.C00.primary;cells.C11.primary;cells.C00.accepted_shortfall;cells.C11.accepted_shortfall',
                    'operation':'G(r,kappa)=r*(C11.primary-C00.primary)-kappa*(C11.accepted_shortfall-C00.accepted_shortfall)'})
            for population in ['all_56','window_24']:
                pop=[x for x in result['case_rows'] if population=='all_56' or (x['regime']=='R1' and x['category']=='interior')]
                if len(pop)!=(56 if population=='all_56' else 24):raise ValueError('population coverage')
                for group in ['all','finite','horizon']:
                    selected=[x for x in pop if group=='all' or factors[x['case_id']]==group]
                    for weight in ['arithmetic','equal_family']:
                        a,s=mean_coefficients(selected,weight);key={'dataset':dataset,'population':population,'group':group,'weighting':weight,'n':len(selected)}
                        regions.append({**key,'family_counts':dict(Counter(x['family'] for x in selected)),
                            'delivery_coefficient':str(a),'shortfall_coefficient':str(s),'strict_inequality':f'({a})*r-({s})*kappa>0',
                            'polygon_closure':[[str(x),str(y)] for x,y in positive_polygon(a,s)],
                            'tolerance_positive_polygon_closure':[[str(x),str(y)] for x,y in positive_polygon(a,s,EPS)],
                            'boundary_excluded':True})
                        for rstr in m['domain']['margin_grid_fractions']:
                            for kstr in m['domain']['penalty_display_fractions']:
                                r,k=Fraction(rstr),Fraction(kstr);g=a*r-s*k
                                grid.append({**key,'r':float(r),'kappa':float(k),'gain':float(g),'gain_exact':str(g),
                                    'mathematically_positive':g>0,'numeric_sign':'positive' if g>EPS else 'negative' if g < -EPS else 'numerical_zero'})
                        cap()
        write(out/'NETWORK_FUNCTIONS.json',functions);write(out/'REGIONS.json',regions);csvout(out/'SOURCE_MAP.csv',sources);csvout(out/'DISPLAY_GRID.csv',grid)
        draw(regions,'window_24',out/'incentive_regions_window.pdf',sha(HERE/'manifest.json'));cap()
        draw(regions,'all_56',out/'incentive_regions_all56.pdf',sha(HERE/'manifest.json'));cap()
    except Exception as e:failures.append({'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()})
    finally:signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,previous)
    write(out/'RESULT.json',{'status':'stopped' if failures else 'completed','manifest_sha256':sha(HERE/'manifest.json'),
        'elapsed_seconds':time.monotonic()-start,'failures':failures,'solves':0,'private_access':False,'new_tests_or_intervals':False,
        'files':{p.name:sha(p) for p in out.iterdir() if p.is_file()}})

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','run']);a=p.parse_args()
    prepare() if a.mode=='prepare' else run()
