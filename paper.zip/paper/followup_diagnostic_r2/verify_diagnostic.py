"""Solver-free independent audit of a completed diagnostic capture."""
from pathlib import Path
from decimal import Decimal,localcontext
import argparse,hashlib,json,math
import numpy as np

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def exact_decimal_dot(a,x):
 # Binary64 products have at most 2,150 significant decimal places including
 # extreme subnormal exponents. 3,000 digits also cover this model's summation.
 with localcontext() as ctx:
  ctx.prec=3000
  return sum((Decimal.from_float(float(v))*Decimal.from_float(float(w)) for v,w in zip(a,x)),Decimal(0))

def verify(base):
 root=base.parents[1];m=json.loads((base/'execution_manifest.json').read_text());out=base/'execution';r=json.loads((out/'result.json').read_text())
 if r['status']!='completed' or r['failures'] or len(r['completed_states'])!=12 or r['mip_solves']!=12:raise ValueError('diagnostic incomplete; no success verification')
 if r['execution_manifest_sha256']!=sha(base/'execution_manifest.json'):raise ValueError('manifest mismatch')
 for category in ['source_sha256','input_sha256']:
  for name,want in m[category].items():
   p=(root/name).resolve()
   if not p.is_relative_to(root) or sha(p)!=want:raise ValueError('input or source differs')
 for name,want in r['files'].items():
  p=(out/name).resolve()
  if not p.is_relative_to(out) or sha(p)!=want:raise ValueError('capture mismatch')
 checked=[]
 for index,task in enumerate(m['tasks']):
  folder=out/f'state-{index:02d}';audit=json.loads((folder/'audit.json').read_text());state=json.loads((folder/'state.json').read_text());capture=json.loads((folder/'capture.json').read_text());arrays=np.load(folder/'arrays.npz',allow_pickle=False)
  if state['task']!=task or task['state_id']!=r['completed_states'][index]:raise ValueError('state identity')
  for field in ['primary_cost','combined']:
   a,x=arrays[field],arrays['solution'];d=exact_decimal_dot(a,x)
   saved=audit['dot_products'][field]
   with localcontext() as ctx:
    ctx.prec=3000
    fraction_value=Decimal(saved['exact_numerator'])/Decimal(saved['exact_denominator'])
    if d!=fraction_value:raise ValueError('exact arithmetic mismatch')
    scale=sum((abs(Decimal.from_float(float(v))*Decimal.from_float(float(w))) for v,w in zip(a,x)),Decimal(0))
    u=Decimal(2)**-53;n=len(a);bound=(2*n*u/(1-2*n*u))*scale+(2*n+1)*Decimal(2)**-1074
    obs=Decimal.from_float(float(capture['values']['primary_recomputed' if field=='primary_cost' else 'combined_recomputed']))
    if not obs.is_finite() or abs(obs-d)>bound:raise ValueError('objective outside analytic budget')
    if float(bound)!=saved['analytic_roundoff_bound']:raise ValueError('bound changed')
  x=arrays['solution'];rowvals=[0.0]*len(arrays['row_lower']);term_lists=[[] for _ in rowvals]
  for i,j,v in zip(arrays['matrix_row'],arrays['matrix_col'],arrays['matrix_value']):term_lists[int(i)].append(float(v)*float(x[int(j)]))
  rowvals=np.asarray([math.fsum(v) for v in term_lists]);tol=capture['values']['postsolve_checks']['feasibility_limit']
  violation=max(0,float(np.max(arrays['lower']-x)),float(np.max(x-arrays['upper'])),float(np.max(arrays['row_lower']-rowvals)),float(np.max(rowvals-arrays['row_upper'])))
  if violation>tol:raise ValueError('independent feasibility mismatch')
  ints=x[arrays['integer']==1]
  if len(ints) and max(abs(float(v)-round(float(v))) for v in ints)>1e-8+capture['values']['postsolve_checks']['row_roundoff']:raise ValueError('integrality mismatch')
  old=state['saved_action'];new=audit['projected_action']
  if type(old['qualify']) is not bool or old['qualify']!=new['qualify']:raise ValueError('binary mismatch')
  diffs=[abs(old[k]-new[k]) for k in ['primary_order','spot_order']]
  for field,ids in [('production',['site','product']),('shipments',['lane_index'])]:
   if len(old[field])!=len(new[field]):raise ValueError('action length')
   for a,b in zip(old[field],new[field]):
    if any(a[k]!=b[k] for k in ids):raise ValueError('action coordinate identity')
    diffs.append(abs(a['quantity']-b['quantity']))
  if max(diffs,default=0)>1e-6 or math.fsum(diffs)>1e-3:raise ValueError('action tolerance')
  cert=capture['values']['certificate'];expected=float(exact_decimal_dot(arrays['combined'],x));limit=1e-7*max(1,abs(expected),abs(cert['primal']))+audit['dot_products']['combined']['analytic_roundoff_bound']
  if cert['status']!=0 or not cert['optimal'] or abs(expected-cert['primal'])>limit:raise ValueError('solver consistency')
  settings={'requested_relative_gap':0,'requested_mip_absolute_gap':0,'requested_mip_feasibility_tolerance':1e-8,'requested_threads':1,'requested_presolve':False,'requested_random_seed':0,'time_limit_seconds':30}
  if any(cert[k]!=v for k,v in settings.items()):raise ValueError('solver settings differ')
  if not all(math.isfinite(cert[k]) for k in ['primal','dual','relative_gap']) or abs(cert['primal']-cert['dual'])>1e-7*max(1,abs(cert['primal']),abs(cert['dual'])):raise ValueError('solver bound closure')
  returned=audit['returned'];values=capture['values']
  for key,expected_value in [('expected_cost',values['primary_recomputed']+values['constant_cost']),('combined_objective',values['combined_recomputed']+values['constant_cost']),('primary_cost_loss_bound',1e-3+values['bound_gap']+values['objective_roundoff'])]:
   if not math.isfinite(returned[key]) or returned[key]!=expected_value:raise ValueError('returned objective summary mismatch')
  checked.append({'state_id':task['state_id'],'maximum_action_difference':max(diffs,default=0),'largest_constraint_violation':violation})
 value={'status':'verified','result_sha256':sha(out/'result.json'),'manifest_sha256':sha(base/'execution_manifest.json'),'states':checked,'exact_products_checked':24,'solver_calls':0,'historical_warnings_cleared':False}
 destination=out/'verification.json'
 with destination.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
 print(json.dumps(value,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--package',type=Path,default=Path(__file__).resolve().parent);a=p.parse_args();verify(a.package)
