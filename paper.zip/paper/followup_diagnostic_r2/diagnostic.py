"""Twelve public saved-state diagnostics. prepare/preflight never optimize.
Frozen planner source is imported unchanged. run requires an exact-hash receipt.
"""
from pathlib import Path
from dataclasses import asdict,is_dataclass
from contextlib import contextmanager
from fractions import Fraction
import argparse,csv,hashlib,io,json,math,os,platform,resource,signal,sys,time,traceback,warnings
import numpy as np
import scipy
from scipy.optimize._highspy import _core as highs
from sn import planner_v3_single_r3 as planner
from sn.allocation_v3 import canonical
from sn.belief_v3_common import load_case
from sn.belief_v3 import problem
from sn.core import Notice,Realization
from sn.core_v3 import initial_state_v3,step_v3
from sn.verify_belief_v3 import action,numeric_tree

ROOT=Path(__file__).resolve().parents[2]
BASE='paper/followup_diagnostic_r2'
PLANNER='src/sn/planner_v3_single_r3.py'
PLANNER_HASH='48f341a686809e41efa15b41583ccab562652ab9ae8a2bc24dbff97dcfcb239c'
PROGRESS='results/v3_discounted_belief_study_r1/progress.jsonl'
CAPS={'solves':12,'per_mip_seconds':30,'wall_seconds':480,'peak_rss_mib':512,'saved_bytes':268435456,'retries':0}
DECISION='owner_approved_v3_objective_diagnostic_r2'
SOURCES=['src/sn/__init__.py','src/sn/core.py','src/sn/core_v2.py','src/sn/core_v3.py','src/sn/handoff_v3_single.py',PLANNER,'src/sn/allocation_v3.py','src/sn/networks_v3.py','src/sn/freeze_v3_design.py','src/sn/belief_v3_common.py','src/sn/belief_v3.py','src/sn/verify_belief_v3.py',BASE+'/diagnostic.py',BASE+'/verify_diagnostic.py',BASE+'/test_diagnostic.py']
INPUTS=['configs/v3-design/selection-freeze.json','results/v3_discounted_belief_study_r1/result.json','results/v3_discounted_belief_study_r1/verification.json',PROGRESS,'configs/proposed-v3-discounted-belief-study-r1.json','docs/paper_prep/discounted_belief_r1/STUDY_WARNINGS.md','paper/followup_plan_r1/PLAN.md','paper/followup_diagnostic_r1/execution/result.json','paper/followup_diagnostic_r1/owner_approval.json']

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(canonical(v)).hexdigest()
WRITE_BUDGET=None
def write(p,v):
 data=canonical(clean(v))
 if WRITE_BUDGET is not None and p.is_relative_to(WRITE_BUDGET.folder):WRITE_BUDGET.check_write(len(data),reserve=p.name not in ('result.json','failure.json'))
 p.write_bytes(data)
def clean(v):
 if is_dataclass(v):return clean(asdict(v))
 if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
 if isinstance(v,(tuple,list)):return [clean(x) for x in v]
 if isinstance(v,np.generic):return clean(v.item())
 if isinstance(v,float) and not math.isfinite(v):return repr(v)
 return v

def environment():
 import io,contextlib
 stream=io.StringIO()
 with contextlib.redirect_stdout(stream):np.show_config()
 return {'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'highs':'.'.join(str(getattr(highs,'HIGHS_VERSION_'+x)) for x in ['MAJOR','MINOR','PATCH']),'platform':platform.system(),'machine':platform.machine(),'numpy_geterr':np.geterr(),'numpy_configuration':stream.getvalue(),'thread_environment':{k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','VECLIB_MAXIMUM_THREADS']}}

@contextmanager
def zero_solve_guard():
 old_solve,old_milp=planner._solve,planner.milp
 def denied(*args,**kwargs):raise RuntimeError('MIP call forbidden in zero-solve preparation')
 planner._solve=denied;planner.milp=denied
 try:yield
 finally:planner._solve=old_solve;planner.milp=old_milp

def selection():
 cat=json.loads((ROOT/'configs/v3-design/selection-freeze.json').read_text())['cases']
 cat=[x for x in cat if x['regime']=='R1' and x['category']=='interior'];tasks=[]
 for family in ['serial','assembly','distribution','layered_dual','planted']:
  for size,alpha in [('small',.25),('large',.75)]:
   item=sorted((x for x in cat if x['family']==family and x['size']==size),key=lambda x:x['case_id'])[0]
   case=load_case(ROOT,item);period=0 if size=='small' else max(0,case.contract.revelation_period-1)
   tasks.append({**item,'alpha':alpha,'period':period,'selection_role':'family_size_pre_revelation'})
 for family,role in [('serial','initial_half_belief'),('planted','revelation_half_belief')]:
  item=sorted((x for x in cat if x['family']==family and x['size']=='large'),key=lambda x:x['case_id'])[0]
  case=load_case(ROOT,item);tasks.append({**item,'alpha':.5,'period':0 if family=='serial' else case.contract.revelation_period,'selection_role':role})
 for t in tasks:
  t['path_id']=f"{t['case_id']}|alpha={t['alpha']:.2f}"
  t['state_id']=f"{t['path_id']}|period={t['period']}"
 assert len(tasks)==len({t['state_id'] for t in tasks})==12
 return tasks

def saved_paths(tasks):
 ids={t['path_id'] for t in tasks};found={}
 with (ROOT/PROGRESS).open() as f:
  for line_number,line in enumerate(f,1):
   row=json.loads(line)
   if row['path_id'] in ids:
    if row['path_id'] in found:raise ValueError('duplicate saved path')
    found[row['path_id']]=(line_number,row)
 if set(found)!=ids:raise ValueError('missing public baseline paths')
 return found

def reconstruct(task,saved):
 line,row=saved;case=load_case(ROOT,task)
 if row['status']!='completed' or len(row['periods'])!=20:raise ValueError('incomplete baseline')
 state=initial_state_v3(case.network);prefix=[]
 for t,record in enumerate(row['periods'][:task['period']+1]):
  if record['period']!=t:raise ValueError('period order')
  call=problem(case,state,task['alpha'],30)
  if digest(asdict(call))!=record['planning_problem_sha256']:raise ValueError('saved planning state differs')
  if t==task['period']:
   return call,record,{'saved_jsonl_line':line,'prefix_sha256':digest(prefix),'state_sha256':digest(asdict(state)),'planning_problem_sha256':digest(asdict(call)),'saved_period_sha256':digest(record),'replayed_prefix_periods':t}
  state,ledger=step_v3(case.network,case.contract,call.notice,state,action(record['action']),Realization(case.long_capacity[t],case.baseline_demand[t]),revealed_schedule=case.long_capacity if t==case.contract.revelation_period else None)
  if numeric_tree(asdict(ledger))!=numeric_tree(record['ledger']):raise ValueError('prefix ledger mismatch')
  prefix.append(record)
 raise AssertionError('target period absent')

def preflight(tasks):
 if sha(ROOT/PLANNER)!=PLANNER_HASH:raise ValueError('planner hash changed')
 result=json.loads((ROOT/'results/v3_discounted_belief_study_r1/result.json').read_text())
 verified=json.loads((ROOT/'results/v3_discounted_belief_study_r1/verification.json').read_text())
 if result['status']!='completed' or result['failures'] or verified['status']!='verified':raise ValueError('baseline not verified')
 if verified['result_sha256']!=sha(ROOT/'results/v3_discounted_belief_study_r1/result.json') or result['progress_sha256']!=sha(ROOT/PROGRESS) or verified['progress_sha256']!=result['progress_sha256']:raise ValueError('baseline evidence binding differs')
 records=saved_paths(tasks);details=[]
 with zero_solve_guard():
  for task in tasks:
   _,_,detail=reconstruct(task,records[task['path_id']]);details.append({'state_id':task['state_id'],**detail})
 return {'status':'passed','actual_mip_calls':0,'states':details,'planner_sha256':PLANNER_HASH,'scope':'public saved-action prefixes only; no new trajectories'}

def prepare():
 tasks=selection();pre=preflight(tasks);base=ROOT/BASE
 write(base/'PREFLIGHT.json',pre)
 for t,d in zip(tasks,pre['states']):t.update({k:v for k,v in d.items() if k!='state_id'})
 inputs=INPUTS+[f"configs/v3-design/cases/candidate-0/{t['case_id']}.json" for t in tasks]+[BASE+'/PREFLIGHT.json']
 manifest={'schema':1,'status':'proposed_unrun','purpose':'diagnose_postsolve_objective_warnings_only','planner_sha256':PLANNER_HASH,'tasks':tasks,'resource_caps':CAPS,'configuration':{'presolve':False,'threads':1,'relative_gap':0,'absolute_gap':0,'random_seed':0,'time_limit':30},'source_sha256':{p:sha(ROOT/p) for p in SOURCES},'input_sha256':{p:sha(ROOT/p) for p in sorted(set(inputs))},'environment':environment(),'receipt_decision':DECISION,'output':BASE+'/execution','no_payoffs_or_h1_quantities':True,'failure_policy':'stop_first_planner_certificate_nonfinite_objective_inconsistency_action_parity_or_cap_failure_zero_retries; finite_consistent_warning_records_do_not_clear_historical_warning','arithmetic_budget':'gamma_(2n)*sum(abs(a_i*x_i)) + (2n+1)*smallest_subnormal for dot versus exact rational; solver objective comparison uses existing 1e-7*max(1,abs(reported),abs(exact)) plus dot budget; diagnostic only, no new planner tolerance','action_parity':{'exact_qualification':True,'coordinate_absolute':1e-6,'single_state_l1':1e-3},'historical_occurrence_attribution':'unavailable; selection is metadata-based, not claimed to identify affected states'}
 write(base/'execution_manifest.json',manifest)
 print(json.dumps({'preflight':pre['status'],'states':len(tasks),'solves':0,'manifest_sha256':sha(base/'execution_manifest.json')}))

class ResourceStop(RuntimeError):pass
class Budget:
 def __init__(self,caps,folder):self.caps=caps;self.folder=folder;self.solves=0;self.start=time.monotonic()
 def check(self):
  rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024)
  if rss>self.caps['peak_rss_mib']:raise ResourceStop('worker memory cap')
  if time.monotonic()-self.start>self.caps['wall_seconds']:raise ResourceStop('wall cap')
  if sum(p.stat().st_size for p in self.folder.rglob('*') if p.is_file())>self.caps['saved_bytes']-1048576:raise ResourceStop('output cap; 1 MiB reserved for failure')
 def check_write(self,size,reserve=True):
  limit=self.caps['saved_bytes']-(1048576 if reserve else 0)
  if sum(p.stat().st_size for p in self.folder.rglob('*') if p.is_file())+size>limit:raise ResourceStop('output write cap')
 def enter(self):
  self.check()
  if self.solves>=self.caps['solves']:raise ResourceStop('MIP phase cap')
  self.solves+=1

class Capture:
 """Observe Python return locals without modifying planner code or arrays.
 Line/opcode tracing is disabled. A different observer can still change floating
 environment timing; failure to reproduce a historical warning is inconclusive.
 """
 def __init__(self,plan_fn,solve_fn,budget):self.plan_fn=plan_fn;self.solve_fn=solve_fn;self.budget=budget;self.plan={};self.solve={};self.exceptions=[]
 def trace(self,frame,event,arg):
  kind='plan' if frame.f_code is self.plan_fn.__code__ else 'solve' if frame.f_code is self.solve_fn.__code__ else None
  if kind is None:return None
  if event=='call':
   frame.f_trace_lines=False;frame.f_trace_opcodes=False
   if kind=='solve':self.budget.enter()
  elif event in ('return','exception'):
   setattr(self,kind,dict(frame.f_locals))
   if event=='exception':self.exceptions.append({'function':kind,'type':arg[0].__name__,'text':str(arg[1])})
  return self.trace
 def invoke(self,call):
  if sys.gettrace() is not None:raise RuntimeError('existing trace hook; diagnostic requires clean process')
  sys.settrace(self.trace)
  try:return self.plan_fn(call)
  finally:sys.settrace(None)

def dot_audit(coeff,vector,observed):
 a=[float(x) for x in coeff];x=[float(x) for x in vector]
 if len(a)!=len(x) or not all(math.isfinite(z) for z in a+x):raise ValueError('nonfinite dot input or shape')
 terms=[Fraction(v)*Fraction(w) for v,w in zip(a,x)];exact=sum(terms,Fraction());scale=sum(map(abs,terms),Fraction());n=len(a)
 u=Fraction(1,2**53);gamma=2*n*u/(1-2*n*u);bound=gamma*scale+Fraction(2*n+1,2**1074)
 with np.errstate(all='warn'),warnings.catch_warnings(record=True) as captured:
  warnings.simplefilter('always');repeated=float(np.asarray(coeff)@np.asarray(vector))
 rounded=math.fsum(v*w for v,w in zip(a,x))
 difference=abs(Fraction(observed)-exact) if math.isfinite(observed) else None
 return {'terms':n,'exact_numerator':str(exact.numerator),'exact_denominator':str(exact.denominator),'exact_float':clean(float(exact)),'absolute_product_sum':clean(float(scale)),'analytic_roundoff_bound':float(bound),'observed':clean(observed),'observed_absolute_error':float(difference) if difference is not None else None,'observed_within_budget':difference is not None and difference<=bound,'fsum_of_rounded_products':clean(rounded),'repeated_numpy_dot':clean(repeated),'repeat_warnings':[{'category':w.category.__name__,'message':str(w.message),'filename':Path(w.filename).name,'lineno':w.lineno} for w in captured]}

def action_difference(left,right):
 if left['qualify']!=right['qualify']:raise ValueError('qualification disagreement')
 def flat(v):
  if isinstance(v,dict):return sum((flat(v[k]) for k in sorted(v) if k not in ('qualify','site','product','lane_index')),[])
  if isinstance(v,(list,tuple)):return sum((flat(x) for x in v),[])
  return [float(v)] if isinstance(v,(int,float)) else []
 # Match identities and lengths independently, not just aggregate coordinates.
 for key,ids in [('production',['site','product']),('shipments',['lane_index'])]:
  if [[v[k] for k in ids] for v in left[key]]!=[[v[k] for k in ids] for v in right[key]]:raise ValueError('action identities differ')
 a,b=flat(left),flat(right)
 if len(a)!=len(b):raise ValueError('action shape')
 diff=[abs(x-y) for x,y in zip(a,b)]
 return {'exact_qualification':True,'max_abs':max(diff,default=0),'l1':math.fsum(diff),'coordinates':len(diff),'within_budget':max(diff,default=0)<=1e-6 and math.fsum(diff)<=1e-3}

def dump_capture(folder,capture):
 p,s=capture.plan,capture.solve;model=p.get('model',s.get('model'));data={}
 for k in ['primary_cost','tie','combined','solution']:
  if k in p:data[k]=np.asarray(p[k])
 if 'solution' not in data and 'vector' in s:data['solution']=np.asarray(s['vector'])
 raw=s.get('result')
 if raw is not None and getattr(raw,'x',None) is not None:data['solver_raw_x']=np.asarray(raw.x)
 if model is not None:
  for name,values in [('lower',model.lower),('upper',model.upper),('integer',model.integer),('row_lower',model.row_lower),('row_upper',model.row_upper)]:data[name]=np.asarray(values)
  coords=[(i,j,v) for i,row in enumerate(model.rows) for j,v in row.items()]
  data['matrix_row']=np.array([x[0] for x in coords],dtype=np.int64);data['matrix_col']=np.array([x[1] for x in coords],dtype=np.int64);data['matrix_value']=np.array([x[2] for x in coords],dtype=float)
  write(folder/'variables.json',model.names)
 buffer=io.BytesIO();np.savez_compressed(buffer,**data)
 if WRITE_BUDGET is not None:WRITE_BUDGET.check_write(buffer.tell())
 (folder/'arrays.npz').write_bytes(buffer.getvalue())
 metadata={k:{'shape':list(v.shape),'dtype':str(v.dtype),'strides':list(v.strides),'c_contiguous':v.flags.c_contiguous,'finite':bool(np.isfinite(v).all()),'nonfinite_count':int(np.count_nonzero(~np.isfinite(v))),'max_abs_finite':float(np.max(np.abs(v[np.isfinite(v)]))) if np.isfinite(v).any() else None} for k,v in data.items()}
 vals={k:p[k] for k in ['primary_recomputed','combined_recomputed','objective_roundoff','bound_gap','cost_loss_bound','constant_cost'] if k in p}
 vals['postsolve_checks']={k:s[k] for k in ['lower_violation','upper_violation','row_lower_violation','row_upper_violation','integer_violation','row_roundoff','feasibility_limit','gap','gap_limit'] if k in s}
 result=s.get('result')
 if result is not None:vals['solver_result']={k:getattr(result,k,None) for k in ['status','message','success','fun','mip_dual_bound','mip_gap','mip_node_count']}
 if 'certificate' in p:vals['certificate']=asdict(p['certificate'])
 elif 'certificate' in s:vals['certificate']=asdict(s['certificate'])
 write(folder/'capture.json',{'array_metadata':metadata,'values':vals,'exceptions':capture.exceptions})
 return data,vals

def authorize(manifest_path,receipt_path):
 manifest=json.loads(manifest_path.read_text());receipt=json.loads(receipt_path.read_text())
 if receipt.get('decision')!=DECISION or receipt.get('execution_manifest_sha256')!=sha(manifest_path):raise ValueError('exact-hash owner approval missing')
 if manifest['resource_caps']!=CAPS or len(manifest['tasks'])!=12 or manifest['planner_sha256']!=PLANNER_HASH:raise ValueError('scope differs')
 for group in ['source_sha256','input_sha256']:
  for path,want in manifest[group].items():
   q=(ROOT/path).resolve()
   if not q.is_relative_to(ROOT) or sha(q)!=want:raise ValueError('changed or nonrepository input: '+path)
 if manifest['environment']!=environment():raise ValueError('numerical environment changed')
 if manifest['output']!=BASE+'/execution':raise ValueError('output location differs')
 return manifest

def run(manifest_path,receipt_path):
 global WRITE_BUDGET
 m=authorize(manifest_path,receipt_path);pre=preflight(m['tasks'])
 if pre!=json.loads((ROOT/BASE/'PREFLIGHT.json').read_text()):raise ValueError('preflight differs')
 out=ROOT/m['output'];out.mkdir() # exclusive: no retry or overwrite
 write(out/'attempt.json',{'execution_manifest_sha256':sha(manifest_path),'receipt_sha256':sha(receipt_path),'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())})
 budget=Budget(CAPS,out);WRITE_BUDGET=budget;records=saved_paths(m['tasks']);completed=[];failures=[];allwarnings=[]
 def alarm(*_):raise ResourceStop('wall alarm')
 old_alarm=signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,CAPS['wall_seconds'])
 try:
  for index,task in enumerate(m['tasks']):
   folder=out/f'state-{index:02d}';folder.mkdir();capture=Capture(planner.plan,planner._solve,budget);choice=None;observed=[];error=None
   try:
    call,saved,details=reconstruct(task,records[task['path_id']]);write(folder/'state.json',{'task':task,'planning_problem':asdict(call),'saved_action':saved['action'],'state_binding':details})
    with warnings.catch_warnings(record=True) as observed:
     warnings.simplefilter('always');choice=capture.invoke(call)
    budget.check()
   except Exception as exc:error={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
   # Flush complete diagnostics on both success and failure, before any decision.
   data,values=dump_capture(folder,capture)
   warn=[{'category':w.category.__name__,'message':str(w.message),'filename':Path(w.filename).name,'lineno':w.lineno} for w in observed];write(folder/'warnings.json',warn);allwarnings.extend({'state_id':task['state_id'],**w} for w in warn)
   try:
    if error:raise RuntimeError(error['message'])
    audits={key:dot_audit(data[key],data['solution'],float(values[name])) for key,name in [('primary_cost','primary_recomputed'),('combined','combined_recomputed')]}
    parity=action_difference(asdict(choice.action),saved['action'])
    exact=audits['combined']['exact_float'];reported=values['certificate']['primal'];limit=1e-7*max(1,abs(exact),abs(reported))+audits['combined']['analytic_roundoff_bound'];difference=abs(exact-reported)
    report={'dot_products':audits,'solver_objective_difference':difference,'solver_objective_comparison_limit':limit,'action_parity':parity,'projected_action':asdict(choice.action),'handoff':asdict(choice.handoff),'returned':{'expected_cost':choice.expected_cost,'combined_objective':choice.combined_objective,'primary_cost_loss_bound':choice.primary_cost_loss_bound}}
    write(folder/'audit.json',report)
    if not all(math.isfinite(float(v)) for v in report['returned'].values()):raise ValueError('nonfinite returned objective summary')
    if not all(a['observed_within_budget'] for a in audits.values()):raise ValueError('objective dot differs from exact accumulation beyond analytic bound')
    if difference>limit:raise ValueError('objective differs from solver beyond declared scale')
    if not parity['within_budget']:raise ValueError('saved action parity failed')
    budget.check();completed.append(task['state_id'])
   except Exception as exc:
    failures.append({'state_id':task['state_id'],**(error or {'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})});write(folder/'failure.json',failures[-1]);break
 except Exception as exc:failures.append({'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()})
 finally:
  signal.setitimer(signal.ITIMER_REAL,0);signal.signal(signal.SIGALRM,old_alarm)
 result={'status':'completed' if len(completed)==12 and not failures else 'stopped','completed_states':completed,'failures':failures,'warnings':allwarnings,'mip_solves':budget.solves,'elapsed_seconds':time.monotonic()-budget.start,'peak_rss_mib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/(1024**2 if sys.platform=='darwin' else 1024),'execution_manifest_sha256':sha(manifest_path),'files':{str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file()},'historical_warnings_cleared':False,'private_access':False,'new_payoff_or_h1_outputs':False}
 write(out/'result.json',result);print(json.dumps({'status':result['status'],'mip_solves':budget.solves,'completed':len(completed),'failures':failures},indent=2))

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('mode',choices=['prepare','preflight','run']);parser.add_argument('--manifest',type=Path,default=ROOT/BASE/'execution_manifest.json');parser.add_argument('--receipt',type=Path,default=ROOT/BASE/'owner_approval.json');args=parser.parse_args()
 if args.mode=='prepare':prepare()
 elif args.mode=='preflight':print(json.dumps(preflight(selection()),indent=2))
 else:run(args.manifest,args.receipt)
