"""Synthetic arithmetic checks only; no study or solver imports."""
import unittest
from fractions import Fraction as Q
from reprice import coeff, sign, threshold, choose, monotone_zero


class RepricingTests(unittest.TestCase):
    def test_payoff_from_cells_and_fees(self):
        row={'cells':{'C00':{'primary':4,'accepted_shortfall':0},'C11':{'primary':6,'accepted_shortfall':1}}}
        self.assertEqual(coeff(row),(Q(2),Q(-5)))
        self.assertEqual(coeff(row,liability=0,fixed=3),(Q(2),Q(-3)))
        for margin in [Q(0),Q(1,4),Q(1),Q(3)]:
            a,b=coeff(row);self.assertEqual(a*margin+b,(a*3+b)+(margin-3)*a)

    def test_positive_negative_zero_slopes(self):
        self.assertEqual(threshold(Q(2),Q(-1))['root'],'1/2')
        self.assertEqual(threshold(Q(-2),Q(1))['condition'],'r < root')
        self.assertEqual(threshold(Q(0),Q(0))['condition'],'identically_zero')
        self.assertEqual(threshold(Q(0),Q(1))['condition'],'always_positive')
        self.assertEqual(threshold(Q(0),Q(-1))['condition'],'always_negative')

    def test_sign_tolerance_boundary(self):
        e=Q(1,100_000_000)
        for value in [0,e,-e]:self.assertEqual(sign(value),'numerical_zero')
        self.assertEqual(sign(e+e/10),'positive')
        self.assertEqual(sign(-e-e/10),'negative')

    def test_expedite_tie_and_reselection(self):
        base={'primary':0,'accepted_shortfall':0}
        fast={'primary':4,'accepted_shortfall':0}
        self.assertFalse(choose(base,fast,Q(3,4))[0])
        self.assertFalse(choose(base,fast,Q(3_000_001,4_000_000))[0])
        self.assertTrue(choose(base,fast,Q(3_000_002,4_000_000))[0])
        self.assertFalse(choose(base,fast,Q(1,2))[0])
        self.assertTrue(choose(base,fast,Q(1))[0])

    def test_interval_root_bracket(self):
        x=monotone_zero(lambda r:r-.3)['bracket']
        self.assertLessEqual(x[0],.3);self.assertGreaterEqual(x[1],.3)
        self.assertLessEqual(x[1]-x[0],1e-10)
        self.assertEqual(monotone_zero(lambda r:r-2)['classification'],'not_positive_in_domain')


if __name__=='__main__':unittest.main()
