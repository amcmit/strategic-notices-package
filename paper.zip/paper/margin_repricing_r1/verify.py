"""Independent arithmetic verification. Does not import the repricing runner."""
from pathlib import Path
from fractions import Fraction
from random import Random
from collections import Counter
import csv
import hashlib
import json
import numpy as np

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1];OUT=HERE/'output'
Q=lambda x:Fraction(str(x))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
families=('assembly','distribution','layered_dual','planted','serial')
def read(p):return json.loads(p.read_text())
def csvrows(name):
    with (OUT/name).open() as stream:return list(csv.DictReader(stream))
def close(x,y):assert abs(float(x)-float(y))<1e-8,(x,y)
def status(v):return 'positive' if v>Q('1e-8') else 'negative' if v<Q('-1e-8') else 'numerical_zero'
def is_window(r):return r['regime']=='R1' and r['category']=='interior'
def raw_gain(row,r,k=5,f=0):
    c=row['cells'];return r*(Q(c['C11']['primary'])-Q(c['C00']['primary']))-k*(Q(c['C11']['accepted_shortfall'])-Q(c['C00']['accepted_shortfall']))-f
def select_group(rows,name,commit):
    if name=='all_56':return rows
    if name=='window':return [r for r in rows if is_window(r)]
    if name=='boundary':return [r for r in rows if r['regime']=='R1' and not is_window(r)]
    if name in ['finite','horizon']:return [r for r in rows if is_window(r) and commit[r['case_id']]==name]
    if name.startswith('family_'):return [r for r in rows if is_window(r) and r['family']==name[7:]]
    return [r for r in rows if r['regime']==name]


def main():
    m=read(HERE/'manifest.json');p=read(OUT/'PROVENANCE.json')
    assert p['manifest_sha256']==sha(HERE/'manifest.json')
    for key,digest in {**m['inputs'],**m['source_sha256']}.items():assert sha(ROOT/key)==digest,key
    for key,digest in p['outputs'].items():assert sha(OUT/key)==digest,key
    baseline={};results={};count=Counter()
    for label,folder in [('design','v3_design_false_notice_r2'),('confirmation','v3_confirmation_opening')]:
        results[label]=read(ROOT/f'results/{folder}/result.json');baseline[label]={r['case_id']:r for r in results[label]['case_rows']}
    allocation=read(ROOT/'configs/proposed-v3-allocation.json')
    commit={r['case_id']:r['commitment'] for r in allocation['candidates'][0]['cases']}
    commit.update({r['case_id']:r['factors']['commitment'] for r in read(ROOT/'configs/v3-confirmation-public.json')['cases']})
    for row in read(OUT/'NETWORK_FUNCTIONS.json'):
        raw=baseline[row['set']][row['case_id']];intercept=raw_gain(raw,Q(0));slope=raw_gain(raw,Q(1))-intercept
        assert Q(row['delivery_slope_exact'])==slope and Q(row['penalty_intercept_exact'])==intercept
        if row['zero']['root'] is not None:assert slope*Q(row['zero']['root'])+intercept==0
        count['exact_network_functions']+=1
    for row in csvrows('NETWORK_GRID.csv'):
        v=raw_gain(baseline[row['set']][row['case_id']],Q(row['margin']))
        assert v==Q(row['gain_exact']);close(v,row['gain']);assert status(v)==row['sign'];count['exact_network_grid_rows']+=1
    for row in csvrows('GROUP_GRID.csv'):
        selected=select_group(list(baseline[row['set']].values()),row['group'],commit)
        vals=[raw_gain(x,Q(row['margin'])) for x in selected];s=Counter(map(status,vals))
        assert len(vals)==int(row['n']);close(sum(vals)/len(vals),row['mean_gain']);close(min(vals),row['minimum_gain']);close(max(vals),row['maximum_gain'])
        for key in ['positive','numerical_zero','negative']:assert s[key]==int(row[key])
        count['group_grid_rows']+=1
    # Independently resample whole rows with scalar means, rather than the runner's matrix weights.
    curve=csvrows('WINDOW_INTERVALS.csv');summary=read(OUT/'SUMMARY.json')
    for label,result in results.items():
        rows=result['case_rows'];ww=[r for r in rows if is_window(r)];cc=[r for r in rows if r['regime']!='R1']
        groups=[[r for r in ww if r['family']==f] for f in families];others=[[r for r in cc if r['family']==f] for f in families]
        rng=Random(20261112);aa=[];bb=[]
        for _ in range(10000):
            drawn=[[g[rng.randrange(len(g))] for _ in g] for g in groups]
            for g in others:
                for _ in g:rng.randrange(len(g))
            aa.append(sum(sum(r['delta_d'] for r in g)/len(g) for g in drawn)/5)
            bb.append(sum(sum(-5*r['s'] for r in g)/len(g) for g in drawn)/5)
        aa=np.array(aa);bb=np.array(bb)
        for row in [x for x in curve if x['set']==label]:
            r=Q(row['margin']);expected=sum(sum(raw_gain(x,r) for x in g)/len(g) for g in groups)/5
            close(expected,row['mean_gain']);limits=np.quantile(aa*float(r)+bb,[.00835,.99165],method='linear')
            close(limits[0],row['lower_98_33']);close(limits[1],row['upper_98_33']);count['independent_bootstrap_intervals']+=1
        old=result['analysis_confirmation' if label=='confirmation' else 'analysis_validation']['intervals']['g_3_5']
        lim=np.quantile(3*aa+bb,[.00835,.99165],method='linear');close(lim[0],old['lower']);close(lim[1],old['upper'])
        for key,quantile in [('pointwise_lower_zero',.00835),('pointwise_upper_zero',.99165)]:
            bound=summary[label][key]
            if bound['bracket']:
                lo,hi=bound['bracket'];assert hi-lo<=1e-10
                assert np.quantile(aa*lo+bb,quantile)<=1e-10 and np.quantile(aa*hi+bb,quantile)>=-1e-10
    # Audit every saved accelerate/no-accelerate option, then every reselected choice.
    saved={}
    with (ROOT/'results/v3_design_sensitivities_r1/progress.jsonl').open() as stream:
        for line in stream:
            x=json.loads(line)
            if x['arm']=='long_type_expedite':saved[x['case_id'],x['cell']]=x
    options={}
    for row in read(OUT/'EXPEDITE_OPTIONS.json'):
        path=saved[row['case_id'],row['cell']];ledgers=[p['ledger'] for p in path['periods']]
        pairs={'primary':'primary_delivered','backup':'backup_delivered','buyer_cost':'operating_cost'}
        expected={k:sum(Q(p[field]) for p in ledgers) for k,field in pairs.items()}
        expected['accepted_shortfall']=sum(Q(p['primary_shortfall'])-Q(p['pre_horizon_order_shortfall']) for p in ledgers)
        assert all(Q(row['fast'][k])==v for k,v in expected.items())
        assert all(Q(row['base'][k])==Q(baseline['design'][row['case_id']]['cells'][row['cell']][k]) for k in expected)
        options[row['case_id'],row['cell']]={side:{k:Q(v) for k,v in row[side].items()} for side in ['base','fast']};count['expedite_options']+=1
    choices={}
    for row in csvrows('EXPEDITE_CHOICES.csv'):
        q=options[row['case_id'],row['cell']];r=Q(row['margin'])
        pay=lambda c:r*c['primary']-5*c['accepted_shortfall']
        diff=pay(q['fast'])-3-pay(q['base']);sel=diff>Q('1e-6')
        assert int(sel)==int(row['selected_expedite']);close(diff,row['net_advantage'])
        choices[row['case_id'],row['cell'],r]=(q['fast'] if sel else q['base'],sel);count['expedite_choices']+=1
    sensitivity=read(ROOT/'results/v3_design_sensitivities_r1/result.json')
    arms={a['arm']:a for a in sensitivity['fixed_table'] if a['arm']!='net_shortage_value'}
    arms.update({(a['arm'],a['level']):a for a in sensitivity['fixed_table'] if a['arm']=='net_shortage_value'})
    for row in csvrows('SENSITIVITY_GRID.csv'):
        arm=arms[(row['arm'],row['level'])] if row['arm']=='net_shortage_value' else arms[row['arm']]
        rr=[x['row'] for x in arm['cases']];selected=select_group(rr,row['group'],commit);r=Q(row['margin']);gains=[];dd=[];backup=[];harm=[]
        for x in selected:
            if row['arm']=='long_type_expedite':
                t,ts=choices[x['case_id'],'C00',r];f,fs=choices[x['case_id'],'C11',r]
                d=f['primary']-t['primary'];g=r*d-5*(f['accepted_shortfall']-t['accepted_shortfall'])-3*(fs-ts)
                dd.append(d);backup.append(t['backup']-f['backup']);harm.append(f['buyer_cost']-t['buyer_cost'])
            else:
                g=raw_gain(x,r,0 if row['arm']=='no_damages' else 5,3 if row['arm']=='positive_contradiction_fee' else 0)
                dd.append(Q(x['delta_d']));backup.append(Q(x['b']));harm.append(Q(x['buyer_harm']))
            gains.append(g)
        for key,vals in [('mean_gain',gains),('mean_b',backup),('mean_delta_d',dd),('mean_buyer_harm',harm)]:close(sum(vals)/len(vals),row[key])
        signs=Counter(map(status,gains))
        for key in ['positive','numerical_zero','negative']:assert signs[key]==int(row[key])
        count['sensitivity_group_rows']+=1
    db=read(ROOT/'results/v3_discounted_belief_study_r1/result.json')['case_rows']
    for row in csvrows('DISCOUNTED_BELIEF_GRID.csv'):
        selected=select_group([x for x in db if x['alpha']==float(row['alpha'])],row['group'],commit);gains=[]
        for x in selected:
            a=x['totals'];t=baseline['design'][x['case_id']]['cells']['C00']
            gains.append(Q(row['margin'])*(Q(a['primary'])-Q(t['primary']))-5*(Q(a['accepted_shortfall'])-Q(t['accepted_shortfall'])))
        close(sum(gains)/len(gains),row['mean_gain']);signs=Counter(map(status,gains))
        for key in ['positive','numerical_zero','negative']:assert signs[key]==int(row[key])
        count['discounted_group_rows']+=1
    for row in csvrows('CRITICAL_PENALTIES.csv'):
        x=baseline[row['set']][row['case_id']];r=Q(row['margin']);c=x['cells'];d=Q(c['C11']['primary'])-Q(c['C00']['primary']);s=Q(c['C11']['accepted_shortfall'])-Q(c['C00']['accepted_shortfall'])
        if row['critical_penalty']!='':close(r*d/s,row['critical_penalty'])
        close(raw_gain(x,r),row['gain_at_penalty_5']);count['critical_rows']+=1
    protected=read(HERE/'protected_before.json')
    for path,digest in protected.items():assert sha(ROOT/path)==digest,path
    result={'status':'verified','manifest_sha256':sha(HERE/'manifest.json'),'checked':dict(count),'protected_files_unchanged':len(protected),'mip_solves':0,'new_trajectories':0,'private_reads':0,'new_confirmatory_decisions':False}
    (HERE/'VERIFICATION.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))


if __name__=='__main__':main()
