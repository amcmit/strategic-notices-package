"""Render verified repricing artifacts; no model or inference execution."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import csv
import hashlib
import json
import statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE=Path(__file__).resolve().parent;OUT=HERE/'output'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
Q=lambda x:Fraction(str(x))
v=read(HERE/'VERIFICATION.json');assert v['status']=='verified'
provenance=read(OUT/'PROVENANCE.json')
for path,digest in provenance['outputs'].items():assert sha(OUT/path)==digest
source_map=[]
def rows(name):
    with (OUT/name).open() as stream:
        result=list(csv.DictReader(stream))
    for n,row in enumerate(result,2):row['_source']=name;row['_row']=n
    return result
def val(row,key,places=3):
    text=f'{float(row[key]):.{places}f}'
    source_map.append({'display':text,'source':'output/'+row['_source'],'sha256':sha(OUT/row['_source']),'row':row['_row'],'column':key,'operation':'display rounding only'})
    return text
def ref(name):return f"Source: `output/{name}`, SHA-256 `{sha(OUT/name)}`."
def table(headers,data):return '\n'.join(['| '+' | '.join(headers)+' |','|'+'---|'*len(headers)]+['| '+' | '.join(r)+' |' for r in data])

curves=rows('WINDOW_INTERVALS.csv');groups=rows('GROUP_GRID.csv');sens=rows('SENSITIVITY_GRID.csv');belief=rows('DISCOUNTED_BELIEF_GRID.csv');critical=rows('CRITICAL_PENALTIES.csv');choices=rows('EXPEDITE_CHOICES.csv')
functions=read(OUT/'NETWORK_FUNCTIONS.json');summary=read(OUT/'SUMMARY.json');anchors=[0,.25,.5,.75,1]

# Mathematical zero-gain penalties include zero/negative roots. The analysis's
# finite-positive-range category is narrower; an empty field there is not, by
# itself, a claim that the algebraic zero is undefined.
zero_penalties=[];network_thresholds=[]
for n in functions:
    d=Q(n['delivery_slope_exact']);s=-Q(n['penalty_intercept_exact'])/5
    network_thresholds.append({k:n[k] for k in ['set','case_id','regime','category','family','commitment']} |
        {'gain_slope':str(d),'gain_intercept':n['penalty_intercept_exact'],'margin_zero':n['zero'].get('root',''),
         'positive_condition':n['zero']['condition'],'source':'output/NETWORK_FUNCTIONS.json'})
    for j in range(101):
        r=Fraction(j,100);zero=None if abs(s)<=Q('1e-8') else r*d/s
        zero_penalties.append({'set':n['set'],'case_id':n['case_id'],'margin':float(r),
            'zero_gain_penalty_exact':'' if zero is None else str(zero),
            'zero_gain_penalty':'' if zero is None else float(zero),
            'status':'undefined_zero_shortfall' if zero is None else 'defined',
            'gain_increases_with_penalty':s<0,'positive_penalty_range_exists':(s<0 or (s>0 and r*d>0) or (s==0 and r*d>0))})
for name,data in [('NETWORK_THRESHOLDS.csv',network_thresholds),('ZERO_GAIN_PENALTIES.csv',zero_penalties)]:
    with (HERE/name).open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)

# Additional independent checks of count/label fields used in this report.
def sign(x):return 'positive' if x>Q('1e-8') else 'negative' if x<Q('-1e-8') else 'numerical_zero'
for row in curves:
    ns=[n for n in functions if n['set']==row['set'] and n['regime']=='R1' and n['category']=='interior']
    counts=Counter(sign(Q(row['margin'])*Q(n['delivery_slope_exact'])+Q(n['penalty_intercept_exact'])) for n in ns)
    assert all(counts[k]==int(row[k]) for k in ['positive','numerical_zero','negative'])
for row in critical:
    n=next(n for n in functions if n['set']==row['set'] and n['case_id']==row['case_id']);d=Q(n['delivery_slope_exact']);s=-Q(n['penalty_intercept_exact'])/5;r=Q(row['margin'])
    cat='finite_nonnegative' if s>Q('1e-8') and d>Q('1e-8') and r>0 else 'no_positive_range' if s>Q('1e-8') else 'gain_increases_with_penalty' if s<Q('-1e-8') else 'penalty_invariant_'+sign(r*d)
    assert cat==row['category']
for label in ['design','confirmation']:
    assert float(next(x for x in groups if x['set']==label and x['group']=='finite' and float(x['margin'])==1)['mean_gain'])<0

lines=['# Supplier-margin correction from saved evidence','',
       '13 November 2026. **Post-confirmation economic sensitivity; no new confirmatory decisions.**', '',
       'Primary procurement price remains 1 and shortfall penalty remains 5. Ordinary production cost is therefore 1−r for margin r in [0,1]. The range is an economic consistency check, not an empirical calibration. Original study files, protocols, manuscript and inferential decisions are preserved.', '',
       'The correction materially narrows profitability. Finite commitments have a negative mean gain throughout the admissible range. Through-horizon commitments retain positive gains over part of that range, including at a margin of 0.50 with positive production cost. Backup displacement, primary deliveries, buyer harm and attribution for fixed paths are unchanged.', '',
       '## Window networks: main comparison','',
       'Equal-family means and the original 10,000 paired family-stratified bootstrap draws. Intervals are pointwise 98.33% percentile intervals, using the frozen tail probability 0.00835. They are not simultaneous intervals across margins and do not issue a new gate decision. The production-cost column equals 1−r. Positive counts use the original 1e-8 numerical sign tolerance.', '']
data=[]
for r in anchors:
    c=next(x for x in curves if x['set']=='confirmation' and float(x['margin'])==r);d=next(x for x in curves if x['set']=='design' and float(x['margin'])==r)
    data.append([val(c,'margin',2),val(c,'production_cost',2),val(c,'mean_gain'),f"[{val(c,'lower_98_33')}, {val(c,'upper_98_33')}]",val(c,'positive',0)+'/24',val(d,'mean_gain'),f"[{val(d,'lower_98_33')}, {val(d,'upper_98_33')}]",val(d,'positive',0)+'/24'])
lines += [table(['Margin','Production cost','Confirmation mean','Confirmation interval','Positive confirmation cases','Design mean','Design interval','Positive design cases'],data),'',ref('WINDOW_INTERVALS.csv'),'']
for label in ['confirmation','design']:
    s=summary[label];root=s['mean_gain_zero']['root_decimal'];br=s['pointwise_lower_zero']['bracket']
    lines += [f"The {label} equal-family mean crosses zero at r = {root:.6f}. The lower pointwise bootstrap endpoint crosses zero within [{br[0]:.12f}, {br[1]:.12f}]. These are descriptive break-even summaries of the saved data and bootstrap functions, not estimates of industrial margin distributions.",'']
    source_map += [{'display':f'{root:.6f}','source':'output/SUMMARY.json','sha256':sha(OUT/'SUMMARY.json'),'row':label,'column':'mean_gain_zero.root_decimal','operation':'rounding exact affine zero'}, {'display':str(br),'source':'output/SUMMARY.json','sha256':sha(OUT/'SUMMARY.json'),'row':label,'column':'pointwise_lower_zero.bracket','operation':'bracket from saved bootstrap affine functions'}]
lines += [ref('SUMMARY.json'),'','## Commitment groups','',
          'Each group contains 12 confirmation window networks. These are arithmetic means and observed signs, with no subgroup intervals or tests. Other factors and structures also differ between groups, so this is not an estimate of the causal effect of shortening a commitment.','']
data=[]
for r in anchors:
    a=next(x for x in groups if x['set']=='confirmation' and x['group']=='finite' and float(x['margin'])==r);b=next(x for x in groups if x['set']=='confirmation' and x['group']=='horizon' and float(x['margin'])==r)
    data.append([val(a,'margin',2),val(a,'mean_gain'),val(a,'positive',0)+'/12',val(b,'mean_gain'),val(b,'positive',0)+'/12'])
lines += [table(['Margin','Finite mean','Finite positive','Through-horizon mean','Through-horizon positive'],data),'',ref('GROUP_GRID.csv'),'']
for label in ['confirmation','design']:
    rr=[x for x in functions if x['set']==label and x['regime']=='R1' and x['category']=='interior' and x['commitment']=='horizon']
    maximum=max(Q(x['zero']['root']) for x in rr)
    lines += [f'For {label}, every through-horizon network has strictly positive mathematical gain above r = {float(maximum):.6f}. The exact threshold is {maximum}. A 1e-8 gain band around zero applies to the reported numerical sign counts.','']
    source_map.append({'display':f'{float(maximum):.6f}','source':'output/NETWORK_FUNCTIONS.json','sha256':sha(OUT/'NETWORK_FUNCTIONS.json'),'row':f'{label}; R1/interior/horizon','column':'zero.root','operation':'maximum of exact per-network break-even margins'})
lines += [ref('NETWORK_FUNCTIONS.json'),'','![Margin and commitment results](margin_repricing.png)','',
          'Figure: saved confirmation cases. Panel (a) uses equal family weights and pointwise intervals; panel (b) uses arithmetic subgroup means without intervals. Sources: WINDOW_INTERVALS.csv and GROUP_GRID.csv, hashed above.','',
          '## Descriptive sensitivity arms','',
          'All ten arms and all five headline margin levels are shown. Full 0.01 grids, sign counts, unchanged physical means and all six population groups are in SENSITIVITY_GRID.csv. Supplier contradiction and expedite costs remain 3; the no-damages arm retains zero liability. No arm is omitted because its corrected gain is negative.','']
arm_order=[]
for row in sens:
    pair=(row['arm'],row['level'])
    if pair not in arm_order:arm_order.append(pair)
for population,title in [('window','24 design window networks'),('all_56','All 56 design cases')]:
    data=[]
    for arm,level in arm_order:
        ss=[x for x in sens if x['arm']==arm and x['level']==level and x['group']==population]
        data.append([arm+' / '+level]+[val(next(x for x in ss if float(x['margin'])==r),'mean_gain') for r in anchors])
    lines += [f'### {title}: arithmetic mean gain','',table(['Arm / level']+[f'r={r:.2f}' for r in anchors],data),'']
lines += [ref('SENSITIVITY_GRID.csv'),'','## Discounted belief','',
          'Public design window networks only; arithmetic means, no new intervals or tests. The original objective-recomputation warnings remain unresolved. Repricing does not clear that numerical limitation. Physical suppression counts are unchanged.','']
data=[]
for alpha in [0,.25,.5,.75,1]:
    ss=[x for x in belief if x['group']=='window' and float(x['alpha'])==alpha]
    data.append([f'{alpha:.2f}',val(ss[0],'suppressed',0)+'/24']+[val(next(x for x in ss if float(x['margin'])==r),'mean_gain') for r in anchors])
lines += [table(['P(short)','Backup suppressed']+[f'Gain r={r:.2f}' for r in anchors],data),'',ref('DISCOUNTED_BELIEF_GRID.csv'),'','## Expedite choices','']
changes=sum(int(x['changed_from_r3']) for x in choices);selected=sum(int(x['selected_expedite']) for x in choices)
for case_id,cell in {(x['case_id'],x['cell']) for x in choices}:
    endpoints=[x for x in choices if x['case_id']==case_id and x['cell']==cell and float(x['margin']) in [0,1]]
    assert len(endpoints)==2 and endpoints[0]['selected_expedite']==endpoints[1]['selected_expedite']
lines += [f'All 224 saved accelerated alternatives were checked against their baseline cells. The full grid contains {len(choices):,} choice comparisons. There are {changes} selections differing from the saved r=3 decision across that grid. There are {selected} selected expedite records across all margin levels. Each option has the same choice at both endpoints, so its affine net advantage proves that this choice is unchanged throughout [0,1]. EXPEDITE_BREAKPOINTS.json records the exact affine selection conditions, including the 1e-6 decision tolerance.','',ref('EXPEDITE_CHOICES.csv'),'']
source_map.append({'display':str(changes),'source':'output/EXPEDITE_CHOICES.csv','sha256':sha(OUT/'EXPEDITE_CHOICES.csv'),'row':'all','column':'changed_from_r3','operation':'sum'})
source_map.append({'display':str(selected),'source':'output/EXPEDITE_CHOICES.csv','sha256':sha(OUT/'EXPEDITE_CHOICES.csv'),'row':'all','column':'selected_expedite','operation':'sum'})
source_map.append({'display':str(len(choices)),'source':'output/EXPEDITE_CHOICES.csv','sha256':sha(OUT/'EXPEDITE_CHOICES.csv'),'row':'all','column':'case_id,cell,margin','operation':'count records'})
lines += ['## Critical penalties','',
          'For nonzero shortfall difference, the zero-gain penalty is r times delivery difference divided by shortfall difference, scaling by r/3 from its original value. At r=0 this algebraic root is zero, not undefined. Zero shortfall remains undefined. ZERO_GAIN_PENALTIES.csv supplies every defined zero and negative root as well as the positive ones. The table below summarizes only finite strictly positive thresholds; a zero root supplies no strictly profitable nonnegative-penalty range when shortfall is positive.','']
data=[]
for label in ['design','confirmation']:
    for r in anchors:
        rr=[x for x in critical if x['set']==label and float(x['margin'])==r];vv=sorted(float(x['critical_penalty']) for x in rr if x['critical_penalty']!='')
        data.append([label,f'{r:.2f}',str(len(vv)),f'{min(vv):.3f}' if vv else 'none',f'{statistics.median(vv):.3f}' if vv else 'none',f'{max(vv):.3f}' if vv else 'none'])
        source_map.append({'display':str(data[-1]),'source':'output/CRITICAL_PENALTIES.csv','sha256':sha(OUT/'CRITICAL_PENALTIES.csv'),'row':f'{label}; margin={r}','column':'critical_penalty','operation':'count, minimum, ordinary median, maximum over defined finite values'})
lines += [table(['Set','Margin','Finite positive thresholds','Minimum','Median','Maximum'],data),'',ref('CRITICAL_PENALTIES.csv'),'',
          'In CRITICAL_PENALTIES.csv, an empty critical_penalty field denotes absence from that finite-positive-range category. Use ZERO_GAIN_PENALTIES.csv to distinguish an algebraically defined zero or negative root from zero-shortfall undefined cases.','',
          '## Implications for the paper','',
          '- Physical primary confirmation, buyer harm, the four-cell attribution, and suppression under discounted beliefs remain unchanged for the recorded policies. No new trajectories were needed.',
          '- The original profitability test at r=3 is preserved as a historical result. It cannot serve as confirmation of ordinary financial profitability at a different margin. Corrected intervals are explicitly post-confirmation pointwise sensitivity summaries.',
          '- The finite-commitment mean is negative throughout [0,1]. Through-horizon gains remain positive for part of that range, including positive production costs. This supports a narrower commitment-dependent profitability claim, without establishing field prevalence or realistic margin levels.',
          '- The worked example retains its physical suppression mechanism, but its supplier gain becomes 2r−5, from −5 to −3 over [0,1]. The existing profitable-deception numerical illustration must change. The general equilibrium proposition remains conditional on its incentive inequalities.',
          '- The no-damages, positive-fee, backlog, spot, price-parity, shortage-value and belief comparisons must use the corrected payoff values if incorporated into a future manuscript revision. No manuscript changes were made here.',
          '- The archive and unresolved discounted-belief recomputation warnings are separate issues; this correction resolves neither.', '',
          '## Verification and provenance','',
          f"Manifest SHA-256: `{sha(HERE/'manifest.json')}`.",
          f"Independent verification SHA-256: `{sha(HERE/'VERIFICATION.json')}`.",
          'Synthetic tests cover payoff repricing, zero and negative slopes, numerical sign boundaries, expedite ties and changes of choice, and root brackets. The verifier independently reconstructs coefficients from source cells, resamples rows directly, recomputes the original r=3 intervals, and checks every exported grid. Protected scientific files and manuscript sources are unchanged.',
          'No MIP solves, simulation transitions, private cases, seeds or new confirmatory decisions. M5 and the LLM arm remain paused. All artifacts are local.','']
(HERE/'REPORT.md').write_text('\n'.join(lines))
with (HERE/'REPORT_NUMBER_SOURCES.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=['display','source','sha256','row','column','operation']);writer.writeheader();writer.writerows(source_map)

plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'ps.fonttype':42})
fig,axes=plt.subplots(1,2,figsize=(7.3,3.2),layout='constrained')
cc=[x for x in curves if x['set']=='confirmation'];r=[float(x['margin']) for x in cc]
axes[0].fill_between(r,[float(x['lower_98_33']) for x in cc],[float(x['upper_98_33']) for x in cc],color='0.85',label='Pointwise 98.33% interval')
axes[0].plot(r,[float(x['mean_gain']) for x in cc],color='black',lw=1.6,label='Equal-family mean')
for group,label,style in [('finite','Finite','--'),('horizon','Through-horizon','-')]:
    ss=[x for x in groups if x['set']=='confirmation' and x['group']==group]
    axes[1].plot([float(x['margin']) for x in ss],[float(x['mean_gain']) for x in ss],style,color='black',lw=1.6,label=label)
for ax in axes:
    ax.axhline(0,color='0.45',lw=.7);ax.set(xlim=(0,1),xlabel='Supplier margin r (primary price = 1)',ylabel='Supplier gain at penalty 5')
    ax.set_xticks([0,.25,.5,.75,1]);ax.legend(frameon=False,fontsize=7.5,loc='upper left')
axes[0].set_title('(a) All 24 window networks',loc='left',fontsize=9)
axes[1].set_title('(b) Commitment groups (12 each)',loc='left',fontsize=9)
metadata={'Title':'Supplier-margin repricing of saved confirmation outcomes','Subject':'Post-confirmation descriptive sensitivity. WINDOW_INTERVALS.csv SHA-256 '+sha(OUT/'WINDOW_INTERVALS.csv')+'; GROUP_GRID.csv SHA-256 '+sha(OUT/'GROUP_GRID.csv'),'Creator':'Verified cached-evidence report','Author':''}
fig.savefig(HERE/'margin_repricing.pdf',metadata=metadata)
fig.savefig(HERE/'margin_repricing.png',dpi=220,metadata={'Description':metadata['Subject']});plt.close(fig)
(HERE/'REPORT_BINDINGS.json').write_text(json.dumps({'generator_sha256':sha(HERE/'report.py'),'verified_provenance_sha256':sha(OUT/'PROVENANCE.json'),'verification_sha256':sha(HERE/'VERIFICATION.json'),'report_sha256':sha(HERE/'REPORT.md'),'source_map_sha256':sha(HERE/'REPORT_NUMBER_SOURCES.csv'),'figure_pdf_sha256':sha(HERE/'margin_repricing.pdf'),'figure_png_sha256':sha(HERE/'margin_repricing.png'),'network_thresholds_sha256':sha(HERE/'NETWORK_THRESHOLDS.csv'),'zero_gain_penalties_sha256':sha(HERE/'ZERO_GAIN_PENALTIES.csv')},indent=2)+'\n')
print('Report and source-bound figure written.')
