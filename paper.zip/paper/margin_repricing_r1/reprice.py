"""Post-confirmation monetary repricing of saved records. No study imports."""
from pathlib import Path
from fractions import Fraction
from random import Random
from collections import Counter
import csv
import hashlib
import json
import platform
import resource
import time
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
FAMILIES = ('assembly', 'distribution', 'layered_dual', 'planted', 'serial')
CELLS = ('C00', 'C10', 'C01', 'C11')
EPS = Fraction(1, 100_000_000)
F = lambda x: Fraction(str(x))
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def dump(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def csvout(path, rows):
    assert rows
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def coeff(row, liability=1, fixed=0):
    t, f = row['cells']['C00'], row['cells']['C11']
    delivery = F(f['primary']) - F(t['primary'])
    shortfall = F(f['accepted_shortfall']) - F(t['accepted_shortfall'])
    return delivery, -5 * liability * shortfall - fixed


def sign(value):
    return 'positive' if value > EPS else 'negative' if value < -EPS else 'numerical_zero'


def threshold(a, b):
    """Exact zero of a*r+b, separate from the numerical sign tolerance."""
    if not a:
        return {'root': None, 'condition': 'always_positive' if b > 0 else 'always_negative' if b < 0 else 'identically_zero'}
    root = -b / a
    return {'root': str(root), 'root_decimal': float(root), 'condition': 'r > root' if a > 0 else 'r < root',
            'root_in_0_1': 0 <= root <= 1, 'sign_tolerance_margin_half_width': float(EPS / abs(a))}


def window(row):
    return row['regime'] == 'R1' and row['category'] == 'interior'


def group_rows(rows, commitments, families=True):
    interior = [r for r in rows if window(r)]
    groups = [('all_56', rows), ('window', interior), ('boundary', [r for r in rows if r['regime'] == 'R1' and not window(r)])]
    groups += [(regime, [r for r in rows if r['regime'] == regime]) for regime in ['R2', 'R3', 'R4']]
    if families:
        groups += [(name, [r for r in interior if commitments[r['case_id']] == name]) for name in ['finite', 'horizon']]
        groups += [('family_' + name, [r for r in interior if r['family'] == name]) for name in FAMILIES]
    return groups


def bootstrap_lines(rows):
    """Preserve the frozen RNG draw order, including intervening contrasts."""
    selected = [r for r in rows if window(r)]
    comparison = [r for r in rows if r['regime'] in ['R2', 'R3', 'R4']]
    indices = {family: [i for i, r in enumerate(selected) if r['family'] == family] for family in FAMILIES}
    other_sizes = {family: sum(r['family'] == family for r in comparison) for family in FAMILIES}
    rng = Random(20261112)
    weights = np.zeros((10000, len(selected)))
    for j in range(10000):
        for family, ix in indices.items():
            for _ in ix:
                weights[j, ix[rng.randrange(len(ix))]] += 1 / (5 * len(ix))
        for family in FAMILIES:
            for _ in range(other_sizes[family]):
                rng.randrange(other_sizes[family])
    ab = [coeff(r) for r in selected]
    a = np.array([float(v[0]) for v in ab]); b = np.array([float(v[1]) for v in ab])
    mean_a = sum(sum(ab[i][0] for i in ix) / len(ix) for ix in indices.values()) / 5
    mean_b = sum(sum(ab[i][1] for i in ix) / len(ix) for ix in indices.values()) / 5
    return selected, weights @ a, weights @ b, mean_a, mean_b


def interval(a, b, r):
    return tuple(float(v) for v in np.quantile(a * r + b, [0.00835, 0.99165], method='linear'))


def monotone_zero(fun):
    if fun(0) > 0: return {'classification': 'positive_throughout', 'bracket': None}
    if fun(1) <= 0: return {'classification': 'not_positive_in_domain', 'bracket': None}
    lo, hi = 0., 1.
    while hi - lo > 1e-10:
        mid = (lo + hi) / 2
        if fun(mid) > 0: hi = mid
        else: lo = mid
    return {'classification': 'one_zero_crossing', 'bracket': [lo, hi],
            'interpretation': 'positive above root; descriptive pointwise endpoint, not a new test'}


def accelerated_options(path):
    options = {}; sources = {}
    with path.open() as stream:
        for line_number, line in enumerate(stream, 1):
            p = json.loads(line)
            if p['arm'] != 'long_type_expedite': continue
            assert p['status'] == 'completed' and len(p['periods']) == 20
            ledgers = [r['ledger'] for r in p['periods']]
            def total(field): return sum((F(x[field]) for x in ledgers), Fraction(0))
            cell = {'primary': total('primary_delivered'), 'backup': total('backup_delivered'),
                    'accepted_shortfall': sum((F(x['primary_shortfall']) - F(x['pre_horizon_order_shortfall']) for x in ledgers), Fraction(0)),
                    'buyer_cost': total('operating_cost')}
            options[p['case_id'], p['cell']] = cell
            sources[p['case_id'], p['cell']] = line_number
    assert len(options) == 224
    return options, sources


def choose(base, fast, r):
    diff = r * (F(fast['primary']) - F(base['primary'])) - 5 * (F(fast['accepted_shortfall']) - F(base['accepted_shortfall'])) - 3
    return diff > Fraction(1, 1_000_000), diff


def main():
    started = time.monotonic(); manifest = read(HERE / 'manifest.json')
    for path, digest in manifest['inputs'].items():
        assert sha(ROOT / path) == digest, path
    for path, digest in manifest['source_sha256'].items(): assert sha(ROOT / path) == digest, path
    assert sha(ROOT / 'paper/paper_inputs.json') == manifest['paper_input_manifest_sha256']
    dest = HERE / 'output'; dest.mkdir(exist_ok=False)
    datasets = {}
    for label, folder, analysis in [('design', 'v3_design_false_notice_r2', 'analysis_validation'), ('confirmation', 'v3_confirmation_opening', 'analysis_confirmation')]:
        result = read(ROOT / f'results/{folder}/result.json'); verification = read(ROOT / f'results/{folder}/verification.json')
        assert result['status'] == 'completed' and verification['status'] == 'verified'
        assert verification['result_sha256'] == manifest['inputs'][f'results/{folder}/result.json']
        assert len(result['case_rows']) == 56
        datasets[label] = (result, analysis)
    allocation = read(ROOT / 'configs/proposed-v3-allocation.json')
    commitments = {r['case_id']: r['commitment'] for r in allocation['candidates'][0]['cases']}
    commitments.update({r['case_id']: r['factors']['commitment'] for r in read(ROOT / 'configs/v3-confirmation-public.json')['cases']})
    margins = [Fraction(i, 100) for i in range(101)]
    anchors = [Fraction(i, 4) for i in range(5)]
    networks = []; network_grid = []; groups = []; curves = []; critical = []; summary = {}; sources = []
    bootstrap_export = []
    for label, (result, analysis_key) in datasets.items():
        rows = result['case_rows']
        for i, row in enumerate(rows):
            a, b = coeff(row)
            assert abs(float(3*a+b) - row['g_3_5']) < 1e-7
            assert abs(float(a) - row['delta_d']) < 1e-7
            item = {'set': label, 'case_id': row['case_id'], 'regime': row['regime'], 'category': row['category'],
                    'family': row['family'], 'commitment': commitments[row['case_id']],
                    'delivery_slope_exact': str(a), 'penalty_intercept_exact': str(b),
                    'delta_d': float(a), 'shortfall_difference': float(-b/5), 'zero': threshold(a,b)}
            networks.append(item)
            sources.append({'set':label, 'case_id':row['case_id'], 'source':f"results/{'v3_confirmation_opening' if label=='confirmation' else 'v3_design_false_notice_r2'}/result.json", 'locator':f'case_rows[{i}].cells.C00/C11.primary, accepted_shortfall; regime,category,family', 'operation':'r*(C11.primary-C00.primary)-5*(C11.accepted_shortfall-C00.accepted_shortfall)'})
            for r in margins:
                network_grid.append({'set':label,'case_id':row['case_id'],'margin':float(r),'gain':float(r*a+b),'gain_exact':str(r*a+b),'sign':sign(r*a+b)})
            shortfall=-b/5
            for r in anchors:
                category = 'finite_nonnegative' if shortfall>EPS and a>EPS and r>0 else 'no_positive_range' if shortfall>EPS else 'gain_increases_with_penalty' if shortfall < -EPS else 'penalty_invariant_'+sign(r*a)
                critical.append({'set':label,'case_id':row['case_id'],'margin':float(r),'category':category,'critical_penalty':float(r*a/shortfall) if category=='finite_nonnegative' else '', 'gain_at_penalty_5':float(r*a+b)})
        for name, group in group_rows(rows, commitments):
            for r in margins:
                gains=[r*coeff(row)[0]+coeff(row)[1] for row in group]; counts=Counter(map(sign,gains))
                groups.append({'set':label,'group':name,'margin':float(r),'n':len(group),'weighting':'equal_network','mean_gain':float(sum(gains)/len(gains)), 'minimum_gain':float(min(gains)), 'maximum_gain':float(max(gains)), **{key:counts[key] for key in ['positive','numerical_zero','negative']}})
        selected, aa, bb, ma, mb = bootstrap_lines(rows)
        old = result[analysis_key]['intervals']['g_3_5']; lo,hi=interval(aa,bb,3)
        assert max(abs(float(3*ma+mb)-old['estimate']),abs(lo-old['lower']),abs(hi-old['upper']))<1e-9
        assert np.all(aa>0)
        for j,(a,b) in enumerate(zip(aa,bb)):bootstrap_export.append({'set':label,'replicate':j,'delivery_slope':float(a),'penalty_intercept':float(b)})
        for r in margins:
            lo,hi=interval(aa,bb,float(r)); counts=Counter(sign(r*coeff(row)[0]+coeff(row)[1]) for row in selected)
            curves.append({'set':label,'margin':float(r),'production_cost':1-float(r),'n':24,'weighting':'equal_family','mean_gain':float(r*ma+mb),'lower_98_33':lo,'upper_98_33':hi,**{key:counts[key] for key in ['positive','numerical_zero','negative']}})
        summary[label]={'mean_delivery_slope_exact':str(ma),'mean_penalty_intercept_exact':str(mb),'mean_gain_zero':threshold(ma,mb),
                        'pointwise_lower_zero':monotone_zero(lambda r:interval(aa,bb,r)[0]),
                        'pointwise_upper_zero':monotone_zero(lambda r:interval(aa,bb,r)[1]),
                        'old_r3_reproduced':{'estimate':float(3*ma+mb),'lower':interval(aa,bb,3)[0],'upper':interval(aa,bb,3)[1]},
                        'unchanged_original_primary':result[analysis_key]['h1_decision'],
                        'original_secondary_decisions_preserved':result[analysis_key]['secondary_decisions']}
    dump(dest/'NETWORK_FUNCTIONS.json',networks); csvout(dest/'NETWORK_GRID.csv',network_grid)
    csvout(dest/'GROUP_GRID.csv',groups);csvout(dest/'WINDOW_INTERVALS.csv',curves);csvout(dest/'CRITICAL_PENALTIES.csv',critical)
    csvout(dest/'BOOTSTRAP_AFFINE_LINES.csv',bootstrap_export);csvout(dest/'SOURCE_MAP.csv',sources)
    # Saved descriptive arms. Expedite choice is recomputed, not held fixed.
    sensitivity=read(ROOT/'results/v3_design_sensitivities_r1/result.json')
    fast, fast_sources=accelerated_options(ROOT/'results/v3_design_sensitivities_r1/progress.jsonl')
    base={r['case_id']:r for r in datasets['design'][0]['case_rows']}
    option_rows=[]; sensitivity_grid=[]; sensitivity_choices=[]; expedite_boundaries=[]
    for (case_id,cell),accelerated in fast.items():
        slow=base[case_id]['cells'][cell]; a=F(accelerated['primary'])-F(slow['primary']); b=-5*(F(accelerated['accepted_shortfall'])-F(slow['accepted_shortfall']))-3
        option_rows.append({'case_id':case_id,'cell':cell,'base':{k:str(F(slow[k])) for k in accelerated},'fast':{k:str(v) for k,v in accelerated.items()},'progress_jsonl_line':fast_sources[case_id,cell]})
        expedite_boundaries.append({'case_id':case_id,'cell':cell,'fast_minus_base_slope':str(a),'fast_minus_base_intercept':str(b),'selection':threshold(a,b-Fraction(1,1000000))})
    for arm in sensitivity['fixed_table']:
        for r in margins+[Fraction(3)]:
            changed=[]
            for c in arm['cases']:
                row=c['row'];cid=c['case_id']; item=dict(row)
                if arm['arm']=='long_type_expedite':
                    chosen={}; picks={}
                    for cell in CELLS:
                        selected,diff=choose(base[cid]['cells'][cell],fast[cid,cell],r)
                        if r==3: assert selected==row['expedite_choices'][cell]['selected']
                        chosen[cell]=fast[cid,cell] if selected else {k:F(v) for k,v in base[cid]['cells'][cell].items() if isinstance(v,(float,int))}
                        picks[cell]=selected
                        if r<=1:sensitivity_choices.append({'case_id':cid,'cell':cell,'margin':float(r),'selected_expedite':int(selected),'net_advantage':float(diff),'changed_from_r3':int(selected!=row['expedite_choices'][cell]['selected'])})
                    a=F(chosen['C11']['primary'])-F(chosen['C00']['primary']);s=F(chosen['C11']['accepted_shortfall'])-F(chosen['C00']['accepted_shortfall'])
                    g=r*a-5*s-3*(int(picks['C11'])-int(picks['C00']))
                    item.update(delta_d=float(a),b=float(F(chosen['C00']['backup'])-F(chosen['C11']['backup'])),buyer_harm=float(F(chosen['C11']['buyer_cost'])-F(chosen['C00']['buyer_cost'])))
                else:
                    a,b=coeff(row,liability=0 if arm['arm']=='no_damages' else 1,fixed=3 if arm['arm']=='positive_contradiction_fee' else 0);g=r*a+b
                if r==3:assert abs(float(g)-row['supplier_gain'])<1e-7
                item['repriced_gain']=g;changed.append(item)
            if r>1:continue
            for name,group in group_rows(changed,commitments,families=False):
                counts=Counter(sign(x['repriced_gain']) for x in group)
                sensitivity_grid.append({'arm':arm['arm'],'level':arm['level'],'margin':float(r),'group':name,'n':len(group),'mean_gain':float(sum(x['repriced_gain'] for x in group)/len(group)), 'mean_b':sum(x['b'] for x in group)/len(group),'mean_delta_d':sum(x['delta_d'] for x in group)/len(group),'mean_buyer_harm':sum(x['buyer_harm'] for x in group)/len(group),**{key:counts[key] for key in ['positive','numerical_zero','negative']}})
    csvout(dest/'SENSITIVITY_GRID.csv',sensitivity_grid);csvout(dest/'EXPEDITE_CHOICES.csv',sensitivity_choices)
    dump(dest/'EXPEDITE_OPTIONS.json',option_rows);dump(dest/'EXPEDITE_BREAKPOINTS.json',expedite_boundaries)
    # Exogenous-belief paths, with their original numerical-warning limitation.
    belief=read(ROOT/'results/v3_discounted_belief_study_r1/result.json');discounted=[]
    for alpha in [0,.25,.5,.75,1]:
        rr=[dict(row) for row in belief['case_rows'] if row['alpha']==alpha];assert len(rr)==56
        for row in rr:
            truth=base[row['case_id']]['cells']['C00']; observed=row['totals']
            a=F(observed['primary'])-F(truth['primary']);b=-5*(F(observed['accepted_shortfall'])-F(truth['accepted_shortfall']))
            assert abs(float(a)-row['delta_d'])<1e-7 and abs(float(3*a+b)-row['g_3_5'])<1e-7
            row['a'],row['b_gain']=a,b
        for r in margins:
            for name,group in group_rows(rr,commitments,families=False):
                gains=[r*row['a']+row['b_gain'] for row in group];counts=Counter(map(sign,gains))
                discounted.append({'alpha':alpha,'margin':float(r),'group':name,'n':len(group),'mean_gain':float(sum(gains)/len(gains)), 'suppressed':sum(bool(base[row['case_id']]['cells']['C00']['qualification_dates']) and not row['totals']['qualification_dates'] for row in group),**{key:counts[key] for key in ['positive','numerical_zero','negative']}})
    csvout(dest/'DISCOUNTED_BELIEF_GRID.csv',discounted)
    summary['method']={'purpose':manifest['purpose'],'pointwise_interval_level':.9833,'intervals_not_simultaneous':True,'new_confirmatory_decisions':False,'toy_gain':'2*r-5; negative throughout [0,1]','discounted_belief_warning':'Original objective-recomputation warning remains unresolved; repricing does not clear it.'}
    summary['resource']={'wall_seconds':time.monotonic()-started,'peak_rss_bytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss if platform.system()=='Darwin' else resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024,'mip_solves':0,'new_trajectories':0,'private_reads':0}
    assert summary['resource']['wall_seconds']<manifest['caps']['analysis_wall_seconds']
    dump(dest/'SUMMARY.json',summary)
    size=sum(p.stat().st_size for p in dest.iterdir());assert size<manifest['caps']['saved_output_mib']*1024**2
    dump(dest/'PROVENANCE.json',{'manifest_sha256':sha(HERE/'manifest.json'),'inputs':manifest['inputs'],'sources':manifest['source_sha256'],'python':platform.python_version(),'numpy':np.__version__,'outputs':{p.name:sha(p) for p in dest.iterdir() if p.is_file()}})
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
